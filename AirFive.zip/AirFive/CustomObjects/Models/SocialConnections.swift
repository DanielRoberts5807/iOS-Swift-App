//
//  SocialConnections.swift
//  AirFive
//
//  Created by Anil Gautam on 18/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class SocialConnections {
    
    var facebookUrl:String = "", twitterUrl:String = "", googleUrl:String = "", tumlbrUrl:String = "",
    instagramUrl:String = "", linkedinUrl:String = "", snapchatUrl:String = ""
    var facebookUrlVisibility:Bool = true, twitterUrlVisibility:Bool = true, googleUrlVisibility:Bool = true, tumlbrUrlVisibility:Bool = true, instagramUrlVisibility:Bool = true, linkedinUrlVisibility:Bool = true, snapchatUrlVisibility:Bool = true
    
    init(){
    }
    
    init(facebookUrl:String, twitterUrl:String, googleUrl:String, tumlbrUrl:String, instagramUrl:String, linkedinUrl:String, snapchatUrl:String) {
        self.facebookUrl = facebookUrl
        self.twitterUrl = twitterUrl
        self.googleUrl = googleUrl
        self.tumlbrUrl = tumlbrUrl
        self.instagramUrl = instagramUrl
        self.linkedinUrl = linkedinUrl
        self.snapchatUrl = snapchatUrl
    }
    
    static func createDummyContactDetail() -> SocialConnections {
        
        let socialConnections = SocialConnections(facebookUrl: "", twitterUrl: "", googleUrl: "", tumlbrUrl: "", instagramUrl: "", linkedinUrl: "asdf", snapchatUrl: "asdf")
       return socialConnections
        
    }
    
    static func makeSocialConnectionsFromJson(jsonResponse:Dictionary<String,AnyObject>) -> SocialConnections {
        
        let socialConnections = SocialConnections()
        
        if let json = jsonResponse["facebook"] as? [String:String] {
            if let url = json["facebook_url"] {
                socialConnections.facebookUrl = url
            }
            if let visibility = json["facebook_url_visiblity"] {
                socialConnections.facebookUrlVisibility = visibility == "1"
            }
        }

        if let json = jsonResponse["twitter"] as? [String:String] {
            if let url = json["twitter_url"] {
                socialConnections.twitterUrl = url
            }
            if let visibility = json["twitter_url_visiblity"] {
                socialConnections.twitterUrlVisibility = visibility == "1"
            }
        }
        
        if let json = jsonResponse["google"] as? [String:String] {
            if let url = json["google_url"] {
                socialConnections.googleUrl = url
            }
            if let visibility = json["google_url_visiblity"] {
                socialConnections.googleUrlVisibility = visibility == "1"
            }
        }
        
        if let json = jsonResponse["tumlbr"] as? [String:String] {
            if let url = json["tumlbr_url"] {
                socialConnections.tumlbrUrl = url
            }
            if let visibility = json["tumlbr_url_visiblity"] {
                socialConnections.tumlbrUrlVisibility = visibility == "1"
            }
        }
        
        if let json = jsonResponse["instagram"] as? [String:String] {
            if let url = json["instagram_url"] {
                socialConnections.instagramUrl = url
            }
            if let visibility = json["instagram_url_visiblity"] {
                socialConnections.instagramUrlVisibility = visibility == "1"
            }
        }
        
        if let json = jsonResponse["linkedin"] as? [String:String] {
            if let url = json["linkedin_url"] {
                socialConnections.linkedinUrl = url
            }
            if let visibility = json["linkedin_url_visiblity"] {
                socialConnections.linkedinUrlVisibility = visibility == "1"
            }
        }
        
        if let json = jsonResponse["snapchat"] as? [String:String] {
            if let url = json["snapchat_url"] {
                socialConnections.snapchatUrl = url
            }
            if let visibility = json["snapchat_url_visiblity"] {
                socialConnections.snapchatUrlVisibility = visibility == "1"
            }
        }
        
        return socialConnections
        
    }
    
}