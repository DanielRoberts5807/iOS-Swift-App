//
//  Feed.swift
//  AirFive
//
//  Created by Umair Bhatti on 01/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class Feed {
    var id = "", message = "", name = "", title = "", company = "", personalStmt = "", profileImg = "", action = FeedAction.Info, type = FeedType.Other
    var event:Event! = nil
    var contactId:String! = nil, contactName:String! = nil
    var contentMeta:ContentMeta! = nil, contentLikes = 0, contentLiked = false
    
    static func createDummyFeeds() -> [Feed] {
        
        var feeds:[Feed] = []
        for _ in 0..<1 {
            var feed = Feed()
            feed.name = "Katherine Atcheson"
            feed.message = "Katherine Atcheson asked for coffee"
            feed.action = FeedAction.Bite
            feed.type = FeedType.Other
            feeds.append(feed)
            
            feed = Feed()
            feed.name = "Flora"
            feed.message = "Flora accepted for meeting"
            feed.action = FeedAction.Info
            feed.type = FeedType.Other
            feeds.append(feed)
            
            feed = Feed()
            feed.message = "LA Spartan MSU vs OSU Gamewathch Next Sat 10/12 - Pony T's, Los Angeles"
            feed.action = FeedAction.Event
            feed.type = FeedType.Event
            feeds.append(feed)
        }
        
        var feed = Feed()
        feed.name = "Flora Walkins"
        feed.action = FeedAction.Content
        feed.type = FeedType.Content
        
        feed.contentMeta = ContentMeta()
        feed.contentMeta.title = "test"
        feed.contentMeta.desc = "test"
        feed.contentMeta.url = "https://test.com"
        feed.contentLikes = 23
        
        feeds.append(feed)
        
        feed = Feed()
        feed.name = "Flora Walkins"
        feed.action = FeedAction.Content
        feed.type = FeedType.Content
        
        feed.contentMeta = ContentMeta()
        feed.contentMeta.title = "test"
        feed.contentMeta.desc = "test"
        feed.contentMeta.url = "test"
        feed.contentMeta.imgUrl = "tourSlide"
        feed.contentLikes = 23
        
        feeds.append(feed)
        
        return feeds
    }
    
    static func mergeOldAndNewFeed(feedFor:String, var jsonResponse:Dictionary<String,AnyObject>) -> Dictionary<String,AnyObject> {
    
        let userId = Helper.getUserId()
        if userId == nil {
            return jsonResponse
        }
        
        let fileName = "feed_" + feedFor + userId! + ".json"
        let paths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)
        let documentDirectory = paths[0] 
        let url = NSURL(fileURLWithPath: documentDirectory)
        let fileUrl = url.URLByAppendingPathComponent(fileName)
        
        let manager = NSFileManager.defaultManager()
        if (manager.fileExistsAtPath(fileUrl.path!)) {
            
            if let _ = jsonResponse["feeds"] as? Array<AnyObject> {
                var newfeeds:[AnyObject] = (jsonResponse["feeds"] as? Array<AnyObject>)!
                
                let oldJson = NSDictionary(contentsOfFile: fileUrl.path!)! as! [String:AnyObject]
                if let oldfeeds = oldJson["feeds"] as? Array<AnyObject> {
                    
                    for oldfeed in oldfeeds {
                        
                        if shouldMergeFeed(feedFor, oldfeed: oldfeed as! [String:AnyObject],newfeeds: newfeeds) {
                            newfeeds.append(oldfeed)
                        }
                    }
                    
                }
                jsonResponse["feeds"] = newfeeds
            }
            
        }

        (jsonResponse as NSDictionary).writeToFile(fileUrl.path!, atomically: true)
        return jsonResponse
        
    }
    
    static func shouldMergeFeed(feedFor:String, oldfeed:[String:AnyObject], newfeeds:[AnyObject]) -> Bool {

        if feedFor == FeedsFilter.Content.rawValue {
        
            var oldFeedContentId = ""
            if oldfeed.keys.contains("content_id") == true {
                oldFeedContentId = oldfeed["content_id"]! as! String
            }
            
            for json in newfeeds {
                
                let newfeed = json as! [String:AnyObject]
                var newFeedContentId = ""
                
                if newfeed.keys.contains("content_id") == true {
                    newFeedContentId = newfeed["content_id"]! as! String
                }
                
                if oldFeedContentId == newFeedContentId && oldFeedContentId.characters.count > 0 {
                    return false
                }
                
            }
            return true
            
        }
        
        var oldFeedId = ""
        if oldfeed.keys.contains("invite_id") == true {
            oldFeedId = oldfeed["invite_id"]! as! String
        }else if oldfeed.keys.contains("invitation_id") == true {
            oldFeedId = oldfeed["invitation_id"]! as! String
        }
        
        for json in newfeeds {
            let newfeed = json as! [String:AnyObject]
            var newFeedId = ""
            if newfeed.keys.contains("invite_id") == true {
                newFeedId = newfeed["invite_id"]! as! String
            }else if newfeed.keys.contains("invitation_id") == true {
                newFeedId = newfeed["invitation_id"]! as! String
            }
            
            if oldFeedId == newFeedId && oldFeedId.characters.count > 0 {
                return false
            }
            
        }
        return true
        
    }
    
    static func loadFeedsForFilter(feedFor:String) -> [Feed] {
    
        var feeds:[Feed] = []
        let userId = Helper.getUserId()
        if userId == nil {
            return feeds
        }
        
        let fileName = "feed_" + feedFor + userId! + ".json"
        let paths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)
        let documentDirectory = paths[0]
        let url = NSURL(fileURLWithPath: documentDirectory)
        let fileUrl = url.URLByAppendingPathComponent(fileName)
        
        let manager = NSFileManager.defaultManager()
        if (manager.fileExistsAtPath(fileUrl.path!)) {
            
            let oldJson = NSDictionary(contentsOfFile: fileUrl.path!)! as! [String:AnyObject]
            feeds = makeFeedsFromJson(oldJson)
            
        }
        
        return feeds
        
    }
    
    static func removeFeed(feedId:String, feedFor:String) {
        
        let userId = Helper.getUserId()
        if userId == nil {
            return
        }
        
        let fileName = "feed_" + feedFor + userId! + ".json"
        let paths = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)
        let documentDirectory = paths[0]
        let url = NSURL(fileURLWithPath: documentDirectory)
        let fileUrl = url.URLByAppendingPathComponent(fileName)
        
        let manager = NSFileManager.defaultManager()
        if (manager.fileExistsAtPath(fileUrl.path!)) {
            
            let oldJson = NSDictionary(contentsOfFile: fileUrl.path!)! as! [String:AnyObject]
            var resultFeeds = [AnyObject]()
            var jsonResponse = oldJson
            
            if let oldfeeds = oldJson["feeds"] as? Array<AnyObject> {
                
                for feed in oldfeeds {
                    
                    let oldFeed = feed as! [String:AnyObject]
                    var oldFeedId = ""
                    if oldFeed.keys.contains("invite_id") == true {
                        oldFeedId = oldFeed["invite_id"]! as! String
                    }else if oldFeed.keys.contains("invitation_id") == true {
                        oldFeedId = oldFeed["invitation_id"]! as! String
                    }
                    
                    if oldFeedId != feedId {
                    
                        resultFeeds.append(oldFeed)
                        
                    }
                    
                }
                
            }
            jsonResponse["feeds"] = resultFeeds
            
            (jsonResponse as NSDictionary).writeToFile(fileUrl.path!, atomically: true)
            
        }
        
    }
    
    
    static func makeFeedsFromJson(jsonResponse:Dictionary<String,AnyObject>) -> [Feed] {
        
        var feeds:[Feed] = []
        
        if let feedsJsonArray = jsonResponse["feeds"] as? Array<AnyObject> {
            for json in feedsJsonArray {
                let feedJson = json as! Dictionary<String,AnyObject>
                let feed = Feed()
                
                if feedJson.keys.contains("invite_id") == true {
                    feed.id = feedJson["invite_id"]! as! String
                }else if feedJson.keys.contains("invitation_id") == true {
                    feed.id = feedJson["invitation_id"]! as! String
                }
                
                if feedJson.keys.contains("text") == true {
                    feed.message = feedJson["text"]! as! String
                }
                if feedJson.keys.contains("name") == true {
                    feed.name = feedJson["name"]! as! String
                }
                if feedJson.keys.contains("profile_image") == true {
                    feed.profileImg = feedJson["profile_image"]! as! String
                }
                if feedJson.keys.contains("invitation") == true {
                    let action = feedJson["invitation"]! as! String
                    
                    feed.type = FeedType.Other
                    
                    if action == "info" {
                        feed.action = FeedAction.Info
                    }
                    else if action == "bite" {
                        feed.action = FeedAction.Bite
                    }
                    else if action == "coffee" {
                        feed.action = FeedAction.Coffee
                    }
                    else if action == "info_bite" || action == "info_coffee"  {
                        feed.action = FeedAction.InfoContact
                        
                        if let contactJson = feedJson["contact"] as? [String: String] {
                            feed.contactId = contactJson["contact_id"]!
                            feed.contactName = contactJson["contact_name"]!
                        }
                        
                    }
                    
                    else if action == "event_creater" {
                        feed.action = FeedAction.Info
                        feed.type = FeedType.Event
                    }
                    else if action == "event" {
                        feed.action = FeedAction.Event
                        feed.type = FeedType.Event
                    }
                    else if action == "event_details" {
                        feed.action = FeedAction.EventDetail
                        feed.type = FeedType.Event
                    }
                    else if action == "info_event" {
                        feed.action = FeedAction.Info
                    }
                    
                    else if action == "content" {
                        feed.action = FeedAction.Content
                        feed.type = FeedType.Content
                    }
                    
                    if action == "event" || action == "event_details" {
                        if feedJson.keys.contains("event") == true {
                            let eventJson = feedJson["event"]! as! Dictionary<String,AnyObject>
                            feed.event = Event.makeEventFromJson(eventJson)
                        }
                    }
                    else if action == "content" {
                        if feedJson.keys.contains("meta") == true {
                            feed.contentMeta = ContentMeta.makeContentMetaFromJson(feedJson)
                            if feedJson.keys.contains("content_id") == true {
                                feed.contentMeta.id = feedJson["content_id"]! as! String
                            }
                        }
                        if feedJson.keys.contains("likes") == true {
                            feed.contentLikes = feedJson["likes"]! as! Int
                        }
                        
                        if feedJson.keys.contains("liked_by_current") == true {
                            feed.contentLiked = feedJson["liked_by_current"]! as! Bool
                        }
                    }
                    
                }
                
                if feedJson.keys.contains("title") == true {
                    feed.title = feedJson["title"]! as! String
                }
                
                if feedJson.keys.contains("company") == true {
                    feed.company = feedJson["company"]! as! String
                }
                
                if feedJson.keys.contains("personal_statement") == true {
                    feed.personalStmt = feedJson["personal_statement"]! as! String
                }
                
                feeds.append(feed)
                
            }
        }
        
        return feeds
        
    }
    
}