//
//  ContactDetail.swift
//  AirFive
//
//  Created by Anil Gautam on 17/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class ContactDetail {
    
    class DetailUrl {
        var urlName:String = "", urlValue:String = ""
        
        init() {
        }
        
        init(urlName:String, urlValue:String) {
            self.urlName = urlName
            self.urlValue = urlValue
        }
    }
    
    var id:String = "", name:String = "", title:String = "", company:String = "", school:String = "", secondSchool:String = "", personalStmt = ""
    var profileImg:String = "", coverImg:String = ""
    var detailUrls:[DetailUrl] = []
    
    init(){
    }
    
    init(id:String, name:String, title:String, company:String, school:String, secondSchool:String, profileImg:String, coverImg:String) {
        self.id = id
        self.name = name
        self.title = title
        self.company = company
        self.school = school
        self.secondSchool = secondSchool
        self.profileImg = profileImg
        self.coverImg = coverImg
    }
    
    static func createDummyContactDetail() -> ContactDetail {
        
        let contactDetail = ContactDetail(id: "1", name: "Lily Richards", title: "Professional", company: "Saloon", school: "Michigan State", secondSchool: "", profileImg: "", coverImg: "")
        return contactDetail
        
    }
    
    static func makeContactDetailFromJson(jsonResponse:Dictionary<String,AnyObject>) -> ContactDetail {
        
        let contactDetail = ContactDetail()
        
        if jsonResponse.keys.contains("name") == true {
            contactDetail.name = jsonResponse["name"]! as! String
        }
        
        if jsonResponse.keys.contains("profile_image") == true {
            contactDetail.profileImg = jsonResponse["profile_image"]! as! String
        }
        
        if jsonResponse.keys.contains("cover_image") == true {
            contactDetail.coverImg = jsonResponse["cover_image"]! as! String
        }
        
        if jsonResponse.keys.contains("title") == true {
            contactDetail.title = jsonResponse["title"]! as! String
        }
        
        if jsonResponse.keys.contains("company") == true {
            contactDetail.company = jsonResponse["company"]! as! String
        }
        
        if jsonResponse.keys.contains("school") == true {
            contactDetail.school = jsonResponse["school"]! as! String
        }
        
        if jsonResponse.keys.contains("second_school") == true {
            contactDetail.secondSchool = jsonResponse["second_school"]! as! String
        }
        
        if jsonResponse.keys.contains("email") == true {
            let email = jsonResponse["email"]! as! String
            if email.characters.count > 0 {
                contactDetail.detailUrls.append(DetailUrl(urlName: "email", urlValue: email))
            }
        }
        
        if jsonResponse.keys.contains("phone") == true {
            let phone = jsonResponse["phone"]! as! String
            if phone.characters.count > 0 {
                contactDetail.detailUrls.append(DetailUrl(urlName: "phone", urlValue: phone))
            }
        }
        
        if jsonResponse.keys.contains("facebook_url") == true {
            let url = jsonResponse["facebook_url"]! as! String
            if url.characters.count > 0 {
                contactDetail.detailUrls.append(DetailUrl(urlName: "facebook", urlValue: url))
            }
        }
        
        if jsonResponse.keys.contains("twitter_url") == true {
            let url = jsonResponse["twitter_url"]! as! String
            if url.characters.count > 0 {
                contactDetail.detailUrls.append(DetailUrl(urlName: "twitter", urlValue: url))
            }
        }
        
        if jsonResponse.keys.contains("google_url") == true {
            let url = jsonResponse["google_url"]! as! String
            if url.characters.count > 0 {
                contactDetail.detailUrls.append(DetailUrl(urlName: "google", urlValue: url))
            }
        }
        
        if jsonResponse.keys.contains("tumlbr_url") == true {
            let url = jsonResponse["tumlbr_url"]! as! String
            if url.characters.count > 0 {
                contactDetail.detailUrls.append(DetailUrl(urlName: "tumlbr", urlValue: url))
            }
        }
        
        if jsonResponse.keys.contains("instagram_url") == true {
            let url = jsonResponse["instagram_url"]! as! String
            if url.characters.count > 0 {
                contactDetail.detailUrls.append(DetailUrl(urlName: "instagram", urlValue: url))
            }
        }
        
        if jsonResponse.keys.contains("linkedin_url") == true {
            let url = jsonResponse["linkedin_url"]! as! String
            if url.characters.count > 0 {
                contactDetail.detailUrls.append(DetailUrl(urlName: "linkedin", urlValue: url))
            }
        }
        
        if jsonResponse.keys.contains("snapchat_url") == true {
            let url = jsonResponse["snapchat_url"]! as! String
            if url.characters.count > 0 {
                contactDetail.detailUrls.append(DetailUrl(urlName: "snapchat", urlValue: url))
            }
        }
        
        if jsonResponse.keys.contains("personal_statement") == true {
            contactDetail.personalStmt = jsonResponse["personal_statement"]! as! String
        }
        
        
        
        return contactDetail
        
    }
    
}
