//
//  TwitterDataLoader.swift
//  AirFive
//
//  Created by Anil Gautam on 18/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class TwitterDataLoader : NSObject {
    
    let consumerKey = "dfIxTeEUEDUidYLKInrBodn4P"
    let consumerSecret = "ChTUzmlyJpAXRkTEONnHTzbhWL689CIInOOQWihgJP8gh4mg1F"
    
    let googlePlusOAuth = "265969896159-ipupaeb5c6j99oc2f2aiakh1kc28n8fg.apps.googleusercontent.com"
    
    override init() {
        
        super.init()
        FHSTwitterEngine.sharedEngine().permanentlySetConsumerKey(consumerKey, andSecret: consumerSecret)
        
    }
    
    func getProfileLink(viewController:UIViewController, successCallback:(String) -> Void, failureCallback:(String) -> Void) {
        
        if !FHSTwitterEngine.sharedEngine().isAuthorized() {
            
            let loginController = FHSTwitterEngine.sharedEngine().loginControllerWithCompletionHandler({ (success:Bool) in
                
                if success {
                    successCallback("https://twitter.com/" + FHSTwitterEngine.sharedEngine().authenticatedUsername)
                }else {
                    failureCallback("User Canceled")
                }
                
            })
            viewController.presentViewController(loginController, animated: true, completion: nil)
            
        }else {
            successCallback("https://twitter.com/" + FHSTwitterEngine.sharedEngine().authenticatedUsername)
        }
        
    }

}






