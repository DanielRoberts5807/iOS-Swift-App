//
//  DeviceContactLoader.swift
//  AirFive
//
//  Created by Anil Gautam on 21/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation
import AddressBook

class DeviceContactLoader {

    private var addressBookRef: ABAddressBook! = nil
    var deviceContacts = [DeviceContact]()
    
    init() {
        load()
    }
    
    private func load() {
        
        let authorizationStatus = ABAddressBookGetAuthorizationStatus()
        
        switch authorizationStatus {
        case .Denied, .Restricted:
            Helper.showAlert("", message: "Can't get contacts. Kindly allow from settings.")
        case .Authorized:
            loadContacts()
        case .NotDetermined:
            getAccess()
        }
    
    }
    
    private func loadContacts() {
        
        if addressBookRef == nil {
            addressBookRef = ABAddressBookCreateWithOptions(nil, nil).takeRetainedValue()
        }
        
        let allContacts = ABAddressBookCopyArrayOfAllPeople(addressBookRef).takeRetainedValue() as Array
        for record in allContacts {
            
            let contact: ABRecordRef = record
            let deviceContact = DeviceContact()
            
            if ABRecordCopyCompositeName(contact) != nil {
                
                deviceContact.name = ABRecordCopyCompositeName(contact).takeRetainedValue() as String
                
                let phonesRef: ABMultiValueRef = ABRecordCopyValue(contact, kABPersonPhoneProperty).takeRetainedValue() as ABMultiValueRef
                for i:Int in 0 ..< ABMultiValueGetCount(phonesRef) {
                    deviceContact.number = ABMultiValueCopyValueAtIndex(phonesRef, i).takeRetainedValue() as! NSString as String
                    if deviceContact.number.characters.count > 0 {
                        break
                    }
                }
                
                let emailsRef: ABMultiValueRef = ABRecordCopyValue(contact, kABPersonEmailProperty).takeRetainedValue() as ABMultiValueRef
                if(ABMultiValueGetCount(emailsRef) > 0) {
                    deviceContact.email = ABMultiValueCopyValueAtIndex(emailsRef, 0).takeRetainedValue() as! NSString as String
                }
                
                deviceContacts.append(deviceContact)
            }
            
        }
        
    }
    
    private func getAccess() {
        
        if addressBookRef == nil {
            addressBookRef = ABAddressBookCreateWithOptions(nil, nil).takeRetainedValue()
        }
        
        ABAddressBookRequestAccessWithCompletion(addressBookRef) {
            (granted: Bool, error: CFError!) in
            dispatch_async(dispatch_get_main_queue()) {
                if !granted {
                    Helper.showAlert("", message: "Can't get contacts. Kindly allow from settings.")
                } else {
                    self.loadContacts()
                }
            }
        }
        
    }
    
}