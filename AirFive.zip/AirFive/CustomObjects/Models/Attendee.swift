//
//  Attendee.swift
//  AirFive
//
//  Created by Anil Gautam on 12/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

class Attendee {
    
    var id:String = "", name:String = "", profileImg:String = ""
    var invited:Int = -1
    
    init(){
    }
    
    init(id:String, name:String, profileImg:String, invited:Int) {
        self.id = id
        self.name = name
        self.profileImg = profileImg
        self.invited = invited
    }
    
    static func createDummyAttendees() -> [Attendee]{
        
        var attendees:[Attendee] = []
        
        for _ in 0..<5 {
            let a1 = Attendee(id: "123", name: "Amelia Nelson", profileImg: "", invited: -1)
            let a2 = Attendee(id: "123", name: "Jack Meekle", profileImg: "", invited: -1)
            
            attendees.append(a1)
            attendees.append(a2)
        }
        
        return attendees
        
    }
    
    static func makeAttendeesFromJson(jsonResponse:Dictionary<String,AnyObject>) -> [Attendee] {
        
        var attendees:[Attendee] = []
        
        if let attendeesJsonArray = jsonResponse["alumni"] as? Array<AnyObject> {
            for json in attendeesJsonArray {
                let attendeeJson = json as! Dictionary<String,AnyObject>
                let attendee = Attendee()
                
                if attendeeJson.keys.contains("id") == true {
                    attendee.id = attendeeJson["id"]! as! String
                }
                if attendeeJson.keys.contains("name") == true {
                    attendee.name = attendeeJson["name"]! as! String
                }
                if attendeeJson.keys.contains("profile_image") == true {
                    attendee.profileImg = attendeeJson["profile_image"]! as! String
                }
                if attendeeJson.keys.contains("invite_status") == true {
                    attendee.invited = attendeeJson["invite_status"]! as! Int
                }
                attendees.append(attendee)
                
            }
        }
        
        return attendees
        
    }
    
}
