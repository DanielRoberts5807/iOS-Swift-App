//
//  Alumni.swift
//  AirFive
//
//  Created by Anil Gautam on 30/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class Alumni {

    var id = "", name = "", title = "", company = "", profileImg = "", personalStmt = "", isAdmin = false, isAway = false
    
    
    static func makeAlumniAroundFrom(jsonResponse:Dictionary<String,AnyObject>) -> [Alumni] {
        
        var alumniArr:[Alumni] = []
        
        if let alumniJsonArray = jsonResponse["alumni"] as? Array<AnyObject> {
            for json in alumniJsonArray {
                let alumniJson = json as! Dictionary<String,AnyObject>
                let alumni = Alumni()
                
                if alumniJson.keys.contains("name") == true {
                    alumni.name = alumniJson["name"]! as! String
                }
                
                if alumniJson.keys.contains("title") == true {
                    alumni.title = alumniJson["title"]! as! String
                }
                
                if alumniJson.keys.contains("company") == true {
                    alumni.company = alumniJson["company"]! as! String
                }
                
                if alumniJson.keys.contains("profile_image") == true {
                    alumni.profileImg = alumniJson["profile_image"]! as! String
                }
                
                if alumniJson.keys.contains("id") == true {
                    alumni.id = alumniJson["id"]! as! String
                }
                
                if alumniJson.keys.contains("is_admin") == true {
                    alumni.isAdmin = alumniJson["is_admin"]! as! Bool
                }
                
                if alumniJson.keys.contains("is_away") == true {
                    alumni.isAway = alumniJson["is_away"]! as! Bool
                }
                
                if alumniJson.keys.contains("personal_statment") == true {
                    alumni.personalStmt = alumniJson["personal_statment"]! as! String
                }else if alumniJson.keys.contains("personal_statement") == true {
                    alumni.personalStmt = alumniJson["personal_statement"]! as! String
                }
                
                alumniArr.append(alumni)
                
            }
        }
        
        return alumniArr
        
    }
    
}