//
//  APNSHandler.swift
//  AirFive
//
//  Created by Anil Gautam on 13/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation
import UIKit

class APNSHandler : NSObject {
    
    private static var sharedAPNSHandler:APNSHandler! = nil
    
    static func getSharedAPNSHandler() -> APNSHandler {
        if sharedAPNSHandler == nil {
            sharedAPNSHandler = APNSHandler()
        }
        return sharedAPNSHandler
    }
    
    private var notificationPopup:KLCPopup! = nil
    var currentInvitationId:String! = nil
    var eventAlert:UIBlockAlert! = nil
    
    private override init() {
        
    }
    
    func handleAPNS(apns:[NSObject: AnyObject]) {
    
        UIApplication.sharedApplication().applicationIconBadgeNumber = 0
        if let customData = apns["custom data"] as? [NSObject: AnyObject] {
            
            let invitation = customData["invitation"]! as! String
            
            
            if invitation.containsString("info") {
            
                let recieverName = customData["receiver_name"]! as! String
                let foodCaffine = invitation.containsString("bite") ? "food" : "caffeine"
                let invite = invitation.containsString("bite") ? "bite" : "coffee"
                let acceptMsg = "Super duper! " + recieverName + " has agreed to meet for a " + invite + " with you. May the " + foodCaffine + " be with you!"
                showNotificationView(acceptMsg, rejectMsg: nil, invitationId: nil)
                
            }else if invitation.containsString("event") {
                
                let alert = ((apns["aps"]! as! [String:AnyObject])["alert"]! as! [String:AnyObject])["loc-key"]! as! String
                let eventJson = customData["event"]! as! Dictionary<String, AnyObject>
                let event = Event.makeEventFromJson(eventJson)
                eventAlert = UIBlockAlert(title: "", message: alert, cancelButtonTitle: "OK", otherButtonTitle: "Details", callback: { (btnIndex:Int) in
                    if btnIndex != 0 {
                        
                        let delayTime = dispatch_time(DISPATCH_TIME_NOW, Int64(0.5 * Double(NSEC_PER_SEC)))
                        dispatch_after(delayTime, dispatch_get_main_queue()) {
                            let eventInviteViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("EventInviteViewController") as! EventInviteViewController
                            eventInviteViewController.event = event
                            let viewController = Helper.getTopRootViewController()
                            viewController.presentViewController(eventInviteViewController, animated: true, completion: nil)
                        }
                        
                    }
                })
                
            }else {
                
                let senderName = customData["sender_name"]! as! String
                let invitationId = customData["invitation_id"]! as! String
                let foodCaffine = invitation == "bite" ? "food" : "caffeine"
                let acceptMsg = "Super duper! " + senderName + " want a " + invitation + " with you. May the " + foodCaffine + " be with you!"
                let rejectMsg = "I didn't mean to get a " + invitation + " with " + senderName
                showNotificationView(acceptMsg, rejectMsg: rejectMsg, invitationId: invitationId)
                
            }

        }
        
    }
    
    func showNotificationView(acceptMsg:String, rejectMsg:String?, invitationId:String?) {
        
        currentInvitationId = invitationId
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapDissmiss:")
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.5))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        let tapGestureStop = UITapGestureRecognizer(target: self, action: "tapDissmissStop:")
        innerContainer.addGestureRecognizer(tapGestureStop)
        
        let titleLbl = UILabel(frame: CGRect(x: 10, y: 20, width: innerContainer.frame.size.width - 20, height: innerContainer.frame.size.height * 0.4))
        titleLbl.textColor = Helper.getAppBlackColor()
        titleLbl.font = Helper.getBoldFont(18)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.numberOfLines = 0
        titleLbl.text = acceptMsg
        
        innerContainer.addSubview(titleLbl)
        
        tmp = innerContainer.frame.size.width * 0.25
        let acceptBtn = UIBlockButton(frame: CGRect(x: ((innerContainer.frame.size.width - tmp) / 2), y: (titleLbl.frame.origin.y + titleLbl.frame.size.height + 4), width: tmp, height: tmp * 1.14))
        
        tmp = innerContainer.frame.size.width * 0.35
        let handImg = UIImageView(frame:CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        handImg.image = UIImage(named:"hand.gif")
        
        handImg.center = acceptBtn.center
        innerContainer.addSubview(handImg)
        
        innerContainer.addSubview(acceptBtn)
        
        var rejectBtn:UIBlockButton! = nil
        if rejectMsg != nil {
            tmp = innerContainer.frame.size.height * 0.25
            rejectBtn = UIBlockButton(frame: CGRect(x: titleLbl.frame.origin.x, y: (innerContainer.frame.size.height - tmp), width: titleLbl.frame.size.width, height: tmp))
            rejectBtn.setTitleColor(Helper.getAppBlackColor(), forState: UIControlState.Normal)
            rejectBtn.setTitle((rejectMsg!), forState: UIControlState.Normal)
            rejectBtn.titleLabel?.font = Helper.getNormalFont()
            rejectBtn.titleLabel?.textAlignment = NSTextAlignment.Center
            
            innerContainer.addSubview(rejectBtn)
        }
        
        container.addSubview(innerContainer)
        
        tmp = innerContainer.frame.origin.y + innerContainer.frame.size.height
        let bottomContainer = UIView(frame: CGRect(x: innerContainer.frame.origin.x, y: tmp, width: innerContainer.frame.size.width, height: container.frame.size.height - tmp))
        
        tmp = bottomContainer.frame.size.width * 0.2
        let cancelBtn = UIBlockButton(frame: CGRect(x: ((bottomContainer.frame.size.width - tmp) / 2), y: ((bottomContainer.frame.size.height - tmp) / 2), width: tmp, height: tmp))
        cancelBtn.setBackgroundImage(UIImage(named: "notificationClose"), forState: UIControlState.Normal)
        
        
        bottomContainer.addSubview(cancelBtn)
        
        container.addSubview(bottomContainer)
        
        notificationPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: false, dismissOnContentTouch: false)
        notificationPopup.dimmedMaskAlpha = 0.85
        
        acceptBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.notificationPopup.dismissPresentingPopup()
            if invitationId != nil {
                self.respondFeed(invitationId!, response: "1")
            }else {
                self.checkViewController(2)
            }
            
            
        }
        
        if rejectBtn != nil {
            rejectBtn.callback = {(button:UIBlockButton) -> Void in
                
                self.notificationPopup.dismissPresentingPopup()
                if invitationId != nil {
                    self.respondFeed(invitationId!, response: "2")
                }else {
                    self.checkViewController(2)
                }
                
            }
        }
        
        cancelBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.notificationPopup.dismissPresentingPopup()
            if invitationId != nil {
                self.respondFeed(invitationId!, response: "1")
            }else {
                self.checkViewController(2)
            }
            
        }
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        notificationPopup.showWithLayout(layout)
        
    }
    
    func respondFeed(id:String, response:String) {
        
        WebServices.getSharedWebServices().respondFeed(id, response: response, successCallback:   { (message:String) -> Void in
            
//            Helper.showAlert("", message: message)
            self.checkViewController(3)
            
        }, failureCallback: { (message:String) -> Void in
                
            Helper.showAlert("", message: message)
                
        })
        
        
    }
    
    func tapDissmiss(tap:UITapGestureRecognizer) {

        self.notificationPopup.dismissPresentingPopup()
        if currentInvitationId != nil {
            self.respondFeed(currentInvitationId!, response: "1")
        }else {
            self.checkViewController(2)
        }
        
    }
    
    func tapDissmissStop(tap:UITapGestureRecognizer) {
    }
}

extension APNSHandler : UIAlertViewDelegate {

    func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        
        if buttonIndex != alertView.cancelButtonIndex {//Only in case of bite/coffee
           self.performSelector("checkViewController", withObject: nil, afterDelay: 0.5)
        }
        
    }
    
    func checkViewController(menuItemTag:Int) {
        let viewController = Helper.getTopRootViewController()
        if viewController.isKindOfClass(MenuRootViewController.self) {
            openMenuItem(menuItemTag)
        }else {
            viewController.dismissViewControllerAnimated(true, completion: {
                self.openMenuItem(menuItemTag)
            })
        }
    }
    
    func openMenuItem(menuItemTag:Int) {
        let viewController = Helper.getTopRootViewController()
        if viewController.isKindOfClass(MenuRootViewController.self) {
            let menuController = viewController.menuContainerViewController.leftMenuViewController as! MenuViewController
            menuController.openMenuItemWithTag(menuItemTag)
        }
    }
    
    
}



