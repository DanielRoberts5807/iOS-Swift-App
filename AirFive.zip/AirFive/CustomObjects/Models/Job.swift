//
//  Job.swift
//  AirFive
//
//  Created by Muhammad Umair on 6/29/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class Job {
    
    var id = "", title = "", company = "", detail = "", website = "", experience = ""
    
    static func createDummyJobs() -> [Job] {
        
        var jobs:[Job] = []
        for _ in 0..<2 {
            var job = Job()
            job.title = "Title"
            job.company = "Katherine Atcheson asked for coffee"
            job.detail = "https://www.google.com"
            jobs.append(job)
            
            job = Job()
            job.title = "Flora"
            job.company = "Flora accepted for meeting"
            job.detail = "https://www.google.com"
            jobs.append(job)
            
            job = Job()
            job.company = "LA Spartan MSU vs OSU Gamewathch Next Sat 10/12 - Pony T's, Los Angeles"
            job.detail = "https://www.google.com"
            jobs.append(job)
        }
        
        return jobs
    }
    
    static func makeJobsFromJson(jsonResponse:Dictionary<String,AnyObject>) -> [Job] {
        
        var jobs:[Job] = []
        
        if let jobsJsonArray = jsonResponse["jobs"] as? Array<AnyObject> {
            for json in jobsJsonArray {
                let jobJson = json as! Dictionary<String,AnyObject>
                let job = Job()
                
                if jobJson.keys.contains("id") == true {
                    job.id = jobJson["id"]! as! String
                }
                
                if jobJson.keys.contains("job_title") == true {
                    job.title = jobJson["job_title"]! as! String
                }
                
                if jobJson.keys.contains("company") == true {
                    job.company = jobJson["company"]! as! String
                }
                
                if jobJson.keys.contains("job_description") == true {
                    job.detail = jobJson["job_description"]! as! String
                }
                
                if jobJson.keys.contains("website") == true {
                    job.website = jobJson["website"]! as! String
                }
                
                if jobJson.keys.contains("experience_level") == true {
                    job.experience = jobJson["experience_level"]! as! String
                }
                        
                jobs.append(job)
                
            }
        }
        
        return jobs
        
    }
    
}