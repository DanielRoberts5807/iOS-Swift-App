//
//  GooglePlacesLoader.swift
//  AirFive
//
//  Created by Anil Gautam on 16/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation
import GoogleMaps

class GooglePlacesLoader : NSObject {

//    let apiKey = "AIzaSyAYX_v3aq7KPZu4wuskF-uQ6kgH0vzDHG8"
    let apiKey = "AIzaSyCiaf8rlvVTjgUP0JDJTlU0bCQMagyNC8U"
    
    private static var sharedGooglePlacesLoader:GooglePlacesLoader! = nil
    
    static func getSharedGooglePlacesLoader() -> GooglePlacesLoader {
        if sharedGooglePlacesLoader == nil {
            sharedGooglePlacesLoader = GooglePlacesLoader()
        }
        return sharedGooglePlacesLoader
    }
    
    private override init() {
        GMSServices.provideAPIKey(apiKey)
    }
    
    func placeAutocomplete(searchStr:String, successCallback:((places:[String]) -> Void), failureCallback:((message:String) -> Void)) {
        
        let placesClient = GMSPlacesClient()
        
        var bounds:GMSCoordinateBounds? = nil
        if let locationStr = Helper.getValueForKey("userLocation") {
            
            let tokens = (locationStr as! String).componentsSeparatedByString(" ")
            if tokens.count > 1 {
                let userLocation = CLLocationCoordinate2D(latitude: (tokens[0] as NSString).doubleValue, longitude: (tokens[1] as NSString).doubleValue)
                let northEast = locationWithBearing((2 * M_PI - M_PI / 4), distanceMeters: 5000, origin: userLocation)
                let southWest = locationWithBearing((M_PI - M_PI / 4), distanceMeters: 5000, origin: userLocation)
                
                bounds = GMSCoordinateBounds(coordinate: northEast, coordinate: southWest)
            }
            
        }
        
        placesClient.autocompleteQuery(searchStr, bounds: bounds, filter: nil, callback: { (results, error: NSError?) -> Void in
            if error != nil {
                print(error)
                failureCallback(message: (error?.localizedDescription)!)
                return
            }
            
            var places:[String] = []
            for result in results! {
                places.append(result.attributedFullText.string)
                successCallback(places: places)
            }
        })
    }
    
    func locationWithBearing(bearing:Double, distanceMeters:Double, origin:CLLocationCoordinate2D) -> CLLocationCoordinate2D {
        let distRadians = distanceMeters / (6372797.6) // earth radius in meters
        
        let lat1 = origin.latitude * M_PI / 180
        let lon1 = origin.longitude * M_PI / 180
        
        let lat2 = asin(sin(lat1) * cos(distRadians) + cos(lat1) * sin(distRadians) * cos(bearing))
        let lon2 = lon1 + atan2(sin(bearing) * sin(distRadians) * cos(lat1), cos(distRadians) - sin(lat1) * sin(lat2))
        
        return CLLocationCoordinate2D(latitude: lat2 * 180 / M_PI, longitude: lon2 * 180 / M_PI)
    }
    
}