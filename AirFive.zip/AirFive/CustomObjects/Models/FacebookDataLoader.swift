//
//  FacebookDataLoader.swift
//  AirFive
//
//  Created by Anil Gautam on 11/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation
import FBSDKLoginKit
import FBSDKShareKit

class FacebookDataLoader : NSObject {

    let fbLoginManager:FBSDKLoginManager! = FBSDKLoginManager()
    var failureCallback:((String) -> Void)?
    var loginSuccessCallback:(([String:AnyObject]) -> Void)?
    var shareSuccessCallback:((String) -> Void)?
    
    override init() {
    
        super.init()
        failureCallback = nil
        loginSuccessCallback = nil
        shareSuccessCallback = nil
        
    }

    func processLogin(viewController:UIViewController, successCallback:([String:AnyObject]) -> Void, failureCallback:(String) -> Void) {
    
        self.loginSuccessCallback = successCallback
        self.failureCallback = failureCallback
        if FBSDKAccessToken.currentAccessToken() == nil{
            getAccessToken(viewController)
        }else {
            loadUserData()
        }
        
    }
    
    private func getAccessToken(viewController:UIViewController) {
        
        fbLoginManager.logOut()
        fbLoginManager.logInWithReadPermissions(["public_profile", "email", "user_work_history"], fromViewController: viewController, handler: { (result:FBSDKLoginManagerLoginResult!, error:NSError!) -> Void in
            
            if error != nil {
                if self.failureCallback != nil {
                    self.failureCallback!(error.localizedDescription)
                }
            }else if result.isCancelled {
                if self.failureCallback != nil {
                    self.failureCallback!("User Canceled")
                }
            }else {
                self.loadUserData()
            }
            
        })
        
    }
    
    private func loadUserData() {
        
        let request = FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id,name,email,education,work,link,picture.type(large)"])
        request.startWithCompletionHandler { (connection:FBSDKGraphRequestConnection!, result:AnyObject!, error:NSError!) -> Void in
            
            if error != nil {
                if self.failureCallback != nil {
                    self.failureCallback!(error.localizedDescription)
                }
            }else {
                if self.loginSuccessCallback != nil {
                    self.loginSuccessCallback!(result as! [String : AnyObject])
                }
                
            }
            
        }
        
    }
    
    func shareEvent(eventTitle:String, eventDetail:String, viewController:UIViewController, successCallback:((String) -> Void), failureCallback:((String) -> Void)) {
        
        shareSuccessCallback = successCallback
        self.failureCallback = failureCallback
        
        if FBSDKAccessToken.currentAccessToken() == nil {
            
            fbLoginManager.logOut()
            fbLoginManager.logInWithReadPermissions(["public_profile", "email", "user_work_history"], fromViewController: viewController, handler: { (result:FBSDKLoginManagerLoginResult!, error:NSError!) -> Void in
                
                if error != nil {
                    if self.failureCallback != nil {
                        self.failureCallback!(error.localizedDescription)
                    }
                }else if result.isCancelled {
                    if self.failureCallback != nil {
                        self.failureCallback!("User Canceled")
                    }
                }else {
                    self.share(eventTitle, eventDetail: eventDetail, viewController: viewController)
                }
                
            })
            
        }else {
            
            self.share(eventTitle, eventDetail: eventDetail, viewController: viewController)
            
        }
        
    }
    
    func revokePermissions() {
    
        let request = FBSDKGraphRequest(graphPath: "me/permissions", parameters: nil, HTTPMethod: "DELETE")
        request.startWithCompletionHandler { (connection:FBSDKGraphRequestConnection!, result:AnyObject!, error:NSError!) -> Void in
            
            if error != nil {
                print(error)
            }else {
                print(result)
                
            }
            
        }
        
    }
    
    func invite(viewController:UIViewController, applink:String) {
    
        if FBSDKAccessToken.currentAccessToken() == nil {
            
            fbLoginManager.logOut()
            fbLoginManager.logInWithReadPermissions(["public_profile", "email", "user_work_history"], fromViewController: viewController, handler: { (result:FBSDKLoginManagerLoginResult!, error:NSError!) -> Void in
                
                if error != nil {
                    if self.failureCallback != nil {
                        self.failureCallback!(error.localizedDescription)
                    }
                }else if result.isCancelled {
                    if self.failureCallback != nil {
                        self.failureCallback!("User Canceled")
                    }
                }else {
                    self.inviteHelper(viewController, applink: applink)
                }
                
            })
            
        }else {
            
            self.inviteHelper(viewController, applink: applink)
            
        }
        
        
    }
    
    func inviteHelper(viewController:UIViewController, applink:String) {
        
//        let content = FBSDKAppInviteContent()
//        content.appLinkURL = NSURL(string: applink)
//        content.appInvitePreviewImageURL = NSURL(string: applink)
//        content.description = "I just downloaded AirFive - be sure to check it out!"
//        FBSDKAppInviteDialog.showFromViewController(viewController, withContent: content, delegate: nil)
        
        let content = FBSDKShareLinkContent()
        content.contentTitle = "AirFive"
        content.contentDescription = Helper.inviteMsg
        content.contentURL = NSURL(string: Helper.appLink)
        FBSDKShareDialog.showFromViewController(viewController, withContent: content, delegate: nil);
        
    }
    
    private func isMessangerInstalled() -> Bool {
        return UIApplication.sharedApplication().canOpenURL(NSURL(string: "fb://")!)
    }
    
    private func share(eventTitle:String, eventDetail:String, viewController:UIViewController) {
        
        let content = FBSDKShareLinkContent()
        content.contentDescription = Helper.shareMsg
        content.contentTitle = "AirFive"
        content.contentURL = NSURL(string: Helper.appLink)
//        content.imageURL = NSURL(string: "https://www.airfive.com/images/airfive.png")
        
        FBSDKShareDialog.showFromViewController(viewController, withContent: content, delegate: (viewController as! FBSDKSharingDelegate))
        
    }
    
    private func loginWithPublish(eventTitle:String, eventDetail:String, viewController:UIViewController) {
        
        fbLoginManager.logInWithPublishPermissions(["publish_actions"], fromViewController: viewController) { (result:FBSDKLoginManagerLoginResult!, error:NSError!) in
            
            if (error != nil)  {
                if self.failureCallback != nil {
                    self.failureCallback!("Can't share now. Kindly try later.")
                }
            }else {
                self.share(eventTitle, eventDetail: eventDetail, viewController: viewController)
            }
            
        }
    }
    
}






