//
//  Event.swift
//  AirFive
//
//  Created by Anil Gautam on 06/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class Event {
    
    var id:String = "", title:String = "", type:EventType = EventType.Event
    var day:Int = 0, month:Int = 0, year:Int = 0, hour:Int = 0, minute:Int = 0
    var location:String = "", description:String = ""
    var userId:String = ""
    var latitude:Double = 0, longitude:Double = 0
    
    init(){
    }
    
    init(title:String, type:EventType, day:Int, month:Int, year:Int, hour:Int, minute:Int) {
        self.title = title
        self.type = type
        self.day = day
        self.month = month
        self.year = year
        self.hour = hour
        self.minute = minute
    }
    
    init(event:Event) {
        self.id = event.id
        self.title = event.title
        self.type = event.type
        self.day = event.day
        self.month = event.month
        self.year = event.year
        self.hour = event.hour
        self.minute = event.minute
        self.location = event.location
        self.description = event.description
        self.userId = event.userId
        
        self.latitude = event.latitude
        self.longitude = event.longitude
    }
    
    func belongToDate(day:Int, month:Int, year:Int) -> Bool {
        return (self.day == day && self.month == month && self.year == year)
    }
    
    static func createDummyEvents() -> [Event]{
    
        var events:[Event] = []
        
        let e = Event(title: "MSU GAME", type: EventType.Event, day: 6, month: 4, year: 2016, hour: 3, minute: 20)
        let i1 = Event(title: "HIKING", type: EventType.Invite, day: 6, month: 4, year: 2016, hour: 4, minute: 30)
        let i2 = Event(title: "HIKING", type: EventType.Invite, day: 6, month: 4, year: 2016, hour: 4, minute: 30)
        
        let i3 = Event(title: "HIKING", type: EventType.Invite, day: 16, month: 4, year: 2016, hour: 4, minute: 30)
        
        let e2 = Event(title: "MSU GAME", type: EventType.Event, day: 11, month: 5, year: 2016, hour: 13, minute: 20)
        let i4 = Event(title: "HIKING", type: EventType.Invite, day: 11, month: 5, year: 2016, hour: 14, minute: 30)
        
        events.append(e)
        events.append(i1)
        events.append(i2)
        events.append(i3)
        events.append(e2)
        events.append(i4)
        
        return events
        
    }
    
    static func makeEventsFromJson(jsonResponse:Dictionary<String,AnyObject>) -> [Event] {
        
        var events:[Event] = []
        
        if let eventsJsonArray = jsonResponse["events"] as? Array<AnyObject> {
            for json in eventsJsonArray {
                let eventJson = json as! Dictionary<String,AnyObject>
                let event = makeEventFromJson(eventJson)
                
                events.append(event)
                
            }
        }
        
        return events
        
    }
    
    static func makeEventFromJson(eventJson:Dictionary<String,AnyObject>) -> Event {
    
        let event = Event()
        
        if eventJson.keys.contains("_id") == true {
            event.id = eventJson["_id"]! as! String
        }
        if eventJson.keys.contains("event_name") == true {
            event.title = eventJson["event_name"]! as! String
        }
        if eventJson.keys.contains("date_and_time") == true {
            let dateAndTime = eventJson["date_and_time"]! as! String
            
            let tokens = dateAndTime.componentsSeparatedByString(" ")
            if tokens.count > 1 {
                let date = tokens[0]
                let dateTokens = (date as NSString).componentsSeparatedByString("-")
                if dateTokens.count > 2 {
                    event.year = Int(dateTokens[0])!
                    event.month = Int(dateTokens[1])!
                    event.day = Int(dateTokens[2])!
                }
                
                let time = tokens[1]
                let timeTokens = (time as NSString).componentsSeparatedByString(":")
                if timeTokens.count > 1 {
                    event.hour = Int(timeTokens[0])!
                    event.minute = Int(timeTokens[1])!
                }
            }
            
            
        }
        
        if eventJson.keys.contains("place_of_event") == true {
            event.location = eventJson["place_of_event"]! as! String
        }
        
        if eventJson.keys.contains("description") == true {
            event.description = eventJson["description"]! as! String
        }
        
        if eventJson.keys.contains("type") == true {
            event.type = eventJson["type"]! as! String == "event" ? EventType.Event : EventType.Invite
        }else {
            event.type = EventType.Event
        }
        
        if eventJson.keys.contains("user_id") == true {
            event.userId = eventJson["user_id"]! as! String
        }
        
        if eventJson.keys.contains("location") == true {
            let locationJson = eventJson["location"]! as! Dictionary<String,Double>
            event.latitude = locationJson["latitude"]!
            event.longitude = locationJson["longitude"]!
        }
        return event
        
    }
    
}