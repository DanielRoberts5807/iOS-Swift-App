//
//  Contact.swift
//  AirFive
//
//  Created by Anil Gautam on 14/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class Contact {
    
    var id:String = "", name:String = "", profileImage:String = ""
    
    init(){
    }
    
    init(id:String, name:String, profileImage:String) {
        self.id = id
        self.name = name
        self.profileImage = profileImage
    }
    
    static func createDummyContacts() -> [Contact]{
        
        var contacts:[Contact] = []
        
        for _ in 0..<16 {
        
            let c1 = Contact(id: "1", name: "LILY RICHARDS", profileImage: "")
            contacts.append(c1)
            
            let c2 = Contact(id: "1", name: "ERIC ERIKSON", profileImage: "")
            contacts.append(c2)
            
        }
        
        return contacts
        
    }
    
    static func makeContactsFromJson(jsonResponse:Dictionary<String,AnyObject>) -> [Contact] {
        
        var contacts:[Contact] = []
        
        if let contactsJsonArray = jsonResponse["contacts"] as? Array<AnyObject> {
            for json in contactsJsonArray {
                let contactJson = json as! Dictionary<String,String>
                let contact = Contact()
                
                if contactJson.keys.contains("id") == true {
                    contact.id = contactJson["id"]!
                }
                
                if contactJson.keys.contains("name") == true {
                    contact.name = contactJson["name"]!
                }
                
                if contactJson.keys.contains("profile_image") == true {
                    contact.profileImage = contactJson["profile_image"]!
                }
                
                contacts.append(contact)
                
            }
        }
        
        contacts = contacts.sort { (contact1:Contact, contact2:Contact) -> Bool in
            return contact1.name < contact2.name
        }
        
        return contacts
        
    }
    
}
