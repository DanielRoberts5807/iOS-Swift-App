//
//  SchoolsData.swift
//  AirFive
//
//  Created by Anil Gautam on 11/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class SchoolsData {
    
    private static var sharedSchoolsData:SchoolsData! = nil
    var allSchools:[String]
    
    static func getSharedSchoolsData() -> SchoolsData {
        if sharedSchoolsData == nil {
            sharedSchoolsData = SchoolsData()
        }
        return sharedSchoolsData
    }
    
    private init() {
        
        allSchools = []
        loadSchoolsData()
        
    }
    
    private func loadSchoolsData() {
    
        let filePath = NSBundle.mainBundle().pathForResource("CollegesDB", ofType: "txt")
        
        var fileContent:String?
        do {
            try fileContent = String(contentsOfFile: filePath!)
        }catch {
        }
        if fileContent != nil {
            
            let tokens = fileContent?.componentsSeparatedByString("\n")
            for token in tokens! {
                var schoolName = token.stringByReplacingOccurrencesOfString("\"", withString: "")
                schoolName = schoolName.stringByReplacingOccurrencesOfString("\t", withString: "")
                schoolName = schoolName.stringByReplacingOccurrencesOfString("\r", withString: "")
                allSchools.append(schoolName)
            }
            
        }
        
    }
}
