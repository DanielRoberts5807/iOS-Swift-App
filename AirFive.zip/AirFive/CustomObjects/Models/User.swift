//
//  User.swift
//  AirFive
//
//  Created by Anil Gautam on 15/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class User {
    
    private static var sharedUser:User! = nil
    
    static func getSharedUser() -> User {
        if sharedUser == nil {
            sharedUser = User()
        }
        return sharedUser
    }
    
    
    var name:String = "", title:String = "", company:String = "", school:String = "", secondSchool:String = "", password:String = "", personalStmt = ""
    var profileImgUrl:String = "", coverImgUrl:String = "", email:String = "", phone:String = ""
    var eventsCount = 0
    var emailPreference = true, phonePreference = true
    var profileImgLocal:String = "", coverImgLocal:String = ""
    var activityContentCount = 0, activityEventCount = 0, activityCoffeeCount = 0, activityBiteCount = 0
    
    private init(){
        reset()
    }
    
    func loadUserFromJson(jsonResponse:Dictionary<String,AnyObject>) {
        
        reset()
        if jsonResponse.keys.contains("username") == true {
            name = jsonResponse["username"]! as! String
        }
        
        if jsonResponse.keys.contains("password") == true {
            password = jsonResponse["password"]! as! String
        }
        
        if jsonResponse.keys.contains("title") == true {
            title = jsonResponse["title"]! as! String
        }
        
        if jsonResponse.keys.contains("company") == true {
            company = jsonResponse["company"]! as! String
        }
        
        if jsonResponse.keys.contains("school") == true && (jsonResponse["school"] as? String != nil) {
            school = jsonResponse["school"]! as! String
        }
        if jsonResponse.keys.contains("second_school") == true && (jsonResponse["second_school"] as? String != nil) {
            secondSchool = jsonResponse["second_school"]! as! String
        }
        
        if jsonResponse.keys.contains("personal_statement") == true {
            personalStmt = jsonResponse["personal_statement"]! as! String
        }
        
        if jsonResponse.keys.contains("profile_thumb") == true {
            profileImgUrl = jsonResponse["profile_thumb"]! as! String
        }
        
        if jsonResponse.keys.contains("cover") == true {
            coverImgUrl = jsonResponse["cover"]! as! String
        }
        
        if jsonResponse.keys.contains("email") == true {
            email = jsonResponse["email"]! as! String
        }
        
        if jsonResponse.keys.contains("phone_number") == true {
            phone = jsonResponse["phone_number"]! as! String
        }
        
        if jsonResponse.keys.contains("coffee_count") == true {
            activityCoffeeCount  = jsonResponse["coffee_count"]! as! Int
        }
        
        if jsonResponse.keys.contains("bite_count") == true {
            activityBiteCount  = jsonResponse["bite_count"]! as! Int
        }
        
        if jsonResponse.keys.contains("content_count") == true {
            activityContentCount = jsonResponse["content_count"]! as! Int
        }
        
        if jsonResponse.keys.contains("event_count") == true {
            activityEventCount = jsonResponse["event_count"]! as! Int
        }
        
        if jsonResponse.keys.contains("eventsCount") == true {
            eventsCount = jsonResponse["eventsCount"]! as! Int
        }
        
        if jsonResponse.keys.contains("emailPreference") == true {
            emailPreference = (jsonResponse["emailPreference"]! as! NSString).boolValue
        }
        
        if jsonResponse.keys.contains("phonePreference") == true {
            phonePreference = (jsonResponse["phonePreference"]! as! NSString).boolValue
        }
        
        saveLocal()
        
    }
    
    func reset() {
        name = ""
        title = ""
        company = ""
        school = ""
        secondSchool = ""
        password = ""
        personalStmt = ""
        profileImgUrl = ""
        coverImgUrl = ""
        email = ""
        phone = ""
        activityContentCount = 0
        activityEventCount = 0
        activityCoffeeCount = 0
        activityBiteCount = 0
        eventsCount = 0
        emailPreference = true
        phonePreference = true
        profileImgLocal = ""
        coverImgLocal = ""
    }
    
    func setActivityCounts(contentCount:Int, eventCount:Int, coffeeCount:Int, biteCount:Int) {
        activityContentCount = contentCount
        activityEventCount = eventCount
        activityCoffeeCount = coffeeCount
        activityBiteCount = biteCount
        
        let userDefaults = NSUserDefaults.standardUserDefaults()
        userDefaults.setObject(activityContentCount, forKey: "activityContentCount")
        userDefaults.setObject(activityEventCount, forKey: "activityEventCount")
        userDefaults.setObject(activityCoffeeCount, forKey: "activityCoffeeCount")
        userDefaults.setObject(activityBiteCount, forKey: "activityBiteCount")
        
        userDefaults.synchronize()
    }
    
    func saveLocal() {
    
        let userDefaults = NSUserDefaults.standardUserDefaults()
        userDefaults.setObject(name, forKey: "name")
        userDefaults.setObject(title, forKey: "title")
        userDefaults.setObject(company, forKey: "company")
        userDefaults.setObject(school, forKey: "school")
        userDefaults.setObject(secondSchool, forKey: "secondSchool")
        userDefaults.setObject(password, forKey: "password")
        userDefaults.setObject(personalStmt, forKey: "personalStmt")
        
        userDefaults.setObject(profileImgUrl, forKey: "profileImgUrl")
        userDefaults.setObject(coverImgUrl, forKey: "coverImgUrl")
        userDefaults.setObject(email, forKey: "email")
        userDefaults.setObject(phone, forKey: "phone")
        
        userDefaults.setObject(activityContentCount, forKey: "activityContentCount")
        userDefaults.setObject(activityEventCount, forKey: "activityEventCount")
        userDefaults.setObject(activityCoffeeCount, forKey: "activityCoffeeCount")
        userDefaults.setObject(activityBiteCount, forKey: "activityBiteCount")
        
        userDefaults.setObject(emailPreference, forKey: "emailPreference")
        userDefaults.setObject(phonePreference, forKey: "phonePreference")
        
        userDefaults.synchronize()
        
        if profileImgUrl.characters.count > 0 {
            WebServices.getSharedWebServices().getImage(profileImgUrl, successCallback: { (img:UIImage) -> Void in
                let path = self.getImgPath("profileImg.png")
                self.saveImgLocally(img, path: path)
                self.profileImgLocal = path
            }, failureCallback:  { (message:String) -> Void in
                print(message)
            })
        }
        
        if coverImgUrl.characters.count > 0 {
            WebServices.getSharedWebServices().getImage(coverImgUrl, successCallback: { (img:UIImage) -> Void in
                let path = self.getImgPath("coverImg.png")
                self.saveImgLocally(img, path: path)
                self.coverImgLocal = path
            }, failureCallback:  { (message:String) -> Void in
                print(message)
            })
        }
        
        
    }
    
    func loadLocal() {
        
        let userDefaults = NSUserDefaults.standardUserDefaults()
        if let str = userDefaults.objectForKey("name") as? String {
            name = str
        }
        if let str = userDefaults.objectForKey("title") as? String {
            title = str
        }
        if let str = userDefaults.objectForKey("company") as? String {
            company = str
        }
        if let str = userDefaults.objectForKey("school") as? String {
            school = str
        }
        if let str = userDefaults.objectForKey("secondSchool") as? String {
            secondSchool = str
        }
        if let str = userDefaults.objectForKey("password") as? String {
            password = str
        }
        if let str = userDefaults.objectForKey("personalStmt") as? String {
            personalStmt = str
        }
        
        
        if let str = userDefaults.objectForKey("profileImgUrl") as? String {
            profileImgUrl = str
        }
        if let str = userDefaults.objectForKey("coverImgUrl") as? String {
            coverImgUrl = str
        }
        if let str = userDefaults.objectForKey("email") as? String {
            email = str
        }
        if let str = userDefaults.objectForKey("phone") as? String {
            phone = str
        }
        
        if let count = userDefaults.objectForKey("activityCoffeeCount") as? Int {
            activityCoffeeCount = count
        }
        
        if let count = userDefaults.objectForKey("activityBiteCount") as? Int {
            activityBiteCount = count
        }
        
        if let count = userDefaults.objectForKey("activityContentCount") as? Int {
            activityContentCount = count
        }
        
        if let count = userDefaults.objectForKey("activityEventCount") as? Int {
            activityEventCount = count
        }
        
        if let str = userDefaults.objectForKey("emailPreference") as? Bool {
            emailPreference = str
        }
        if let str = userDefaults.objectForKey("phonePreference") as? Bool {
            phonePreference = str
        }
        
        if profileImgUrl.characters.count > 0 {
            profileImgLocal = getImgPath("profileImg.png")
        }
        
        if coverImgUrl.characters.count > 0 {
            coverImgLocal = getImgPath("coverImg.png")
        }
        
        
    }
    
    func getImgPath(imageName:String) -> String {
        
        let documentsURL = NSFileManager.defaultManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask)[0]
        let fileURL = documentsURL.URLByAppendingPathComponent(imageName)
        return fileURL.path!
        
    }
    
    func saveImgLocally(img:UIImage, path:String) {
    
        let image = rotateImage(img)
        let pngImageData = UIImagePNGRepresentation(image)
        pngImageData!.writeToFile(path, atomically: true)
        
    }
    
    func rotateImage(image: UIImage) -> UIImage {
        
        if (image.imageOrientation == UIImageOrientation.Up ) {
            return image
        }
        
        UIGraphicsBeginImageContext(image.size)
        
        image.drawInRect(CGRect(origin: CGPoint.zero, size: image.size))
        let copy = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        return copy
    }
    
    func dummy() {
        name = "Samantha Ayrton"
        title = "Baby Sitter"
        company = "AirFive"
        school = "Michian State"
        secondSchool = "University Of South Cal"
    }
}


