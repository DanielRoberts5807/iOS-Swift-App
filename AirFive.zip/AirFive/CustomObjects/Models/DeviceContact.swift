//
//  DeviceContact.swift
//  AirFive
//
//  Created by Anil Gautam on 22/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class DeviceContact {

    var name:String = "", number:String = "", email:String = ""
    var invited:Int = -1
    var selectedForInvite:Bool = false
    
}