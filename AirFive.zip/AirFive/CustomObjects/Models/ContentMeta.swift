//
//  ContentMeta.swift
//  AirFive
//
//  Created by Anil Gautam on 5/11/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class ContentMeta {

    var id = "", title = "", desc = "", url = "", imgUrl = ""
    
    static func makeContentMetaFromJson(jsonResponse:Dictionary<String,AnyObject>) -> ContentMeta {
        
        let contentMeta = ContentMeta()
        
        if let contentMetaJson = jsonResponse["meta"] as? Dictionary<String,AnyObject> {
            
            if contentMetaJson.keys.contains("title") == true {
                contentMeta.title = contentMetaJson["title"]! as! String
            }
            
            if contentMetaJson.keys.contains("description") == true {
                contentMeta.desc = contentMetaJson["description"]! as! String
            }
            if contentMetaJson.keys.contains("url") == true {
                contentMeta.url = contentMetaJson["url"]! as! String
            }
            
            if contentMetaJson.keys.contains("image_url") == true {
                contentMeta.imgUrl = contentMetaJson["image_url"]! as! String
            }
            
        }
        
        return contentMeta
        
    }
    
}