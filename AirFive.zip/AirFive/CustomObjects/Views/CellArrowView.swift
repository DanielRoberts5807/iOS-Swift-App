//
//  CellArrowView.swift
//  AirFive
//
//  Created by Anil Gautam on 31/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class CellArrowView : UIView {
    
    var arrowImgs:[UIImageView] = []
    var animationXDelta:CGFloat = 0
    var forward = true
    var isFirstTime = true
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initView()
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        initView()
    }
    
    func initView() {
        
        clipsToBounds = true
        let height = frame.size.height, width = frame.size.height * 0.65
        for _ in 0..<3 {
            
            let arrowImg = UIImageView(frame: CGRect(x: -width, y: 0, width: width, height: height))
            arrowImg.image = UIImage(named: "greenFadeArrow")
            arrowImgs.append(arrowImg)
            addSubview(arrowImg)
            
        }
        
    }
    
    func setForwardDirection(forward:Bool) {
        
        self.forward = forward
        let angle = forward ? 0 : -1 * M_PI
        for arrowImg in arrowImgs {
            arrowImg.transform = CGAffineTransformMakeRotation(CGFloat(angle))
        }        
        animationXDelta = forward ? frame.size.width : -1 * frame.size.width
        setDefaultX()
        
    }
    
    func setDefaultX() {
    
        var width:CGFloat = 5
        if arrowImgs.count > 0 {
            width += frame.size.height * 0.65
        }
        
        var x:CGFloat = 0
        if forward {
            x = frame.size.width - (width * CGFloat(arrowImgs.count)) + (isFirstTime ? 10 : 5)
        }
        for arrowImg in arrowImgs {
            arrowImg.frame.origin.x = x
            x += width
        }
        isFirstTime = false
        
    }
    
    func addAnimations() {
    
        self.layer.removeAllAnimations()
        var delay:Double = 0.3
        for arrowImg in arrowImgs {
            arrowImg.alpha = 0
            arrowImg.frame.origin.x = forward ? -1 * arrowImg.frame.size.width : -1 * animationXDelta
            UIView.animateWithDuration(1.6, delay: delay, options: [UIViewAnimationOptions.CurveEaseInOut, UIViewAnimationOptions.Repeat], animations: { () -> Void in
                arrowImg.frame.origin.x += self.animationXDelta
                arrowImg.alpha = 1
                }, completion: nil)
            delay += 0.4
        }
        
    }
    
    func removeAnimations() {
        for arrowImg in arrowImgs {
            arrowImg.layer.removeAllAnimations()
        }
        setDefaultX()
    }

}
