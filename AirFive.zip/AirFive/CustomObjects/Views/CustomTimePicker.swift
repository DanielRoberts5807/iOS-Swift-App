//
//  CustomTimePicker.swift
//  AirFive
//
//  Created by Anil Gautam on 05/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//


import UIKit

enum TimeComponentType : Int {
    case Hour = 0
    case Minute = 1
    case Half = 2
}

class CustomTimePicker : UIView {
    
    var hour = 0
    var minute = 0
    var half = 0
    
    
    var timeChangeCallback:((Int,Int)->())! = nil
    
    private var pickerView:UIPickerView! = nil
    private var calendar:NSCalendar! = nil
    
    var hours:[String]! = nil
    var minutes:[String]! = nil
    var halfs:[String]! = nil
    
    let multiplier = 20000
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        commonInit()
    }
    
    func commonInit() {
        
        hours = []
        hours.append("12")
        for i in 1..<12 {
            hours.append(String(format:"%02d",i))
        }
        
        minutes = []
        for i in 0..<60 {
            minutes.append(String(format:"%02d",i))
        }
        
        halfs = ["AM", "PM"]
        
        pickerView = UIPickerView(frame: CGRect(x: 0, y: 0, width: UIScreen.mainScreen().bounds.size.width - 40, height: frame.size.height))
        pickerView.delegate = self
        pickerView.dataSource = self
        
        let calendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)!
        let components = calendar.components([NSCalendarUnit.Hour, NSCalendarUnit.Minute], fromDate: NSDate())
        hour = (components.hour % 12)
        minute = components.minute
        half = (components.hour / 12) % halfs.count
        
        setPickerTime(true)
        
        self.addSubview(pickerView)
        
    }
    
}

extension CustomTimePicker : UIPickerViewDelegate, UIPickerViewDataSource {
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch component{
        case TimeComponentType.Hour.rawValue: return hours.count * multiplier
        case TimeComponentType.Minute.rawValue: return minutes.count * multiplier
        case TimeComponentType.Half.rawValue: return halfs.count
        default: return 0
        }
    }
    
    func pickerView(pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusingView view: UIView?) -> UIView {
        
        var width = Int()
        switch component {
        case TimeComponentType.Hour.rawValue: width = Int(self.pickerView.frame.size.width / 3)
        case TimeComponentType.Minute.rawValue: width = Int(self.pickerView.frame.size.width / 3)
        case TimeComponentType.Half.rawValue: width = Int(self.pickerView.frame.size.width / 3)
        default: break
        }
        let lbl = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: 30))
        lbl.textColor = Helper.getAppGreenColor()
        lbl.font = Helper.getNormalFont(16)
        
        if component == 0 { //hours
            lbl.text = hours[row % hours.count]
            lbl.textAlignment = NSTextAlignment.Right
        }else if component == 1 {//minutes
            lbl.text = minutes[row % minutes.count]
            lbl.textAlignment = NSTextAlignment.Center
        }else if component == 2 {//half
            lbl.text = halfs[row % halfs.count]
            lbl.textAlignment = NSTextAlignment.Left
        }
        return lbl
        
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 3
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == TimeComponentType.Hour.rawValue {
            hour = (row % hours.count)
        }
        
        if component == TimeComponentType.Minute.rawValue {
            minute = (row % minutes.count)
        }
        
        if component == TimeComponentType.Half.rawValue {
            half = (row % halfs.count)
        }
        
        setPickerTime(false)
        
        if timeChangeCallback != nil {
            timeChangeCallback(hour,minute)
        }
        
    }
    
    func setPickerTime(animated:Bool) {
        
        let hourRow = (multiplier / 2 * hours.count) + hour
        pickerView.selectRow(hourRow, inComponent: 0, animated: animated)
        
        let minuteRow = (multiplier / 2 * minutes.count) + minute
        pickerView.selectRow(minuteRow, inComponent: 1, animated: animated)
        
        pickerView.selectRow(half, inComponent: 2, animated: animated)
        
    }
    
}

