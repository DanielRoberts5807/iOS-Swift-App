//
//  CustomDatePicker.swift
//  AirFive
//
//  Created by Anil Gautam on 05/04/2016.
//  Copyright © 2016 AirFie. All rights reserved.
//

import UIKit

enum DateComponentType : Int {
    case Month = 0
    case Day = 1
    case Year = 2
}

class CustomDatePicker : UIView {

    var minDate = NSDate(timeIntervalSince1970: 0)
    var maxDate = NSDate(timeIntervalSinceNow: 10 * 265 * 24 * 3600)
    var date = NSDate()
    
    var dateChangeCallback:((NSDate)->())! = nil
    
    private var pickerView:UIPickerView! = nil
    private var calendar:NSCalendar! = nil
    
    private var months:[String]! = nil
    private var days:[String]! = nil
    private var years:[String]! = nil
    
    let multiplier = 20000
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        commonInit()
    }
    
    func commonInit() {

        calendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)
        
        months = NSDateFormatter().monthSymbols
        days = []
        for i in 1..<32 {
            days.append(String(i))
        }
        
        let minYear = calendar.components(NSCalendarUnit.Year, fromDate: minDate).year
        let maxYear = calendar.components(NSCalendarUnit.Year, fromDate: maxDate).year
        
        years = []
        for year in minYear...maxYear {
            years.append(String(year))
        }
        
        pickerView = UIPickerView(frame: CGRect(x: 0, y: 0, width: UIScreen.mainScreen().bounds.size.width - 40, height: frame.size.height))
        pickerView.delegate = self
        pickerView.dataSource = self
        
        setPickerDate(true)
        
        self.addSubview(pickerView)
        
    }
    
}

extension CustomDatePicker : UIPickerViewDelegate, UIPickerViewDataSource {

    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch component{
        case DateComponentType.Month.rawValue: return months.count * multiplier
        case DateComponentType.Day.rawValue: return days.count * multiplier
        case DateComponentType.Year.rawValue: return years.count * multiplier
        default: return 0
        }
    }
    
    func pickerView(pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusingView view: UIView?) -> UIView {
        
        var width = Int()
        switch component {
        case DateComponentType.Month.rawValue: width = Int(self.pickerView.frame.size.width / 3)
        case DateComponentType.Day.rawValue: width = Int(self.pickerView.frame.size.width / 3)
        case DateComponentType.Year.rawValue: width = Int(self.pickerView.frame.size.width / 3)
        default: break
        }
        let lbl = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: 30))
        lbl.textColor = Helper.getAppGreenColor()
        lbl.font = Helper.getNormalFont(16)

        if component == 0 { //month
            lbl.text = months[row % months.count]
            lbl.textAlignment = NSTextAlignment.Right
        }else if component == 1 {//day
            lbl.text = days[row % days.count]
            lbl.textAlignment = NSTextAlignment.Center
        }else {//year
            lbl.text = years[row % years.count]
            lbl.textAlignment = NSTextAlignment.Left
        }
        return lbl
        
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 3
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let dateComp = calendar.components([NSCalendarUnit.Year, NSCalendarUnit.Month, NSCalendarUnit.Day], fromDate: date)
        if component == DateComponentType.Month.rawValue {
            dateComp.month = (row % months.count) + 1
        }
        
        var day = dateComp.day
        if component == DateComponentType.Day.rawValue {
            day = (row % days.count) + 1
        }
        dateComp.day = 1
        
        let maxDays = numberOfDays(calendar.dateFromComponents(dateComp)!)
        if day > maxDays {
            day = maxDays
        }
        dateComp.day = day
        
        if component == DateComponentType.Year.rawValue {
            dateComp.year = Int(years[row % years.count])!
        }
        
        date = calendar.dateFromComponents(dateComp)!
        setPickerDate(false)
        
        if dateChangeCallback != nil {
            dateChangeCallback(date)
        }
        
    }
    
    func setPickerDate(animated:Bool) {
        
        let dateComp = calendar.components([NSCalendarUnit.Year, NSCalendarUnit.Month, NSCalendarUnit.Day], fromDate: date)
        let dayRow = (multiplier / 2 * days.count) + dateComp.day - 1
        pickerView.selectRow(dayRow, inComponent: 1, animated: animated)
        
        let monthRow = (multiplier / 2 * months.count) + dateComp.month - 1
        pickerView.selectRow(monthRow, inComponent: 0, animated: animated)
        
        let yearRow = (multiplier / 2 * years.count) + indexOfYear(dateComp.year)
        pickerView.selectRow(yearRow, inComponent: 2, animated: animated)
        
    }
    
    func indexOfYear(searchYear:Int) -> Int {
        for i in 0..<years.count {
            if years[i] == String(searchYear) {
                return i
            }
        }
        return 0
    }
    
    func numberOfDays(tmpDate:NSDate) -> Int {
        return calendar.rangeOfUnit(NSCalendarUnit.Day, inUnit: NSCalendarUnit.Month, forDate: tmpDate).length
    }
    
    
}
