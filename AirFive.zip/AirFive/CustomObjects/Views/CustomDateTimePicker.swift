//
//  CustomDateTimePicker.swift
//  AirFive
//
//  Created by Anil Gautam on 5/16/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

enum DateTimeComponentType : Int {
    case Day = 0
    case Hour = 1
    case Minute = 2
    case Half = 3
}

class CustomDateTimePicker : UIView {
    
    private static var sharedDateTimePicker:CustomDateTimePicker! = nil
    public static func getSharedDateTimePicker(frame:CGRect) -> CustomDateTimePicker {
        if sharedDateTimePicker == nil {
            sharedDateTimePicker = CustomDateTimePicker(frame: frame)
        }
        return sharedDateTimePicker
    }
    
    var minDay = NSDate(timeIntervalSinceNow: -182 * 86400)
    var maxDay = NSDate(timeIntervalSinceNow: 182 * 86400)
    var date = NSDate()
    
    var days:[String]! = nil
    var hours:[String]! = nil
    var minutes:[String]! = nil
    var halfs:[String]! = nil
    var half = 0
    
    private var pickerView:UIPickerView! = nil
    private var calendar:NSCalendar! = nil
    var dateFormatter:NSDateFormatter! = nil
    
    let multiplier = 10
    
    private override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        commonInit()
    }
    
    func commonInit() {
        
        calendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)
        
        dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "EE dd MMM";
        
        days = []
        var timeStamp = minDay.timeIntervalSince1970
        while(timeStamp <= maxDay.timeIntervalSince1970) {
            days.append(dateFormatter.stringFromDate(NSDate(timeIntervalSince1970: timeStamp)))
            timeStamp += 86400
        }
        
        hours = []
        hours.append("12")
        for i in 1..<12 {
            hours.append(String(format:"%02d",i))
        }
        
        minutes = []
        for i in 0..<60 {
            minutes.append(String(format:"%02d",i))
        }
        
        halfs = ["AM", "PM"]
        
        pickerView = UIPickerView(frame: CGRect(x: 0, y: 0, width: UIScreen.mainScreen().bounds.size.width - 40, height: frame.size.height))
        pickerView.delegate = self
        pickerView.dataSource = self
        
        setPickerDate(true)
        
        self.addSubview(pickerView)
        
    }
    
}

extension CustomDateTimePicker : UIPickerViewDelegate, UIPickerViewDataSource {
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch component{
        case DateTimeComponentType.Day.rawValue: return days.count
        case DateTimeComponentType.Hour.rawValue: return hours.count * multiplier
        case DateTimeComponentType.Minute.rawValue: return minutes.count * multiplier
        case DateTimeComponentType.Half.rawValue: return halfs.count
        default: return 0
        }
    }
    
    func pickerView(pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusingView view: UIView?) -> UIView {
        
        var width = Int()
        switch component {
        case DateTimeComponentType.Day.rawValue: width = Int(self.pickerView.frame.size.width * 0.4)
        case DateTimeComponentType.Hour.rawValue: width = Int(self.pickerView.frame.size.width * 0.15)
        case DateTimeComponentType.Minute.rawValue: width = Int(self.pickerView.frame.size.width * 0.15)
        case DateTimeComponentType.Half.rawValue: width = Int(self.pickerView.frame.size.width * 0.25)
        default: break
        }
        
        let lbl = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: 30))
        lbl.textColor = Helper.getAppGreenColor()
        lbl.font = Helper.getNormalFont(16)
        
        if component == DateTimeComponentType.Day.rawValue {
            
            lbl.text = days[row % days.count]
            lbl.textAlignment = NSTextAlignment.Right
            
        }else if component == DateTimeComponentType.Hour.rawValue {
            
            lbl.text = hours[row % hours.count]
            lbl.textAlignment = NSTextAlignment.Center
            
        }else if component == DateTimeComponentType.Minute.rawValue {
            
            lbl.text = minutes[row % minutes.count]
            lbl.textAlignment = NSTextAlignment.Center
            
        }else {
            
            lbl.text = halfs[row % halfs.count]
            lbl.textAlignment = NSTextAlignment.Left
            
        }
        return lbl
        
    }
    
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 4
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let dateComp = calendar.components([NSCalendarUnit.Year, NSCalendarUnit.Month, NSCalendarUnit.Day, NSCalendarUnit.Hour, NSCalendarUnit.Minute], fromDate: date)
        
        if component == DateTimeComponentType.Day.rawValue {
            
            let timeStamp = minDay.timeIntervalSince1970 + Double(row % days.count) * 86400.0
            
            let date = NSDate(timeIntervalSince1970:timeStamp)
            let newDateComp = calendar.components([NSCalendarUnit.Year, NSCalendarUnit.Month, NSCalendarUnit.Day], fromDate: date)
            dateComp.year = newDateComp.year
            dateComp.month = newDateComp.month
            dateComp.day = newDateComp.day
        }
        
        if component == DateTimeComponentType.Hour.rawValue {
            dateComp.hour = (row % hours.count) + (half * 12)
        }
        
        if component == DateTimeComponentType.Minute.rawValue {
            dateComp.minute = (row % minutes.count)
        }
        
        if component == DateTimeComponentType.Half.rawValue {
            half = (row % halfs.count)
            dateComp.hour = (dateComp.hour % 12) + (half * 12)
        }
        
        date = calendar.dateFromComponents(dateComp)!
        setPickerDate(false)
        
    }
    
    func pickerView(pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        var width = self.pickerView.frame.size.width / 6
        switch component {
        case DateTimeComponentType.Day.rawValue: width = self.pickerView.frame.size.width * 0.45
        case DateTimeComponentType.Hour.rawValue: width = self.pickerView.frame.size.width * 0.15
        case DateTimeComponentType.Minute.rawValue: width = self.pickerView.frame.size.width * 0.15
        case DateTimeComponentType.Half.rawValue: width = self.pickerView.frame.size.width * 0.25
        default: break
        }
        return width
    }
    
    func setPickerDate(animated:Bool) {
        
        let dateComp = calendar.components([NSCalendarUnit.Year, NSCalendarUnit.Month, NSCalendarUnit.Day, NSCalendarUnit.Hour, NSCalendarUnit.Minute], fromDate: date)
        let day = dateFormatter.stringFromDate(date)
        
        let dayRow = indexOfDay(day)
        pickerView.selectRow(dayRow, inComponent: DateTimeComponentType.Day.rawValue, animated: animated)
        
        let half = dateComp.hour / 12
        let hour = dateComp.hour % 12
        let hourRow = (multiplier / 2 * hours.count) + hour
        pickerView.selectRow(hourRow, inComponent: DateTimeComponentType.Hour.rawValue, animated: animated)
        
        let minuteRow = (multiplier / 2 * minutes.count) + dateComp.minute
        pickerView.selectRow(minuteRow, inComponent: DateTimeComponentType.Minute.rawValue, animated: animated)
        
        pickerView.selectRow(half, inComponent: DateTimeComponentType.Half.rawValue, animated: animated)
        
    }
    
    func indexOfDay(searchDay:String) -> Int {
        for i in 0..<days.count {
            if days[i] == searchDay {
                return i
            }
        }
        return 0
    }
    
    func getHourMinute() -> (Int,Int) {
        let dateComp = calendar.components([NSCalendarUnit.Hour, NSCalendarUnit.Minute], fromDate: date)
        return (dateComp.hour, dateComp.minute)
    }
    
    
}

