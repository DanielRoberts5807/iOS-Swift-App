//
//  UIBlockButton.swift
//  IInvest
//
//  Created by Anil Gautam on 27/01/2016.
//  Copyright © 2016 IInvest. All rights reserved.
//

import UIKit

class UIBlockButton : UIButton {

    var callback:((UIBlockButton)->Void)!
    
    override init(frame: CGRect) {
        
        self.callback = nil
        super.init(frame: frame)
        self.addTarget(self, action: "processCallback", forControlEvents: UIControlEvents.TouchUpInside)
        
    }
    
    func setup(titleText:String, color:UIColor, alignment:UIControlContentHorizontalAlignment, callback:(UIBlockButton) -> Void) {
        
        setTitle(titleText, forState: UIControlState.Normal)
        setTitleColor(color, forState: UIControlState.Normal)
        titleLabel?.font = Helper.getBoldFont()
        contentHorizontalAlignment  = alignment

        self.callback = callback
        
    }
    
    func processCallback() {
        if callback != nil {
            callback(self)
        }
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}