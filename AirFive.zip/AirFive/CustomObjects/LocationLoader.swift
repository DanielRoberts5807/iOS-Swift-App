//
//  LocationLoader.swift
//  AirFive
//
//  Created by Anil Gautam on 15/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation
import CoreLocation

class LocationLoader : NSObject {

    private static var sharedLocationLoader:LocationLoader! = nil
    
    static func getSharedLocationLoader() -> LocationLoader {
        if sharedLocationLoader == nil {
            sharedLocationLoader = LocationLoader()
        }
        return sharedLocationLoader
    }
    
    private var locationManager:CLLocationManager!
    private var callback:((CLLocation, String)->())?
    
    private override init() {
        
        super.init()
        locationManager = nil
        if CLLocationManager.locationServicesEnabled() {
            locationManager = CLLocationManager()
            locationManager.delegate = self
            
            locationManager.distanceFilter = kCLDistanceFilterNone
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            
            if CLLocationManager.authorizationStatus() == CLAuthorizationStatus.NotDetermined {
                if #available(iOS 8.0, *) {
                    locationManager.requestAlwaysAuthorization()
                } else {
                }
            }
            
        }
        
    }
    
    func getLocation(callback:(CLLocation, String)->()){
    
        if locationManager != nil {
            locationManager.startUpdatingLocation()
            self.callback = callback
        }
        
    }
    
}

extension LocationLoader : CLLocationManagerDelegate {

    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        reverseGeoCode(locations.last!)
        locationManager.stopUpdatingLocation()
        
    }
    
    func reverseGeoCode(location:CLLocation) {
    
        let geoCoder = CLGeocoder()
        geoCoder.reverseGeocodeLocation(location) { (placeMarkers:[CLPlacemark]?, error:NSError?) -> Void in
            let placeMarker = placeMarkers?.last!
            var address:String = ""
            
            if placeMarker?.locality != nil {
                address = (placeMarker?.locality!)!
            }
            if placeMarker?.administrativeArea != nil{
                if address.characters.count > 0 {
                    address = address + ", "
                }else {
                    address = ""
                }
                address = address + (placeMarker?.administrativeArea!)!
            }
            
            if self.callback != nil && placeMarker != nil {
                self.callback!((placeMarker?.location!)!
                    , address)
                self.callback = nil
            }
            
        }
    }
        
}








