//
//  ContactCell.swift
//  AirFive
//
//  Created by Anil Gautam on 14/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class ContactCell : UICollectionViewCell {

    @IBOutlet weak var profileImg: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        profileImg.clipsToBounds = true
        profileImg.layer.cornerRadius = (70 / 600 * UIScreen.mainScreen().bounds.size.height) / 2
        
    }
    
}