//
//  FeedJobCell.swift
//  AirFive
//
//  Created by Muhammad Umair on 6/28/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class FeedJobCell : UITableViewCell {

    @IBOutlet weak var titleLbl: UILabel!
    
}