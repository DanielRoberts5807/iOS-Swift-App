//
//  EventCell.swift
//  AirFive
//
//  Created by Anil Gautam on 06/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class EventCell : UITableViewCell {

    @IBOutlet weak var typeView: UIView!
    @IBOutlet weak var messageLbl: UILabel!
    @IBOutlet weak var timeLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        typeView.layer.masksToBounds = true
        typeView.layer.cornerRadius = typeView.frame.size.height / 2
    }
    
    func setEventType(type:EventType) {
        if type == EventType.Event {
            typeView.backgroundColor = UIColor(red: 27.0/255.0, green: 88.0/255.0, blue: 255.0/255.0, alpha: 1.0)
        }else {
            typeView.backgroundColor = UIColor(red: 156.0/255.0, green: 0.0/255.0, blue: 195.0/255.0, alpha: 1.0)
        }
    }
    
}
