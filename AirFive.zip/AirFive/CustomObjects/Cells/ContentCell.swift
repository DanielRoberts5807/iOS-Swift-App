//
//  ContentCell.swift
//  AirFive
//
//  Created by Anil Gautam on 5/12/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class ContentCell : UITableViewCell {
    
    @IBOutlet weak var innerContainer: UIView!
    @IBOutlet weak var actionView: UIView!
    @IBOutlet weak var profileImg: UIImageView!
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var rightArrowView: CellArrowView!
    
    @IBOutlet weak var metaContainer: UIView!
    @IBOutlet weak var metaImg: UIImageView!
    @IBOutlet weak var metaTitle: UILabel!
    
    @IBOutlet weak var likesLbl: UILabel!
    @IBOutlet weak var metaLblsX: NSLayoutConstraint!
    
    var profileImgInitialCenter:CGPoint! = nil
    var selectedLblCallback:((SelectedLblPosition)->())! = nil
    var tapCallback:(()->())! = nil
    
    var openUrlCallback:(()->())! = nil
    
    var liked = false
    var longPressGesture:UILongPressGestureRecognizer! = nil
    var panGesture:UIPanGestureRecognizer! = nil
    var tapGesture:UITapGestureRecognizer! = nil
    
    @IBOutlet weak var likedImg: UIImageView!
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        makeCircular(actionView, addBorder: true)
        makeCircular(profileImg, addBorder: false)
        
        panGesture = UIPanGestureRecognizer(target: self, action: "handlePan:")
        panGesture.delegate = self
        profileImg.addGestureRecognizer(panGesture)
        
        longPressGesture = UILongPressGestureRecognizer(target: self, action: "handleLongPress:")
        longPressGesture.minimumPressDuration = 0.001
        longPressGesture.delegate = self
        profileImg.addGestureRecognizer(longPressGesture)
        
        tapGesture = UITapGestureRecognizer(target: self, action: "handleTap:")
        tapGesture.delegate = self
        profileImg.addGestureRecognizer(tapGesture)
        
        profileImg.userInteractionEnabled = true
        
        rightArrowView.setForwardDirection(true)
        
        metaContainer.layer.borderColor = UIColor(white: 203.0/255.0, alpha: 1.0).CGColor
        metaContainer.layer.borderWidth = 1
        
    }
    
    func makeCircular(view:UIView, addBorder:Bool) {
        view.layer.masksToBounds = true
        view.layer.cornerRadius = (38 / 600 * UIScreen.mainScreen().bounds.size.height) / 2
        if addBorder {
            view.layer.borderColor = Helper.getAppGreenColor().CGColor
            view.layer.borderWidth = 1
        }
    }
    
    func addAnimations() {
        rightArrowView.addAnimations()
    }
    
    func removeAnimations() {
        rightArrowView.removeAnimations()
    }
    
    func setContentMeta(contentMeta:ContentMeta) {
    
        metaTitle.text = contentMeta.title
        
        if contentMeta.imgUrl.characters.count > 0 {
            metaImg.hidden = false
            metaImg.setImageWithURL(NSURL(string: contentMeta.imgUrl)!, placeholderImage: UIImage(named:""))
            metaLblsX.constant = 8
        }else {
            metaImg.hidden = true
            metaLblsX.constant = -metaImg.frame.size.width
        }
        
    }
    
}

extension ContentCell {
    
    func clipBounds(inout newCenter:CGPoint) {
        if newCenter.x > actionView.center.x {
            newCenter.x = actionView.center.x
        }
    }
    
    func handlePan(recognizer:UIPanGestureRecognizer) {
        
        if recognizer.state == UIGestureRecognizerState.Began {
            animateprofileImgScale(CGPoint(x: 1.3, y: 1.3))
        }
        
        if recognizer.state == UIGestureRecognizerState.Began || recognizer.state == UIGestureRecognizerState.Changed {
            
            let translation = recognizer.translationInView(innerContainer)
            var newCenter = CGPoint(x: profileImg.center.x + translation.x, y: profileImg.center.y)
            clipBounds(&newCenter)
            profileImg.center = newCenter
            
            recognizer.setTranslation(CGPoint.zero, inView: innerContainer)
            innerContainer.bringSubviewToFront(profileImg)
            animateLblsScaleOnOverlap()
            
        }else if recognizer.state == UIGestureRecognizerState.Ended {
            
            let velocity = recognizer.velocityInView(innerContainer)
            let magnitude = sqrtf(Float(velocity.x * velocity.x) + Float(velocity.y * velocity.y))
            let slideMult = magnitude / 200
            let slideFactor = 0.1 * slideMult;
            
            var newCenter = CGPoint(x: profileImg.center.x + CGFloat(Float(velocity.x) * slideFactor), y: profileImg.center.y)
            clipBounds(&newCenter)
            
            UIView.animateWithDuration(Double(slideFactor * 2), delay: 0.0, options: [UIViewAnimationOptions.CurveEaseOut], animations: { () -> Void in
                
                self.profileImg.center = newCenter
                
                }, completion: {(complete:Bool)->Void in
                    
                    self.handleLblsOverlap()
                    UIView.animateWithDuration(1.5, delay: 0.0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.0, options: [], animations: { () -> Void in
                        
                        self.profileImg.center = self.profileImgInitialCenter
                        
                        }, completion: {(complete:Bool)->Void in
                            //                    self.leftArrowView.setViewHidden(false)
                            //                    self.rightArrowView.setViewHidden(false)
                    })
                    
            })
            
        }
        
    }
    
    func handleLongPress(recognizer:UILongPressGestureRecognizer) {
        if recognizer.state == UIGestureRecognizerState.Began {
            animateprofileImgScale(CGPoint(x: 1.3, y: 1.3))
            if profileImgInitialCenter == nil {
                profileImgInitialCenter = profileImg.center
            }
            addAnimations()
        }else if recognizer.state == UIGestureRecognizerState.Ended {
            animateprofileImgScale(CGPoint(x: 1, y: 1))
            removeAnimations()
        }
    }
    
    func animateprofileImgScale(scaleDelta:CGPoint) {
        UIView.animateWithDuration(0.3) { () -> Void in
            self.profileImg.transform = CGAffineTransformMakeScale(scaleDelta.x, scaleDelta.y)
        }
    }
    
    func animateLblsScaleOnOverlap() {
        if !CGRectIsNull(CGRectIntersection(self.profileImg.frame, self.actionView.frame)) {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.actionView.transform = CGAffineTransformMakeScale(1.4, 1.4)
            })
            
        }else if actionView.transform.a > 1.0 {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.actionView.transform = CGAffineTransformMakeScale(1, 1)
            })
            
        }
    }
    
    func handleLblsOverlap() {
        if !CGRectIsNull(CGRectIntersection(self.profileImg.frame, self.actionView.frame)) {
            
            if selectedLblCallback != nil {
                selectedLblCallback(SelectedLblPosition.Right)
            }
            
        }
        if actionView.transform.a > 1.0 {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.actionView.transform = CGAffineTransformMakeScale(1, 1)
            })
            
        }
    }
    
    func handleTap(recognizer:UITapGestureRecognizer) {
        
        if tapCallback != nil {
            tapCallback()
        }
        
    }
    
    override func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWithGestureRecognizer otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        
        if (gestureRecognizer == panGesture && otherGestureRecognizer == longPressGesture) || (gestureRecognizer == longPressGesture && otherGestureRecognizer == panGesture) || (gestureRecognizer == longPressGesture && otherGestureRecognizer == tapGesture) {
            return true
        }
        return false
        
    }
  
    @IBAction func changeLikeAct(sender: UIButton) {
        selectedLblCallback(SelectedLblPosition.Right)
    }
    
    @IBAction func openUrlAct(sender: UIButton) {
        
        if openUrlCallback != nil {
            openUrlCallback()
        }

    }
    
}








