//
//  ContactDetailCell.swift
//  AirFive
//
//  Created by Anil Gautam on 17/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class ContactDetailCell : UITableViewCell {

    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var titleImg: UIImageView!
    @IBOutlet weak var detailLbl: UILabel!
    @IBOutlet weak var detailImg: UIImageView!
    
    @IBOutlet weak var titleImgWidth: NSLayoutConstraint!
    @IBOutlet weak var titleImgHieght: NSLayoutConstraint!
    
}
