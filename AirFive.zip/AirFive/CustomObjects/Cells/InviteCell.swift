//
//  InviteCell.swift
//  AirFive
//
//  Created by Anil Gautam on 11/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class InviteCell : UITableViewCell {

    @IBOutlet weak var profileImg: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var inviteLbl: UILabel!

    
    var inviteCallback:(()->())! = nil
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        profileImg.layer.masksToBounds = true
        profileImg.layer.cornerRadius = (48 / 600 * UIScreen.mainScreen().bounds.size.height) / 2
        if inviteLbl != nil {
            inviteLbl.layer.borderColor = Helper.getAppBlackColor().CGColor
            inviteLbl.layer.masksToBounds = true
            inviteLbl.layer.cornerRadius = inviteLbl.frame.size.height / 2
            setInvited(-1)
        }
        self.selectionStyle = UITableViewCellSelectionStyle.None
        
    }
    
    func setInvited(invited:Int) {
        
        if invited == 1 {
            inviteLbl.text = "ATTENDING"
            inviteLbl.textColor = UIColor.whiteColor()
            inviteLbl.layer.borderWidth = 0
            inviteLbl.backgroundColor = Helper.getAppGreenColor()
        }else if invited == 0 {
            inviteLbl.text = "INVITED"
            inviteLbl.textColor = UIColor.whiteColor()
            inviteLbl.layer.borderWidth = 0
            inviteLbl.backgroundColor = Helper.getAppGreenColor()
        }else {
            inviteLbl.text = "INVITE"
            inviteLbl.textColor = Helper.getAppBlackColor()
            inviteLbl.layer.borderWidth = 1
            inviteLbl.backgroundColor = UIColor.clearColor()
        }
    }
    
}

extension InviteCell {

    @IBAction func inviteAct(sender: UIButton) {
        if inviteCallback != nil {
            inviteCallback()
        }
    }
    
}
