//
//  SocialConnectionCell.swift
//  AirFive
//
//  Created by Anil Gautam on 18/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class SocialConnectionCell : UITableViewCell {

    @IBOutlet weak var connectionImg: UIImageView!
    @IBOutlet weak var connectionImgWidth: NSLayoutConstraint!
    @IBOutlet weak var connectionImgHeight: NSLayoutConstraint!
    
    @IBOutlet weak var connectionNameLbl: UILabel!
    
    @IBOutlet weak var connectBtn: UIButton!
    
    @IBOutlet weak var connectedCheckImg: UIImageView!
    @IBOutlet weak var connectedTickImg: UIImageView!
    @IBOutlet weak var connectedBtn: UIButton!
    
    var connectCallback:(()->())! = nil
    var changeVisibilityCallback:(()->())! = nil
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        connectBtn.layer.borderColor = Helper.getAppGreenColor().CGColor
        connectBtn.layer.borderWidth = 1
        connectBtn.layer.cornerRadius = 5
        
    }
    
}

extension SocialConnectionCell {
    
    @IBAction func connectAct(sender: UIButton) {
        if connectCallback != nil {
            connectCallback()
        }
    }
    
    @IBAction func changeVisibilityAct(sender: UIButton) {
        if changeVisibilityCallback != nil {
            changeVisibilityCallback()
        }
    }
}
