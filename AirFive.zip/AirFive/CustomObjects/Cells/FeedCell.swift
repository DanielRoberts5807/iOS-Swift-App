//
//  FeedCell.swift
//  AirFive
//
//  Created by Anil Gautam on 01/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class FeedCell : UITableViewCell {
    
    @IBOutlet weak var innerContainer: UIView!
    @IBOutlet weak var dragView: UIView!
    @IBOutlet weak var actionLbl: UILabel!
    @IBOutlet weak var profileImg: UIImageView!
    @IBOutlet weak var meLbl: UILabel!
    
    @IBOutlet weak var messageLbl: UILabel!
    @IBOutlet weak var rightArrowView: CellArrowView!
    
    var dragViewInitialCenter:CGPoint! = nil
    var selectedLblCallback:((SelectedLblPosition)->())! = nil
    var tapCallback:(()->())! = nil
    
    var longPressGesture:UILongPressGestureRecognizer! = nil
    var panGesture:UIPanGestureRecognizer! = nil
    var tapGesture:UITapGestureRecognizer! = nil
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        makeCircular(actionLbl, addBorder: true)
        makeCircular(profileImg, addBorder: false)
        makeCircular(meLbl, addBorder: false)
        
        panGesture = UIPanGestureRecognizer(target: self, action: "handlePan:")
        panGesture.delegate = self
        dragView.addGestureRecognizer(panGesture)
        
        longPressGesture = UILongPressGestureRecognizer(target: self, action: "handleLongPress:")
        longPressGesture.minimumPressDuration = 0.001
        longPressGesture.delegate = self
        dragView.addGestureRecognizer(longPressGesture)
        
        tapGesture = UITapGestureRecognizer(target: self, action: "handleTap:")
        tapGesture.delegate = self
        dragView.addGestureRecognizer(tapGesture)
        
        dragView.userInteractionEnabled = true
        
        rightArrowView.setForwardDirection(true)
        
    }
    
    func makeCircular(view:UIView, addBorder:Bool) {
        view.layer.masksToBounds = true
        view.layer.cornerRadius = (48 / 600 * UIScreen.mainScreen().bounds.size.height) / 2
        if addBorder {
            view.layer.borderColor = Helper.getAppGreenColor().CGColor
            view.layer.borderWidth = 1
        }
    }
    
    func addAnimations() {
        rightArrowView.addAnimations()
    }
    
    func removeAnimations() {
        rightArrowView.removeAnimations()
    }
    
    func enableMeLbl(enable:Bool) {
        meLbl.hidden = !enable
        profileImg.hidden = enable
    }
    
}

extension FeedCell {
    
    func clipBounds(inout newCenter:CGPoint) {
        if newCenter.x > actionLbl.center.x {
            newCenter.x = actionLbl.center.x
        }
    }
    
    func handlePan(recognizer:UIPanGestureRecognizer) {
        
        if recognizer.state == UIGestureRecognizerState.Began {
            animateDragViewScale(CGPoint(x: 1.3, y: 1.3))
        }
        
        if recognizer.state == UIGestureRecognizerState.Began || recognizer.state == UIGestureRecognizerState.Changed {
            
            let translation = recognizer.translationInView(innerContainer)
            var newCenter = CGPoint(x: dragView.center.x + translation.x, y: dragView.center.y)
            clipBounds(&newCenter)
            dragView.center = newCenter
            
            recognizer.setTranslation(CGPoint.zero, inView: innerContainer)
            innerContainer.bringSubviewToFront(dragView)
            animateLblsScaleOnOverlap()
            
        }else if recognizer.state == UIGestureRecognizerState.Ended {
            
            let velocity = recognizer.velocityInView(innerContainer)
            let magnitude = sqrtf(Float(velocity.x * velocity.x) + Float(velocity.y * velocity.y))
            let slideMult = magnitude / 200
            let slideFactor = 0.1 * slideMult;
            
            var newCenter = CGPoint(x: dragView.center.x + CGFloat(Float(velocity.x) * slideFactor), y: dragView.center.y)
            clipBounds(&newCenter)
            
            UIView.animateWithDuration(Double(slideFactor * 2), delay: 0.0, options: [UIViewAnimationOptions.CurveEaseOut], animations: { () -> Void in
                
                self.dragView.center = newCenter
                
            }, completion: {(complete:Bool)->Void in
                    
                self.handleLblsOverlap()
                UIView.animateWithDuration(1.5, delay: 0.0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.0, options: [], animations: { () -> Void in
                        
                    self.dragView.center = self.dragViewInitialCenter
                        
                    }, completion: {(complete:Bool)->Void in
                            //                    self.leftArrowView.setViewHidden(false)
                            //                    self.rightArrowView.setViewHidden(false)
                })
                    
            })
            
        }
        
    }
    
    func handleLongPress(recognizer:UILongPressGestureRecognizer) {
        if recognizer.state == UIGestureRecognizerState.Began {
            animateDragViewScale(CGPoint(x: 1.3, y: 1.3))
            if dragViewInitialCenter == nil {
                dragViewInitialCenter = dragView.center
            }
            addAnimations()
        }else if recognizer.state == UIGestureRecognizerState.Ended {
            animateDragViewScale(CGPoint(x: 1, y: 1))
            removeAnimations()
        }
    }
    
    func animateDragViewScale(scaleDelta:CGPoint) {
        UIView.animateWithDuration(0.3) { () -> Void in
            self.dragView.transform = CGAffineTransformMakeScale(scaleDelta.x, scaleDelta.y)
        }
    }
    
    func animateLblsScaleOnOverlap() {
        if !CGRectIsNull(CGRectIntersection(self.dragView.frame, self.actionLbl.frame)) {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.actionLbl.transform = CGAffineTransformMakeScale(1.4, 1.4)
            })
            
        }else if actionLbl.transform.a > 1.0 {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.actionLbl.transform = CGAffineTransformMakeScale(1, 1)
            })
            
        }
    }
    
    func handleLblsOverlap() {
        if !CGRectIsNull(CGRectIntersection(self.dragView.frame, self.actionLbl.frame)) {
            
            if selectedLblCallback != nil {
                selectedLblCallback(SelectedLblPosition.Right)
            }
            
        }
        if actionLbl.transform.a > 1.0 {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.actionLbl.transform = CGAffineTransformMakeScale(1, 1)
            })
            
        }
    }
    
    func handleTap(recognizer:UITapGestureRecognizer) {
        
        if tapCallback != nil {
            tapCallback()
        }
        
    }
    
    override func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWithGestureRecognizer otherGestureRecognizer: UIGestureRecognizer) -> Bool {
    
        if (gestureRecognizer == panGesture && otherGestureRecognizer == longPressGesture) || (gestureRecognizer == longPressGesture && otherGestureRecognizer == panGesture) || (gestureRecognizer == longPressGesture && otherGestureRecognizer == tapGesture) {
            return true
        }
        return false
        
    }
    
}








