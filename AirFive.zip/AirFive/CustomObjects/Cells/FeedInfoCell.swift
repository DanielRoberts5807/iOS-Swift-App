//
//  FeedInfoCell.swift
//  AirFive
//
//  Created by Anil Gautam on 5/15/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class FeedInfoCell : UITableViewCell {

    @IBOutlet weak var infoLbl: UILabel!
    @IBOutlet weak var container: UIView!
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        container.layer.borderColor = UIColor(white: 203.0/255.0, alpha: 1.0).CGColor
        container.layer.borderWidth = 1
        
    }
    
}