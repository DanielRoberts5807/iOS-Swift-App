//
//  JobCell.swift
//  AirFive
//
//  Created by Muhammad Umair on 6/29/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class JobCell : UITableViewCell {
    
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var descLbl: UILabel!
    @IBOutlet weak var urlLbl: UILabel!
    @IBOutlet weak var container: UIView!
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        container.layer.borderColor = UIColor(white: 203.0/255.0, alpha: 1.0).CGColor
        container.layer.borderWidth = 1
        
    }
    
}
