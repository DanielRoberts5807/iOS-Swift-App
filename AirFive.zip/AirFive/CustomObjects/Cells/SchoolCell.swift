//
//  SchoolCell.swift
//  AirFive
//
//  Created by Anil Gautam on 5/11/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class SchoolCell: UITableViewCell {
    
    @IBOutlet weak var schoolLbl: UILabel!
    
}
