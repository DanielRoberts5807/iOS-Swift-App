//
//  JobDetailCell.swift
//  AirFive
//
//  Created by Muhammad Umair on 6/30/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class JobDetailCell : UITableViewCell {
    
    @IBOutlet weak var titleCompLbl: UILabel!
    @IBOutlet weak var detailLbl: UILabel!
    @IBOutlet weak var websiteLbl: UILabel!
    @IBOutlet weak var experienceLbl: UILabel!
    
    @IBOutlet weak var detailBtn: UIButton!
    @IBOutlet weak var applyBtn: UIButton!
    
    @IBOutlet weak var detailLblHeight: NSLayoutConstraint!
    @IBOutlet weak var detailViewHeight: NSLayoutConstraint!
    
    var detailCallback:((CGFloat, Bool)->())! = nil
    var applyCallback:(()->())! = nil
    var isDetailOpened:Bool = false
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        detailLbl.lineBreakMode = NSLineBreakMode.ByClipping
        if detailBtn != nil {
            detailBtn.layer.borderColor = Helper.getAppGreenColor().CGColor
            detailBtn.layer.borderWidth = 1
            detailBtn.layer.masksToBounds = true
            detailBtn.layer.cornerRadius = detailBtn.frame.size.height / 2
        }
        
        if applyBtn != nil {
            applyBtn.layer.borderColor = Helper.getAppGreenColor().CGColor
            applyBtn.layer.borderWidth = 1
            applyBtn.layer.masksToBounds = true
            applyBtn.layer.cornerRadius = applyBtn.frame.size.height / 2
        }
        
    }
    
    func setDetailOpened(isDetailOpened:Bool) {
        self.isDetailOpened = isDetailOpened
        if isDetailOpened {
            detailBtn.setTitle("Less Details", forState: UIControlState.Normal)
        }else {
            detailBtn.setTitle("More Details", forState: UIControlState.Normal)
        }
    }
    
}

extension JobDetailCell {
    
    @IBAction func detailAct() {
    
        var height:CGFloat = 45
        if !isDetailOpened {//closed
            
            detailBtn.setTitle("Less Details", forState: UIControlState.Normal)
            
            let detailStr: NSString = detailLbl.text! as NSString
            let size: CGSize = detailStr.sizeWithAttributes([NSFontAttributeName: detailLbl.font])
            height = ceil(size.width / (UIScreen.mainScreen().bounds.size.width * 0.65)) * size.height + 40
            
        }else {
        
            detailBtn.setTitle("More Details", forState: UIControlState.Normal)
            
        }
        
        height = height < 45 ? 45 : height
        
        isDetailOpened = !isDetailOpened
        
        if detailCallback != nil {
            detailCallback(height, isDetailOpened)
        }
        
    }

    @IBAction func applyAct() {
    
        if applyCallback != nil {
            applyCallback()
        }
        
    }
    
}








