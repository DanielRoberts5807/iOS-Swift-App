//
//  AlumniCell.swift
//  AirFive
//
//  Created by Anil Gautam on 30/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class AlumniCell : UITableViewCell {
    
    @IBOutlet weak var innerContainer: UIView!
    @IBOutlet weak var coffeeLbl: UILabel!
    @IBOutlet weak var biteLbl: UILabel!
    @IBOutlet weak var profileImg: UIImageView!
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var rightArrowView: CellArrowView!
    @IBOutlet weak var leftArrowView: CellArrowView!
    
    var profileImgInitialCenter:CGPoint! = nil
    var selectedLblCallback:((SelectedLblPosition)->())! = nil
    var tapCallback:(()->())! = nil
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        makeCircular(coffeeLbl, addBorder: true)
        makeCircular(biteLbl, addBorder: true)
        
        makeCircular(profileImg, addBorder: false)
        
        let panGesture = UIPanGestureRecognizer(target: self, action: "handlePan:")
        profileImg.addGestureRecognizer(panGesture)
        
        let longPressGesture = UILongPressGestureRecognizer(target: self, action: "handleLongPress:")
        longPressGesture.minimumPressDuration = 0.001
        longPressGesture.delegate = self
        profileImg.addGestureRecognizer(longPressGesture)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "handleTap:")
        longPressGesture.delegate = self
        profileImg.addGestureRecognizer(tapGesture)
        
        profileImg.userInteractionEnabled = true
        
        leftArrowView.setForwardDirection(false)
        rightArrowView.setForwardDirection(true)
    
    }
    
    func makeCircular(view:UIView, addBorder:Bool) {
        view.layer.masksToBounds = true
        view.layer.cornerRadius = (48 / 600 * UIScreen.mainScreen().bounds.size.height) / 2
        if addBorder {
            view.layer.borderColor = Helper.getAppGreenColor().CGColor
            view.layer.borderWidth = 1
        }
    }
    
    func addAnimations() {
        leftArrowView.addAnimations()
        rightArrowView.addAnimations()
    }
    
    func removeAnimations() {
        leftArrowView.removeAnimations()
        rightArrowView.removeAnimations()
    }
}

extension AlumniCell {
    
    func clipBounds(inout newCenter:CGPoint) {
        if newCenter.x > biteLbl.center.x {
            newCenter.x = biteLbl.center.x
        }else if newCenter.x < coffeeLbl.center.x {
            newCenter.x = coffeeLbl.center.x
        }
    }

    func handlePan(recognizer:UIPanGestureRecognizer) {
        
        if recognizer.state == UIGestureRecognizerState.Began {
            animateProfileImgScale(CGPoint(x: 1.3, y: 1.3))
        }
        
        if recognizer.state == UIGestureRecognizerState.Began || recognizer.state == UIGestureRecognizerState.Changed {
            
            let translation = recognizer.translationInView(innerContainer)
            var newCenter = CGPoint(x: profileImg.center.x + translation.x, y: profileImg.center.y)
            clipBounds(&newCenter)
            profileImg.center = newCenter
            
            recognizer.setTranslation(CGPoint.zero, inView: innerContainer)
            innerContainer.bringSubviewToFront(profileImg)
            animateLblsScaleOnOverlap()
            
        }else if recognizer.state == UIGestureRecognizerState.Ended {
            
            let velocity = recognizer.velocityInView(innerContainer)
            let magnitude = sqrtf(Float(velocity.x * velocity.x) + Float(velocity.y * velocity.y))
            let slideMult = magnitude / 200
            let slideFactor = 0.1 * slideMult;
            
            var newCenter = CGPoint(x: profileImg.center.x + CGFloat(Float(velocity.x) * slideFactor), y: profileImg.center.y)
            clipBounds(&newCenter)
            
            UIView.animateWithDuration(Double(slideFactor * 2), delay: 0.0, options: [UIViewAnimationOptions.CurveEaseOut], animations: { () -> Void in
                
                self.profileImg.center = newCenter
                
            }, completion: {(complete:Bool)->Void in
                
                self.handleLblsOverlap()
                UIView.animateWithDuration(1.5, delay: 0.0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0.0, options: [], animations: { () -> Void in
                    
                    self.profileImg.center = self.profileImgInitialCenter
                    
                }, completion: nil)
                
            })
            
        }
        
    }
    
    func handleLongPress(recognizer:UILongPressGestureRecognizer) {
        if recognizer.state == UIGestureRecognizerState.Began {
            animateProfileImgScale(CGPoint(x: 1.3, y: 1.3))
            if profileImgInitialCenter == nil {
                profileImgInitialCenter = profileImg.center
            }
            addAnimations()
        }else if recognizer.state == UIGestureRecognizerState.Ended {
            animateProfileImgScale(CGPoint(x: 1, y: 1))
            removeAnimations()
        }
    }
    
    func handleTap(recognizer:UITapGestureRecognizer) {
        
        if tapCallback != nil {
            tapCallback()
        }
        
    }
    
    func animateProfileImgScale(scaleDelta:CGPoint) {
        UIView.animateWithDuration(0.3) { () -> Void in
            self.profileImg.transform = CGAffineTransformMakeScale(scaleDelta.x, scaleDelta.y)
        }
    }
    
    func animateLblsScaleOnOverlap() {
        if !CGRectIsNull(CGRectIntersection(self.profileImg.frame, self.biteLbl.frame)) {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.biteLbl.transform = CGAffineTransformMakeScale(1.4, 1.4)
            })
            
        }else if !CGRectIsNull(CGRectIntersection(self.profileImg.frame, self.coffeeLbl.frame)) {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.coffeeLbl.transform = CGAffineTransformMakeScale(1.4, 1.4)
            })
            
        }else if biteLbl.transform.a > 1.0 {
        
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.biteLbl.transform = CGAffineTransformMakeScale(1, 1)
            })
            
        }else if coffeeLbl.transform.a > 1.0 {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.coffeeLbl.transform = CGAffineTransformMakeScale(1, 1)
            })
            
        }
    }
    
    func handleLblsOverlap() {
        if !CGRectIsNull(CGRectIntersection(self.profileImg.frame, self.biteLbl.frame)) {
            
            if selectedLblCallback != nil {
                selectedLblCallback(SelectedLblPosition.Right)
            }
            
        }else if !CGRectIsNull(CGRectIntersection(self.profileImg.frame, self.coffeeLbl.frame)) {
            
            if selectedLblCallback != nil {
                selectedLblCallback(SelectedLblPosition.Left)
            }
            
        }
        if biteLbl.transform.a > 1.0 {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.biteLbl.transform = CGAffineTransformMakeScale(1, 1)
            })
            
        }else if coffeeLbl.transform.a > 1.0 {
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                self.coffeeLbl.transform = CGAffineTransformMakeScale(1, 1)
            })
            
        }
    }
    
    override func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWithGestureRecognizer otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
}







