//
//  User.swift
//  AirFive
//
//  Created by Anil Gautam on 15/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class User {
    
    private static var sharedUser:User! = nil
    
    static func getSharedUser() -> User {
        if sharedUser == nil {
            sharedUser = User()
        }
        return sharedUser
    }
    
    
    var name:String = "", title:String = "", company:String = "", school:String = "", password:String = ""
    var profileImgUrl:String = "", coverImgUrl:String = "", email:String = "", phone:String = ""
    var activityCount = 0, eventsCount = 0
    var emailPreference = true, phonePreference = true
    
    private init(){
        reset()
    }
    
    func loadUserFromJson(jsonResponse:Dictionary<String,AnyObject>) {
        
        reset()
        if jsonResponse.keys.contains("username") == true {
            name = jsonResponse["username"]! as! String
        }
        
        if jsonResponse.keys.contains("password") == true {
            password = jsonResponse["password"]! as! String
        }
        
        if jsonResponse.keys.contains("title") == true {
            title = jsonResponse["title"]! as! String
        }
        
        if jsonResponse.keys.contains("company") == true {
            company = jsonResponse["company"]! as! String
        }
        
        if jsonResponse.keys.contains("school") == true {
            school = jsonResponse["school"]! as! String
        }
        
        if jsonResponse.keys.contains("profile") == true {
            profileImgUrl = jsonResponse["profile"]! as! String
        }
        
        if jsonResponse.keys.contains("cover") == true {
            coverImgUrl = jsonResponse["cover"]! as! String
        }
        
        if jsonResponse.keys.contains("email") == true {
            email = jsonResponse["email"]! as! String
        }
        
        if jsonResponse.keys.contains("phone_number") == true {
            phone = jsonResponse["phone_number"]! as! String
        }
        
        if jsonResponse.keys.contains("activityCount") == true {
            activityCount = jsonResponse["activityCount"]! as! Int
        }
        
        if jsonResponse.keys.contains("eventsCount") == true {
            eventsCount = jsonResponse["eventsCount"]! as! Int
        }
        
        if jsonResponse.keys.contains("emailPreference") == true {
            emailPreference = (jsonResponse["emailPreference"]! as! NSString).boolValue
        }
        
        if jsonResponse.keys.contains("phonePreference") == true {
            phonePreference = (jsonResponse["phonePreference"]! as! NSString).boolValue
        }
        
    }
    
    func reset() {
        name = ""
        title = ""
        company = ""
        school = ""
        password = ""
        profileImgUrl = ""
        coverImgUrl = ""
        email = ""
        phone = ""
        activityCount = 0
        eventsCount = 0
        emailPreference = true
        phonePreference = true
    }
    
}


