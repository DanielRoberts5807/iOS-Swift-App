//
//  LinkedInDataLoader.swift
//  AirFive
//
//  Created by Anil Gautam on 11/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation
import FBSDKLoginKit

class LinkedInDataLoader {
    
    let liRedirectUri = "http://162.243.114.108"
    let liClientId = "77frjntduxlwlx"
    let liClientSecret = "ycgpjNZdoLXqVaj4"
    
    var liClient:LIALinkedInHttpClient!
    var failureCallback:((String) -> Void)?
    var successCallback:(([String:AnyObject]) -> Void)?
    
    init() {
        
        liClient = nil
        failureCallback = nil
        successCallback = nil
        
    }
    
    func process(viewController:UIViewController, successCallback:([String:AnyObject]) -> Void, failureCallback:(String) -> Void) {
        
        self.successCallback = successCallback
        self.failureCallback = failureCallback
        createLiClient(viewController)
        getAuthorizationCode()
        
    }
    
    func createLiClient(viewController:UIViewController) {
        
        let state = "airFive" + String(NSDate().timeIntervalSince1970)
        let permissions = ["r_basicprofile", "r_emailaddress"]
        
        let application = LIALinkedInApplication(redirectURL: liRedirectUri, clientId: liClientId, clientSecret: liClientSecret, state: state, grantedAccess: permissions)
        liClient = LIALinkedInHttpClient(forApplication: application, presentingViewController: viewController)
        
    }
    
    func getAuthorizationCode() {
    
        liClient.getAuthorizationCode({ (authorizationCode:String!) -> Void in
            
            self.getAccessToken(authorizationCode)
            
        }, cancel: { () -> Void in
            
            if self.failureCallback != nil {
                self.failureCallback!("User Canceled")
            }
            
        }, failure: { (error:NSError!) -> Void in
            
            if error != nil && self.failureCallback != nil {
                self.failureCallback!(error.localizedDescription)
            }
            
        })
        
    }
    
    func getAccessToken(authorizationCode:String) {
        
        SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.Dark)
        SVProgressHUD.showWithStatus("Processing...")
        liClient.getAccessToken(authorizationCode, success: { (response:[NSObject : AnyObject]!) -> Void in
            
            let accessToken = response["access_token"] as! String
            self.loadUserData(accessToken)
            
        }, failure: { (error:NSError!) -> Void in
            
            if error != nil && self.failureCallback != nil {
                self.failureCallback!(error.localizedDescription)
            }
            
        })
        
    }
    
    func loadUserData(accessToken:String) {
        
        let url = String(format: "https://api.linkedin.com/v1/people/~:(id,first-name,last-name,email-address,educations,positions)?oauth2_access_token=%@&format=json", arguments: [accessToken])
        liClient.GET(url, parameters: nil, success: { (operation:AFHTTPRequestOperation!, response:AnyObject!) -> Void in
            
            if self.successCallback != nil {
                self.successCallback!(response as! [String : AnyObject])
            }
            
            
        }, failure: { (operation:AFHTTPRequestOperation!, error:NSError!) -> Void in
            
            if error != nil && self.failureCallback != nil {
                self.failureCallback!(error.localizedDescription)
            }
            
        })
        
    }
    
    
}
