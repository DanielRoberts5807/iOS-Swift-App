//
//  FacebookDataLoader.swift
//  AirFive
//
//  Created by Anil Gautam on 11/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation
import FBSDKLoginKit

class FacebookDataLoader {

    let fbLoginManager:FBSDKLoginManager!
    var failureCallback:((String) -> Void)?
    var successCallback:(([String:AnyObject]) -> Void)?
    
    init() {
    
        fbLoginManager = FBSDKLoginManager()
        failureCallback = nil
        successCallback = nil
    }

    func process(viewController:UIViewController, successCallback:([String:AnyObject]) -> Void, failureCallback:(String) -> Void) {
    
        self.successCallback = successCallback
        self.failureCallback = failureCallback
        if FBSDKAccessToken.currentAccessToken() == nil {
            getAccessToken(viewController)
        }else {
            loadUserData()
        }
        
    }
    
    func getAccessToken(viewController:UIViewController) {
        
        fbLoginManager.logInWithReadPermissions(["public_profile", "email", "user_work_history"], fromViewController: viewController, handler: { (result:FBSDKLoginManagerLoginResult!, error:NSError!) -> Void in
            
            if error != nil {
                if self.failureCallback != nil {
                    self.failureCallback!(error.localizedDescription)
                }
            }else if result.isCancelled {
                if self.failureCallback != nil {
                    self.failureCallback!("User Canceled")
                }
            }else {
                self.loadUserData()
            }
            
        })
        
    }
    
    func loadUserData() {
        
        SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.Dark)
        SVProgressHUD.showWithStatus("Processing...")
        let request = FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id,name,email,education,work"])
        request.startWithCompletionHandler { (connection:FBSDKGraphRequestConnection!, result:AnyObject!, error:NSError!) -> Void in
            
            if error != nil {
                if self.failureCallback != nil {
                    self.failureCallback!(error.localizedDescription)
                }
            }else {
                if self.successCallback != nil {
                    self.successCallback!(result as! [String : AnyObject])
                }
                
            }
            
        }
        
    }
    
    
}
