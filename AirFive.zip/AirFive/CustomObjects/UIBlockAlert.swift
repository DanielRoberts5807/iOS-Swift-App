//
//  UIBlockAlert.swift
//  AirFive
//
//  Created by Umair Bhatti on 31/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class UIBlockAlert : NSObject, UIAlertViewDelegate {
    
    private var callback:((Int)->())!
    private var alertView:UIAlertView!
    
    init(title:String, message:String, cancelButtonTitle:String, otherButtonTitle:String?, callback:((Int)->())) {
        
        super.init()
        if otherButtonTitle != nil {
            alertView = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: cancelButtonTitle, otherButtonTitles: otherButtonTitle!)
        }else {
            alertView = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: cancelButtonTitle)
        }
        
        self.callback = callback
        alertView.show()
        
    }
    
    @objc func alertView(alertView: UIAlertView, clickedButtonAtIndex buttonIndex: Int) {
        if callback != nil {
            callback(buttonIndex)
        }
    }
    
}
