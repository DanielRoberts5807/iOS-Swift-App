//
//  Alumni.swift
//  AirFive
//
//  Created by Anil Gautam on 30/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class Alumni {

    var id = "", name = "", title = "", company = "", profileImg = ""
    
    
    static func makeAlumniAroundFrom(jsonResponse:Dictionary<String,AnyObject>) -> [Alumni] {
        
        var alumniArr:[Alumni] = []
        
        if let alumniJsonArray = jsonResponse["alumni"] as? Array<AnyObject> {
            for json in alumniJsonArray {
                let alumniJson = json as! Dictionary<String,String>
                let alumni = Alumni()
                
                if alumniJson.keys.contains("name") == true {
                    alumni.name = alumniJson["name"]!
                }
                
                if alumniJson.keys.contains("title") == true {
                    alumni.title = alumniJson["title"]!
                }
                
                if alumniJson.keys.contains("company") == true {
                    alumni.company = alumniJson["company"]!
                }
                
                if alumniJson.keys.contains("profile_image") == true {
                    alumni.profileImg = alumniJson["profile_image"]!
                }
                
                if alumniJson.keys.contains("id") == true {
                    alumni.id = alumniJson["id"]!
                }
                
                alumniArr.append(alumni)
                
            }
        }
        
        return alumniArr
        
    }
    
}