//
//  WebServices.swift
//  AirFive
//
//  Created by Anil Gautam on 11/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation
import CoreLocation

class WebServices {

    private static var sharedWebSevices:WebServices! = nil

    static func getSharedWebServices() -> WebServices {
        if sharedWebSevices == nil {
            sharedWebSevices = WebServices()
        }
        return sharedWebSevices
    }

    let clientId = "f3d259ddd3ed8ff3843839b"
    let clientSecret = "4c7f6f8fa93d59c45502c0ae8c4a95b"
    let grantType = "client_credentials"

//    let baseUrl = "https://www.airfive.com"
    let baseUrl = "http://airfive.techmarbles.com"

    let accessTokenUrl = "/api/v1/oauth/access_token"
    let signInUrl = "/api/v1/user/login"
    let signUpUrl = "/api/v1/user/register"
    let forgotPasswordUrl = "/api/v1/user/forgot_password"
    let getSchoolUrl = "/api/v1/alumni/find_school"

    let userGetUrl = "/api/v1/user/"
    let userUpdateUrl = "/api/v1/user/update"
    let imageUploadUrl = "/api/v1/user/upload_image"

    let alumniAroundUrl = "/api/v1/alumni/"
    let inviteAlumiUrl = "/api/v1/alumni/invite"
    let searchAlumniUrl = "/api/v1/alumni/search"

    let feedsUrl = "/api/v1/alumni/get_all_feeds"
    let respondFeedUrl = "/api/v1/alumni/respond"

    let addEventUrl = "/api/v1/alumni/event/add"
    let eventsUrl = "/api/v1/alumni/get_user_events/"
    let eventAttendeesUrl = "/api/v1/alumni/event/invite-able"
    let eventInviteUrl = "/api/v1/alumni/invite"
    let eventInviteRespondUrl = "/api/v1/alumni/event/respond"

    let contactsUrl = "/api/v1/alumni/contacts/"
    let contactDetialUrl = "/api/v1/user/contact/detail"

    let socialConnectionsUrl = "/api/v1/user/social/"
    let setSocialConnectionUrl = "/api/v1/user/social/add"

    let contentMetaUrl = "/api/v1/content/meta"
    let shareContentUrl = "/api/v1/content/post"
    let likeContentUrl = "/api/v1/content/like"
    let liveDataUrl = "/api/v1/user/livedata/"
    
    let jobsUrl = "/api/v1/content/getPost"
    let applyJobUrl = "/api/v1/content/applyForJob"

    let serverResponseSuccess = true
    let serverResponseFailure = false

    let sessionManager:AFHTTPSessionManager!

    var request:NSURLSessionDataTask! = nil

    private init() {

        sessionManager = AFHTTPSessionManager(baseURL: NSURL(string: baseUrl))
        sessionManager.requestSerializer = AFHTTPRequestSerializer()
        sessionManager.requestSerializer.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
//        sessionManager.responseSerializer = AFJSONResponseSerializer()
        sessionManager.securityPolicy.allowInvalidCertificates = true

    }

}

extension WebServices {

    func getAccessToken(successCallback:(String)->Void, failureCallback:(String)->Void) {

        let parameters = ["client_id":clientId, "client_secret":clientSecret, "grant_type":grantType]
        request = sessionManager.POST(accessTokenUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {

                if jsonResponse?.keys.contains("access_token")  == true {
                    let accessToken = jsonResponse!["access_token"]! as! String
                    successCallback(accessToken)
                }else {
                    let message = jsonResponse!["error_description"]! as! String
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

    func signIn(email:String, password:String, successCallback:(String,String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        var accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        var deviceToken = Helper.getDeviceToken()
        deviceToken = deviceToken == nil ? "cc47a697c74dc87531ee14ef6cd646add530a9284058c65b80bb168fc2e362f4" : deviceToken

        let parameters = ["access_token":accessToken!, "email":email, "password":password, "device_token":deviceToken!]
        sessionManager.POST(signInUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                if status == self.serverResponseSuccess {

                    let userId = jsonResponse!["id"]! as! String
                    let message = jsonResponse!["message"]! as! String
                    successCallback(userId, message)

                }else {

                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)

                }

            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

    func signUp(fromSignIn:Bool, name: String, email:String, password:String, school: String, signUpFrom: SignUpFrom, successCallback:(String, String, String, String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        var deviceToken = Helper.getDeviceToken()
        deviceToken = deviceToken == nil ? "cc47a697c74dc87531ee14ef6cd646add530a9284058c65b80bb168fc2e362f4" : deviceToken

        var action = "register"
        if fromSignIn {
            action = "sign-in"
        }
        let parameters = ["access_token":accessToken!, "action":action, "username":name, "email":email, "password":password, "school":school, "register_from":signUpFrom.rawValue,  "device_token":deviceToken!]
        sessionManager.POST(signUpUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                if signUpFrom != SignUpFrom.App {
                    failureCallback(Helper.genericErrorMsg)
                }else {
                    failureCallback(Helper.genericErrorMsg)
                }
                return
            }
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                if status == self.serverResponseSuccess {

                    let userId = jsonResponse!["id"]! as! String
                    let message = jsonResponse!["message"]! as! String

                    var school = ""
                    if let sch = jsonResponse!["school"] as? String {
                        school = sch
                    }

                    var profileImg = ""
                    if let prfImg = jsonResponse!["profile_image"] as? String {
                        profileImg = prfImg
                    }

                    successCallback(userId, message, school, profileImg)

                }else {

                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)

                }

            }else {

                if signUpFrom != SignUpFrom.App {
                    failureCallback(Helper.genericErrorMsg)
                }else {
                    failureCallback(Helper.genericErrorMsg)
                }

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                if signUpFrom != SignUpFrom.App {
                    failureCallback(Helper.genericErrorMsg)
                }else {
                    failureCallback(Helper.genericErrorMsg)
                }
            }

        })
    }

    func forgotPassword(email:String, successCallback:(String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let parameters = ["access_token":accessToken!, "email":email]
        sessionManager.POST(forgotPasswordUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                if status == self.serverResponseSuccess {

                    let message = jsonResponse!["message"]! as! String
                    successCallback(message)

                }else {

                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)

                }

            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }
    
    
    func getSchool(searchStr:String, successCallback:([String])->Void, failureCallback:(String)->Void) {
        
        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        var accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        
        let parameters = ["access_token":accessToken!, "keyword":searchStr]
        sessionManager.POST(getSchoolUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in
            
            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {
                
                let status = jsonResponse!["status"]! as! Bool
                if status == self.serverResponseSuccess {
                    
                    var schools = [String]()
                    
                    if let schoolsJson = jsonResponse!["schools"] as? Array<AnyObject> {
                        for json in schoolsJson {
                            let schoolJson = json as! Dictionary<String,AnyObject>
                            let school = schoolJson["value"]! as! String
                            schools.append(school)
                        }
                    }
                    successCallback(schools)
                    
                }else {
                    
                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)
                    
                }
                
            }else {
                
                failureCallback(Helper.genericErrorMsg)
                
            }
            
            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in
                
                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }
                
        })
    }

}

extension WebServices {

    func reportLocation(location:CLLocation) {

        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let parameters = ["access_token":accessToken!, "id":userId!, "latitude":String(location.coordinate.latitude), "longitude":String(location.coordinate.longitude)]
        sessionManager.POST(userUpdateUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                print("reportLocation response nil")
            }else {
                print("reportLocation response success ")
            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print("reportLocation " + error.localizedDescription)
            }

        })

    }

    func getUser(successCallback:(String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let url = userGetUrl + userId! + "?access_token=" + accessToken!
        sessionManager.GET(url, parameters: nil, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                User.getSharedUser().loadUserFromJson(jsonResponse!)
                successCallback("User loaded")

            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

    func setUser(var parameters:[String:AnyObject], successCallback:(String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        parameters["access_token"] = accessToken!
        parameters["id"] = userId!
        parameters["method"] = "UPDATE"
    
        sessionManager.POST(userUpdateUrl, parameters: parameters,  success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

                if response == nil {
                    failureCallback(Helper.genericErrorMsg)
                    return
                }

                if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                    let status = jsonResponse!["status"]! as! Bool
                    if status == self.serverResponseSuccess {

                        self.getUser(successCallback, failureCallback: failureCallback)

                    }else {

                        let message = jsonResponse!["message"]! as! String
                        failureCallback(message)

                    }

                }else {

                    failureCallback(Helper.genericErrorMsg)

                }

            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }

        })
    }

    func uploadImage(imageName:String, imageData:NSData, successCallback:(String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let parameters = ["access_token":accessToken!, "id":userId!, "to_update":imageName]

        sessionManager.POST(imageUploadUrl, parameters: parameters, constructingBodyWithBlock: { (formData:AFMultipartFormData!) -> Void in

            formData.appendPartWithFileData(imageData, name: imageName + "_image", fileName:"image.png", mimeType: "image/jpeg")

        },  success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }else if let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {
                    successCallback(message)
                }else {
                    failureCallback(message)
                }

            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

    func getLiveData(successCallback:(Int, Int, Int, Int, Int, String)->Void, failureCallback:(String)->Void) {

        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let url = liveDataUrl + userId! + "?access_token=" + accessToken!
        sessionManager.GET(url, parameters: nil, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {
                    
                    let likes = jsonResponse!["likes"]! as! Int
                    let coffeeCount = jsonResponse!["coffee_count"]! as! Int
                    let biteCount = jsonResponse!["bite_count"]! as! Int
                    let contentCount = jsonResponse!["content_count"]! as! Int
                    let eventCount = jsonResponse!["event_count"]! as! Int

                    successCallback(likes, contentCount, eventCount, coffeeCount, biteCount, message)

                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }

        })
    }

}

extension WebServices {

    func getAlumniAround(successCallback:(String, [Alumni])->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let url = alumniAroundUrl + userId! + "?access_token=" + accessToken!
        sessionManager.GET(url, parameters: nil, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {

                    let alumni = Alumni.makeAlumniAroundFrom(jsonResponse!)
                    successCallback(message, alumni)
                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }

        })
    }

    func inviteAlumi(alumniId:String, invite:String, successCallback:(String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let parameters = ["access_token":accessToken!, "sender_id":userId!, "receiver_id":alumniId, "invitation":invite]
        sessionManager.POST(inviteAlumiUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                if status == self.serverResponseSuccess {

                    let message = jsonResponse!["message"]! as! String
                    successCallback(message)

                }else {

                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)

                }

            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

    func searchAlumni(searchTxt:String, successCallback:(String, [Alumni])->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let parameters = ["access_token":accessToken!, "id":userId!, "search_text":searchTxt]
        sessionManager.POST(searchAlumniUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {

                    let alumni = Alumni.makeAlumniAroundFrom(jsonResponse!)
                    successCallback(message, alumni)
                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

}

extension WebServices {

    func getFeeds(feedFor:String, successCallback:(String, Int, [Feed])->Void, failureCallback:(String)->Void) {
        
        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        
        let userId = Helper.getUserId()
        if userId == nil {
            return
        }
        
        var filterDate = ""
        let dateKey = feedFor + "_date" + userId!
        if let date = Helper.getValueForKey(dateKey) as? String {
            filterDate = date
        }
        
        let parameters = ["access_token":accessToken!, "id":userId!, "feed_for":feedFor, "date":filterDate]
        
        sessionManager.POST(feedsUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in
            
            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            
            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {
                
                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {
                    
                    let mergedJson = Feed.mergeOldAndNewFeed(feedFor, jsonResponse: jsonResponse!)
                    let feeds = Feed.makeFeedsFromJson(mergedJson)
                    let newPostsCount = jsonResponse!["new_posts_count"]! as! Int
                    
                    let date = jsonResponse!["current_date"]! as! String
                    Helper.saveValue(date, forKey: dateKey)
                    
                    successCallback(message, newPostsCount, feeds)
                    
                }else {
                    failureCallback(message)
                }
                
                
            }else {
                
                failureCallback(Helper.genericErrorMsg)
                
            }
            
            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in
                
                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }
                
        })
        
    }

    func respondFeed(feedId:String, response:String, successCallback:(String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let parameters = ["access_token":accessToken!, "id":userId!, "invitation_id":feedId, "response":response]
        sessionManager.POST(respondFeedUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                if status == self.serverResponseSuccess {

                    let message = jsonResponse!["message"]! as! String
                    successCallback(message)

                }else {

                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)

                }

            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

}

extension WebServices {

    func addEvent(eventId:String?, eventName:String, date:String, time:String, location:String, description:String, isPrivate:String, successCallback:(String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        var parameters = ["access_token":accessToken!, "id":userId!, "event_name":eventName, "date":date, "time":time, "place_of_event":location, "description":description, "is_private":isPrivate]
        if eventId != nil {
            parameters["event_id"] = eventId!
        }
        sessionManager.POST(addEventUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                if status == self.serverResponseSuccess {

                    let message = jsonResponse!["message"]! as! String
                    successCallback(message)

                }else {

                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)

                }

            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

    func getEvents(successCallback:(String,[Event])->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let url = eventsUrl + userId! + "?access_token=" + accessToken!
        sessionManager.GET(url, parameters: nil, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {

                    let events = Event.makeEventsFromJson(jsonResponse!)
                    successCallback(message, events)

                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }

        })
    }

    func getEventAttendees(eventId:String, successCallback:(String,[Attendee])->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }


        let parameters = ["access_token":accessToken!, "id":userId!, "event_id":eventId]
        sessionManager.POST(eventAttendeesUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {

                    let events = Attendee.makeAttendeesFromJson(jsonResponse!)
                    successCallback(message, events)

                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }

        })
    }

    func sendEventInvite(eventId:String, receiverId:String, successCallback:(String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let parameters = ["access_token":accessToken!, "sender_id":userId!, "event_id":eventId, "receiver_id":receiverId, "invitation":"event"]
        sessionManager.POST(eventInviteUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                if status == self.serverResponseSuccess {

                    let message = jsonResponse!["message"]! as! String
                    successCallback(message)

                }else {

                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)

                }

            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

    func eventInviteRespond(eventId:String, response:String, successCallback:(String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let parameters = ["access_token":accessToken!, "id":userId!, "invitation_id":eventId, "response":response]
        sessionManager.POST(eventInviteRespondUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                if status == self.serverResponseSuccess {

                    let message = jsonResponse!["message"]! as! String
                    successCallback(message)

                }else {

                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)

                }

            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }
}

extension WebServices {

    func getContacts(successCallback:(String,[Contact])->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let url = contactsUrl + userId! + "?access_token=" + accessToken!
        sessionManager.GET(url, parameters: nil, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {

                    let contacts = Contact.makeContactsFromJson(jsonResponse!)
                    successCallback(message, contacts)

                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

    func getContactDetail(contactId:String,successCallback:(String,ContactDetail)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let parameters = ["id": userId!, "access_token": accessToken!, "contact_id":contactId]
        sessionManager.POST(contactDetialUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {

                    let contactDetail = ContactDetail.makeContactDetailFromJson(jsonResponse!)
                    successCallback(message, contactDetail)

                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }
}

extension WebServices {

    func getSocialConnections(successCallback:(String,SocialConnections)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        let url = socialConnectionsUrl + userId! + "?access_token=" + accessToken!
        sessionManager.GET(url, parameters: nil, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {

                    let socialConnections = SocialConnections.makeSocialConnectionsFromJson(jsonResponse!)
                    successCallback(message, socialConnections)

                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

    func setSocialConnection(var parameters:[String:String],successCallback:(String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }

        parameters["id"] = userId!
        parameters["access_token"] = accessToken!

        sessionManager.POST(setSocialConnectionUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {
                    successCallback(message)
                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

            if error != nil {
                print(error.localizedDescription)
                failureCallback(Helper.genericErrorMsg)
            }

        })
    }

    func getImage(url:String, successCallback:(UIImage)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let url = NSURL(string: url)

        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) {
            if let data = NSData(contentsOfURL: url!) {
                successCallback(UIImage(data: data)!)
            }else {
                failureCallback(Helper.genericErrorMsg)
            }
        }

    }
}

extension WebServices {

    func getContentMeta(url:String, successCallback:(String,ContentMeta)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }


        let parameters = ["access_token":accessToken!, "id":userId!, "url":url]
        sessionManager.POST(contentMetaUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {

                    let contentMeta = ContentMeta.makeContentMetaFromJson(jsonResponse!)
                    successCallback(message, contentMeta)

                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }

        })
    }

    func shareContent(url:String, school:String, successCallback:(String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }


        let parameters = ["access_token":accessToken!, "user_id":userId!, "url":url, "school": school]
        sessionManager.POST(shareContentUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {
                    successCallback(message)
                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }

        })
    }

    func toggleLikeContent(contentId:String, successCallback:(Int, String)->Void, failureCallback:(String)->Void) {

        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }

        let userId = Helper.getUserId()
        if userId == nil {
            return
        }


        let parameters = ["access_token":accessToken!, "user_id":userId!, "content_id":contentId]
        sessionManager.POST(likeContentUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in

            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }

            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {

                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {

                    let likes = jsonResponse!["likes"]! as! Int
                    successCallback(likes, message)
                }else {
                    failureCallback(message)
                }


            }else {

                failureCallback(Helper.genericErrorMsg)

            }

            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in

                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }

        })
    }

}

extension WebServices {

    func getJobs(jobsFilter:String, successCallback:(String, [Job])->Void, failureCallback:(String)->Void) {
        
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        
        let userId = Helper.getUserId()
        if userId == nil {
            return
        }
        
        let parameters = ["access_token":accessToken!, "user_id":userId!, "filter":jobsFilter]
        sessionManager.POST(jobsUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in
            
            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            
            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {
                
                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {
                    
                    let jobs = Job.makeJobsFromJson(jsonResponse!)
                    successCallback(message, jobs)
                    
                }else {
                    failureCallback(message)
                }
                
                
            }else {
                
                failureCallback(Helper.genericErrorMsg)
                
            }
            
            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in
                
                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }
                
        })
        
    }
    
    func applyForJob(jobId:String, successCallback:(String)->Void, failureCallback:(String)->Void) {
        
        if !Helper.isNetworkAvailable() {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        let accessToken = Helper.getAccessToken()
        if accessToken == nil {
            failureCallback(Helper.genericErrorMsg)
            return
        }
        
        let userId = Helper.getUserId()
        if userId == nil {
            return
        }
        
        let parameters = ["access_token":accessToken!, "user_id":userId!, "job_id":jobId]
        sessionManager.POST(applyJobUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in
            
            if response == nil {
                failureCallback(Helper.genericErrorMsg)
                return
            }
            
            if  let jsonResponse = response as? Dictionary<String,AnyObject>? {
                
                let status = jsonResponse!["status"]! as! Bool
                let message = jsonResponse!["message"]! as! String
                if status == self.serverResponseSuccess {
                    
                    successCallback(message)
                    
                }else {
                    failureCallback(message)
                }
                
                
            }else {
                
                failureCallback(Helper.genericErrorMsg)
                
            }
            
            }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in
                
                if error != nil {
                    print(error.localizedDescription)
                    failureCallback(Helper.genericErrorMsg)
                }
                
        })
        
    }
    
}
