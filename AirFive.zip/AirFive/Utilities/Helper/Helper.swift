//
//  Helper.swift
//  AirFive
//
//  Created by Anil Gautam on 10/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class Helper {
    
    static func getAppWhiteColor() -> UIColor {
        return UIColor(white: 255.0/255.0, alpha: 1.0)
    }

    static func getAppBlackColor() -> UIColor {
        return UIColor(white: 50.0/255.0, alpha: 1.0)
    }
    
    static func getAppGreyColor() -> UIColor {
        return UIColor(white: 192.0/255.0, alpha: 1.0)
    }
    
    static func getAppGreenColor() -> UIColor {
        return UIColor(red: 108.0/255.0, green: 200.0/255.0, blue: 206.0/255.0, alpha: 1.0)
    }
    
    static func showAlert(title:String, message:String) {
        let alert = UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: "OK")
        alert.show()
    }
    
    static func isValidEmail(email:String) -> Bool {
        
        let emailRegEx = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluateWithObject(email)
        
    }
    
    static func getNormalFont(size:CGFloat = 12) -> UIFont {
        return UIFont(name: "Roboto-Regular", size: size)!
    }
    
    static func getBoldFont(size:CGFloat = 12) -> UIFont {
        return UIFont(name: "Roboto-Bold", size: size)!
    }
    
    static func printAllFonts() {
        let fontFamilies = UIFont.familyNames()
        for family in fontFamilies {
            let font = UIFont.fontNamesForFamilyName(family)
            print("\(family) \(font)")
        }
    }
    
    static func saveValue(value:AnyObject?, forKey key:String) {
        NSUserDefaults.standardUserDefaults().setObject(value, forKey: key)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    static func getValueForKey(key:String) -> AnyObject? {
        return NSUserDefaults.standardUserDefaults().objectForKey(key)
    }
    
    static func saveUserToken(userToken:Int) {
        saveValue(userToken, forKey: "userToken")
    }
    
    static func getUserToken() -> Int? {
        let userToken = getValueForKey("userToken")
        if userToken != nil {
            return userToken! as? Int
        }
        return nil
    }
    
}


extension Helper {
    
    static func showAlert(title:String, message:String, isSuccess:Bool) -> KLCPopup {
        
        let textColor:UIColor! = UIColor.whiteColor()
        
        //Creating view
        let container = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 100))
        container.backgroundColor = getAppGreenColor()
        
        let margin:CGFloat = 5
        let titleLbl = UILabel(frame: CGRect(x: margin, y: margin, width: container.frame.size.width - 2 * margin, height: 20))
        titleLbl.textColor = textColor
        titleLbl.font = getBoldFont(14)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.text = title
        
        let messageLbl = UILabel(frame: CGRect(x: margin, y: titleLbl.frame.origin.y + titleLbl.frame.size.height  + margin / 2, width: container.frame.size.width - 2 * margin, height: 40))
        messageLbl.textColor = textColor
        messageLbl.font = getNormalFont()
        messageLbl.textAlignment = NSTextAlignment.Center
        messageLbl.numberOfLines = 0
        messageLbl.text = message
        
        let line = UIView(frame: CGRect(x: 0, y: messageLbl.frame.origin.y + messageLbl.frame.size.height + margin / 2, width: container.frame.size.width, height: 1))
        line.backgroundColor = getAppBlackColor()
        
        let okBtn = UIBlockButton(frame: CGRect(x: 0, y: line.frame.origin.y + line.frame.size.height, width: container.frame.size.width, height: 30))
        
        container.addSubview(titleLbl)
        container.addSubview(messageLbl)
        container.addSubview(line)
        container.addSubview(okBtn)
        
        let klcPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        
        okBtn.setup("OK", color: textColor, alignment: UIControlContentHorizontalAlignment.Center, callback:  { (btn:UIBlockButton) -> Void in
          
            klcPopup.dismissPresentingPopup()
            
        })
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        klcPopup.showWithLayout(layout)
        
        return klcPopup
        
    }
}









