//
//  Helper.swift
//  AirFive
//
//  Created by Anil Gautam on 10/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class Helper {
    
    static let genericErrorMsg = "\u{1f914} Hmm, that didn't seem to work, please try again"
    static let genericLoadingMsg = "Loading, make a wish"
    static let appLink = "https://itunes.apple.com/ca/app/airfive/id1055501677?mt=8"
    static let inviteMsg = "I just downloaded AirFive - be sure to check it out!"
    static let shareMsg = "I just created an event using AirFive - download it to see when & where!"
    static let postJobUrl = "https://www.airfivejobs.com/add-a-job/"
    
    static func getAppWhiteColor() -> UIColor {
        return UIColor(white: 255.0/255.0, alpha: 1.0)
    }

    static func getAppBlackColor() -> UIColor {
        return UIColor(white: 50.0/255.0, alpha: 1.0)
    }
    
    static func getAppGreyColor() -> UIColor {
        return UIColor(white: 192.0/255.0, alpha: 1.0)
    }
    
    static func getAppGreenColor() -> UIColor {
        return UIColor(red: 108.0/255.0, green: 200.0/255.0, blue: 206.0/255.0, alpha: 1.0)
    }
    
    static func getAppDarkGreenColor() -> UIColor {
        return UIColor(red: 58.0/255.0, green: 150.0/255.0, blue: 156.0/255.0, alpha: 1.0)
    }
    
    static func getFacebookColor() -> UIColor {
        return UIColor(red: 20.0/255.0, green: 82.0/255.0, blue: 225.0/255.0, alpha: 1.0)
    }
    
    static func getLinkedinColor() -> UIColor {
        return UIColor(red: 29.0/255.0, green: 140.0/255.0, blue: 181.0/255.0, alpha: 1.0)
    }
    
    static func isValidEmail(email:String) -> Bool {
        
        let emailRegEx = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluateWithObject(email)
        
    }
    
    static func getNormalFont(size:CGFloat = 12) -> UIFont {
        return UIFont(name: "SFUIDisplay-Regular", size: size)!
    }
    
    static func getBoldFont(size:CGFloat = 12) -> UIFont {
        return UIFont(name: "SFUIDisplay-Bold", size: size)!
    }
    
    static func printAllFonts() {
        let fontFamilies = UIFont.familyNames()
        for family in fontFamilies {
            let font = UIFont.fontNamesForFamilyName(family)
            print("\(family) \(font)")
        }
    }
    
    static func getTopRootViewController() -> UIViewController! {
        
        var topRootViewController = UIApplication.sharedApplication().keyWindow!.rootViewController
        while ((topRootViewController!.presentedViewController) != nil){
            topRootViewController = topRootViewController!.presentedViewController;
        }
        return topRootViewController
    }
    
    static func presentViewController(viewController:UIViewController!, animated:Bool) {
        
        let topRootViewController = getTopRootViewController()
        topRootViewController!.presentViewController(viewController!, animated: animated, completion: nil)
        
    }
    
    static func presentViewControllerWithIdentifier(viewControllerIdentifier:String, animated:Bool) {
        
        let topRootViewController = getTopRootViewController()
        let viewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier(viewControllerIdentifier)
        topRootViewController!.presentViewController(viewController, animated: animated, completion: nil)
        
    }
    
    static func dismissViewController(animated:Bool) {
        
        var topRootViewController = UIApplication.sharedApplication().keyWindow!.rootViewController
        while ((topRootViewController!.presentedViewController) != nil){
            topRootViewController = topRootViewController!.presentedViewController;
        }
        
        topRootViewController!.dismissViewControllerAnimated(animated, completion: nil)
        
    }
    
    static func dayNameFromDate(dateStr:String) -> String {
    
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let date = dateFormatter.dateFromString(dateStr)
        dateFormatter.dateFormat = "EEE"
        return dateFormatter.stringFromDate(date!)
        
    }
    
    static func isNetworkAvailable() -> Bool {
        return AFNetworkReachabilityManager.sharedManager().reachable
    }
    
    static func convertStringToDictionary(text: String) -> [String:AnyObject]? {
        if let data = text.dataUsingEncoding(NSUTF8StringEncoding) {
            do {
                return try NSJSONSerialization.JSONObjectWithData(data, options: []) as? [String:AnyObject]
            } catch let error as NSError {
                print(error)
            }
        }
        return nil
    }
    
    static func getFileURL(fileName: String) -> String {
        var filePath = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true).first!
        filePath = (filePath as NSString).stringByAppendingPathComponent(fileName) as String
        return filePath
    }

    
}

extension Helper {

    static func saveValue(value:AnyObject?, forKey key:String) {
        NSUserDefaults.standardUserDefaults().setObject(value, forKey: key)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    static func getValueForKey(key:String) -> AnyObject? {
        return NSUserDefaults.standardUserDefaults().objectForKey(key)
    }
    
    static func saveUserId(userId:String?) {
        saveValue(userId, forKey: "userId")
    }
    
    static func getUserId() -> String? {
        let userId = getValueForKey("userId")
        if userId != nil {
            return userId! as? String
        }
        return nil
    }
    
    static func saveAccessToken(accessToken:String?) {
        saveValue(accessToken, forKey: "accessToken")
    }
    
    static func getAccessToken() -> String? {
        let accessToken = getValueForKey("accessToken")
        if accessToken != nil {
            return accessToken! as? String
        }
        return nil
    }
   
    static func saveDeviceToken(deviceToken:String?) {
        saveValue(deviceToken, forKey: "deviceToken")
    }
    
    static func getDeviceToken() -> String? {
        let deviceToken = getValueForKey("deviceToken")
        if deviceToken != nil {
            return deviceToken! as? String
        }
        return nil
    }
    
    static func setTourShown() {
        saveValue("true", forKey: "tourShown")
    }
    
    static func isTourShow() -> Bool {
        if let tourShown = getValueForKey("tourShown") {
            return true
        }
        return false
    }
    
    
}


extension Helper {
    
    static func showAlert(title:String, message:String) {
    
        let alert = UIAlertView(title: title, message: message, delegate: nil, cancelButtonTitle: "OK")
        alert.show()
        
    }
    
    static func showAlertCustom(title:String, message:String, isSuccess:Bool) -> KLCPopup {
        
        let textColor:UIColor! = UIColor.whiteColor()
        
        //Creating view
        let container = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 100))
        container.backgroundColor = getAppGreenColor()
        
        let margin:CGFloat = 5
        let titleLbl = UILabel(frame: CGRect(x: margin, y: margin, width: container.frame.size.width - 2 * margin, height: 20))
        titleLbl.textColor = textColor
        titleLbl.font = getBoldFont(14)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.text = title
        
        let messageLbl = UILabel(frame: CGRect(x: margin, y: titleLbl.frame.origin.y + titleLbl.frame.size.height  + margin / 2, width: container.frame.size.width - 2 * margin, height: 40))
        messageLbl.textColor = textColor
        messageLbl.font = getNormalFont()
        messageLbl.textAlignment = NSTextAlignment.Center
        messageLbl.numberOfLines = 0
        messageLbl.text = message
        
        let line = UIView(frame: CGRect(x: 0, y: messageLbl.frame.origin.y + messageLbl.frame.size.height + margin / 2, width: container.frame.size.width, height: 1))
        line.backgroundColor = getAppBlackColor()
        
        let okBtn = UIBlockButton(frame: CGRect(x: 0, y: line.frame.origin.y + line.frame.size.height, width: container.frame.size.width, height: 30))
        
        container.addSubview(titleLbl)
        container.addSubview(messageLbl)
        container.addSubview(line)
        container.addSubview(okBtn)
        
        let klcPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        
        okBtn.setup("OK", color: textColor, alignment: UIControlContentHorizontalAlignment.Center, callback:  { (btn:UIBlockButton) -> Void in
          
            klcPopup.dismissPresentingPopup()
            
        })
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        klcPopup.showWithLayout(layout)
        
        return klcPopup
        
    }
    
    static func showPopupWithView(containerView:UIView) -> KLCPopup {
    
        let klcPopup = KLCPopup(contentView: containerView, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        klcPopup.showWithLayout(layout)
        
        return klcPopup
        
    }
    
    private static var customProgress:UIView! = nil
    private static var cPHandImg:UIImageView! = nil
    static func showCustomProgress(viewController:UIViewController) {
        
        if customProgress == nil {
            createCustomProgress()
        }
        customProgress.removeFromSuperview()
        viewController.view.addSubview(customProgress)
        startHandAnimation()
        
    }
    
    static func hideCustomProgress() {
        
        if customProgress != nil {
            customProgress.removeFromSuperview()
        }
        
    }
    
    private static func createCustomProgress() {
        
        let width = 60.0
        let height = width * 1.14 + 10
        
        customProgress = UIView(frame: CGRect(x: 0.0, y: 0.0, width: height, height: height))
        customProgress.backgroundColor = UIColor.whiteColor()
        customProgress.layer.cornerRadius = 3
        customProgress.layer.shadowOpacity = 1
        customProgress.layer.shadowColor = getAppBlackColor().CGColor
        customProgress.layer.shadowOffset = CGSize(width: 0, height: 0)
        
        cPHandImg = UIImageView(frame: CGRect(x: 0.0, y: 0.0, width: width, height: height - 10))
        cPHandImg.image = UIImage(named:"handIcon")
        cPHandImg.center = CGPoint(x: height / 2, y: height / 2)
        
        customProgress.addSubview(cPHandImg)
        
        customProgress.center = CGPoint(x: UIScreen.mainScreen().bounds.size.width / 2, y: UIScreen.mainScreen().bounds.size.height / 2)
        
    }
    
    private static func startHandAnimation() {
        
        if cPHandImg.layer.animationForKey("rotationanimationkey") == nil {
            let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")
            
            rotationAnimation.fromValue = 0.0
            rotationAnimation.toValue = Float(M_PI * 2.0)
            rotationAnimation.duration = 1.5
            rotationAnimation.repeatCount = Float.infinity
            
            cPHandImg.layer.addAnimation(rotationAnimation, forKey: "rotationanimationkey")
        }
        
    }
    
}









