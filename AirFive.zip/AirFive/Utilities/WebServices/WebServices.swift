//
//  WebServices.swift
//  AirFive
//
//  Created by Anil Gautam on 11/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class WebServices {
    
    private static var sharedWebSevices:WebServices! = nil
    
    static func getSharedWebServices() -> WebServices {
        if sharedWebSevices == nil {
            sharedWebSevices = WebServices()
        }
        return sharedWebSevices
    }

    let baseUrl = ""
    
    let signInUrl = ""
    let signUpUrl = ""
    let signInOtherUrl = ""
    let forgotPasswordUrl = ""
    
    let serverResponseSuccess = 1
    let serverResponseFailure = 0
    
    let sessionManager:AFHTTPSessionManager!
    
    private init() {
    
        sessionManager = AFHTTPSessionManager(baseURL: NSURL(string: baseUrl))
        sessionManager.responseSerializer = AFJSONResponseSerializer()
        
    }
    
    func signIn(email:String, password:String, successCallback:(Int)->Void, failureCallback:(String)->Void) {
    
        let parameters = ["email":email, "password":password]
        sessionManager.POST(signInUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in
            
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {
                
                let status = jsonResponse!["status"]! as! Int
                if status == self.serverResponseSuccess {
                
                    let userToken = jsonResponse!["userToken"]! as! Int
                    successCallback(userToken)
                    
                }else {
                    
                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)
                    
                }
                
            }else {
                
                failureCallback("Can't sign in. Kindly try later.")
                
            }
            
        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in
            
            if error != nil {
                print(error.localizedDescription)
                failureCallback("Can't sign in. Kindly try later.")
            }
            
        })
    }
    
    func signUp(name: String, email:String, password:String, school: String, signUpFrom: SignUpFrom, successCallback:(Int)->Void, failureCallback:(String)->Void) {
        
        let parameters = ["name":name, "email":email, "password":password, "school":school, "signUpFrom":signUpFrom.rawValue]
        sessionManager.POST(signUpUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in
            
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {
                
                let status = jsonResponse!["status"]! as! Int
                if status == self.serverResponseSuccess {
                    
                    let userToken = jsonResponse!["userToken"]! as! Int
                    successCallback(userToken)
                    
                }else {
                    
                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)
                    
                }
                
            }else {
                
                if signUpFrom != SignUpFrom.App {
                    failureCallback("Can't process. Kindly try later.")
                }else {
                    failureCallback("Can't sign up. Kindly try later.")
                }
                
            }
            
        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in
                
            if error != nil {
                print(error.localizedDescription)
                if signUpFrom != SignUpFrom.App {
                    failureCallback("Can't process. Kindly try later.")
                }else {
                    failureCallback("Can't sign up. Kindly try later.")
                }
            }
                
        })
    }
    
    func signInOther(email:String, method:String, successCallback:(AnyObject)->Void, failureCallback:(String)->Void) {
        
        let parameters = ["email":email, "method":method]
        sessionManager.POST(signInOtherUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in
            
            successCallback(response)
            
        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in
                
            if error != nil {
                print(error.localizedDescription)
                failureCallback("Can't sign in. Kindly try later.")
            }
                
        })
    }
    
    func forgotPassword(email:String, successCallback:(String)->Void, failureCallback:(String)->Void) {
        
        let parameters = ["email":email]
        sessionManager.POST(forgotPasswordUrl, parameters: parameters, success: { (dataTask:NSURLSessionDataTask!, response:AnyObject!) -> Void in
            
            if let jsonResponse = response as? Dictionary<String,AnyObject>? {
                
                let status = jsonResponse!["status"]! as! Int
                if status == self.serverResponseSuccess {
                    
                    successCallback("New password is sent to your email id.")
                    
                }else {
                    
                    let message = jsonResponse!["message"]! as! String
                    failureCallback(message)
                    
                }
                
            }else {
                
                failureCallback("Can't process. Kindly try later.")
                
            }
            
        }, failure: { (dataTask:NSURLSessionDataTask!, error:NSError!) -> Void in
                
            if error != nil {
                print(error.localizedDescription)
                failureCallback("Can't process. Kindly try later.")
            }
                
        })
    }
}




