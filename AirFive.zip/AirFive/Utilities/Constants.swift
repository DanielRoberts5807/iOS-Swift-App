//
//  Constants.swift
//  AirFive
//
//  Created by Anil Gautam on 12/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

enum SignUpFrom : String {
    case App = "ios_app"
    case Facebook = "facebook"
    case Linkedin = "linkedin"
}

enum SelectedLblPosition : Int {
    case Left = 0
    case Right = 1
}

enum FeedType : String {
    case Event = "event"
    case Other = "other"
    case Content = "content"
}

enum FeedAction : String {
    case Bite = "Accept Bite"
    case Coffee = "Accept Coffee"
    case Info = "OK!"
    case Event = "Going!"
    case EventDetail = "Event Details!"
    case InfoEvent = "Beans!"
    case InfoContact = "Contact Card!"
    case Content = "Content"
}

enum EventType : String {
    case Event = "event"
    case Invite = "invite"
}

enum FeedsFilter : String {
    case Jobs = "jobs"
    case Content = "content"
    case Events = "event"
    case Coffee = "coffee"
    case Bite = "bite"
}

enum JobFilter : String {
    case Nearest = "nearest"
    case Internship = "internship"
    case PartTime = "part_time_job"
    case FullTime = "full_time_job"
}

class Constants {
    
}




