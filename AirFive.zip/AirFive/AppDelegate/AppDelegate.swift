//
//  AppDelegate.swift
//  AirFive
//
//  Created by Anil Gautam on 10/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import EventKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        application.statusBarStyle = UIStatusBarStyle.Default
        LocationLoader.getSharedLocationLoader()
        AFNetworkReachabilityManager.sharedManager().startMonitoring()
        
        let notificationSettings = UIUserNotificationSettings(forTypes: [UIUserNotificationType.Alert, UIUserNotificationType.Badge, UIUserNotificationType.Sound], categories: nil)
        UIApplication.sharedApplication().registerUserNotificationSettings(notificationSettings)
        UIApplication.sharedApplication().registerForRemoteNotifications()
        
        GooglePlacesLoader.getSharedGooglePlacesLoader()
        
        let navigationController = window?.rootViewController as! UINavigationController
        
        var viewControllerIdentifier = "TourViewController"
        if Helper.isTourShow() {
            if Helper.getUserId() == nil {
                viewControllerIdentifier = "SignInViewController"
            }else {
                viewControllerIdentifier = "MenuRootViewController"
            }
        }
        let viewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier(viewControllerIdentifier)
        navigationController.viewControllers = [viewController]
        
        if launchOptions != nil {
            if let apns = launchOptions![UIApplicationLaunchOptionsRemoteNotificationKey] {
                APNSHandler.getSharedAPNSHandler().handleAPNS(apns as! [NSObject: AnyObject])
            }
            
            if let url = launchOptions![UIApplicationLaunchOptionsURLKey] {
                if (url as! NSURL).absoluteString == "airfive://" {
                    return true
                }
            }
        }
        
        return FBSDKApplicationDelegate.sharedInstance().application(application, didFinishLaunchingWithOptions: launchOptions)
        
    }
    
    func application(application: UIApplication, openURL url: NSURL, sourceApplication: String?, annotation: AnyObject) -> Bool {
    
        if url.absoluteString == "airfive://" {
            let delayTime = dispatch_time(DISPATCH_TIME_NOW, Int64(0.9 * Double(NSEC_PER_SEC)))
            dispatch_after(delayTime, dispatch_get_main_queue()) {
                Helper.showAlert("", message: "Account va-va-va-Verified! Good job! \u{1f44d}")
            }
        }
        return FBSDKApplicationDelegate.sharedInstance().application(application, openURL: url, sourceApplication: sourceApplication, annotation: annotation)
        
    }
    
    func application(application: UIApplication, handleOpenURL url: NSURL) -> Bool {
        return true
    }
    
    func application(application: UIApplication, didRegisterUserNotificationSettings notificationSettings: UIUserNotificationSettings) {
        if notificationSettings.types != .None {
            application.registerForRemoteNotifications()
        }
    }

    func application(application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: NSError) {
        print("Failed to register for remote notitifcaitoins %s", error)
    }
    
    func application(application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: NSData) {
        
        let trimEnds = deviceToken.description.stringByTrimmingCharactersInSet(
            NSCharacterSet(charactersInString: "<>"))
        
        let cleanToken = trimEnds.stringByReplacingOccurrencesOfString(
            " ", withString: "")
        print("Registered for remote notifications " + cleanToken)
        
        Helper.saveDeviceToken(cleanToken)
        
    }
    
    func application(application: UIApplication, didReceiveRemoteNotification userInfo: [NSObject : AnyObject]) {
        APNSHandler.getSharedAPNSHandler().handleAPNS(userInfo)
    }
    
    func applicationWillResignActive(application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(application: UIApplication) {
//        saveEventsToCalendar()
    }

    func applicationWillEnterForeground(application: UIApplication) {
        // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(application: UIApplication) {
        getAccessToken()
    }

    func applicationWillTerminate(application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    func saveEventsToCalendar() {
        
        if let calendarAccessGranted = Helper.getValueForKey("calendarAccessGranted") as? Bool {
            
            if !calendarAccessGranted {
                return
            }
            
            WebServices.getSharedWebServices().getEvents({ (message:String, events:[Event]) -> Void in
                
                let dateFormatter = NSDateFormatter()
                
                for event in events {
                    
                    if let _ = Helper.getValueForKey(event.id) {
                        continue
                    }
                    
                    let store = EKEventStore()
                    let calEvent = EKEvent(eventStore: store)
                    
                    calEvent.title = event.title
                    calEvent.location = event.location
                    calEvent.notes = event.description
                    
                    dateFormatter.dateFormat = "MM/dd/yyyy HH:mm"
                    let date = dateFormatter.dateFromString(String(format:"%02d",event.month) + "/" + String(format:"%02d",event.day) + "/" + String(event.year) + " " + String(format:"%02d",event.hour) + ":" + String(format:"%02d",event.minute))
                    
                    calEvent.startDate = date!
                    calEvent.endDate = date!.dateByAddingTimeInterval(10*60)
                    calEvent.calendar = store.defaultCalendarForNewEvents
                    
                    do {
                        try store.saveEvent(calEvent, span: .ThisEvent, commit: true)
                        Helper.saveValue(true, forKey: event.id)
                    } catch {
                    }
                }
                
                }, failureCallback: { (message:String) -> Void in
                    
                    print(message)
            })

            
        }
        
    }

    func getAccessToken() {
        
        WebServices.getSharedWebServices().getAccessToken({ (accessToken:String) -> Void in
            
            Helper.saveAccessToken(accessToken)
            
        }, failureCallback:  { (message:String) -> Void in
                
//            Helper.saveAccessToken(nil)
            
        })
    }

}

