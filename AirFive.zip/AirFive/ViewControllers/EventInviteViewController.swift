//
//  EventInviteViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 11/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit
import FBSDKShareKit

class EventInviteViewController : BaseViewController {
    
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var locationLbl: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var timeLbl: UILabel!
    @IBOutlet weak var descriptionLbl: TopAlignedLabel!
    
    @IBOutlet weak var editBtn: UIButton!
    
    @IBOutlet weak var attendeesLbl: UILabel!
    @IBOutlet weak var attendeesTbl: UITableView!
    
    var event:Event! = nil
    var attendees:[Attendee] = []
    var dataLoadedFromServer = false
    
    var tblController:UITableViewController!
    var refresh:UIRefreshControl!
    
    var showProgress:Bool = true
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        attendeesTbl.tableFooterView = UIView()
        setEventData()
        setRefreshControl()
        
    }
    
    func setRefreshControl() {
        tblController = UITableViewController()
        tblController.tableView = attendeesTbl
        
        refresh = UIRefreshControl()
        refresh.tintColor = Helper.getAppBlackColor()
        let attributes = [NSForegroundColorAttributeName:Helper.getAppBlackColor(), NSFontAttributeName:Helper.getNormalFont(10)]
        refresh.attributedTitle = NSMutableAttributedString(string: "Loading...", attributes: attributes)
        refresh.addTarget(self, action: "loadDataFromServer", forControlEvents: UIControlEvents.ValueChanged)
        
        tblController.refreshControl = refresh
        
    }
    
    func setEventData() {
    
        editBtn.hidden = true
        if event != nil {
            
            titleLbl.text = event.title
            
            locationLbl.text = event.location
            locationLbl.textColor = Helper.getAppGreenColor()
            
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateFormat = "MM-dd-yyyy"
            let date = dateFormatter.dateFromString(String(format:"%02d",event.month) + "-" + String(format:"%02d",event.day) + "-" + String(event.year))
            dateFormatter.dateFormat = "MMMM dd, yyyy"
            dateLbl.text = dateFormatter.stringFromDate(date!)
            
            var time = String(format: "%02d",event.hour % 12) + ":" + String(format: "%02d",event.minute) + " "
            if event.hour > 12 {
                time += "PM"
            }else {
                time += "AM"
            }
            timeLbl.text = time
            
            descriptionLbl.text = event.description
            
            if let userId = Helper.getUserId() {
                if userId == event.userId {
                    editBtn.hidden = false
                }
            }
            
            setAttendeesLbl()
            
        }
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        if !dataLoadedFromServer && event != nil {
            loadDataFromServer()
            dataLoadedFromServer = true
        }
        
        if let _ = Helper.getValueForKey("newEventDate") {
            self.dismissViewControllerAnimated(true, completion: nil)
        }
        
    }
    
    func loadDataFromServer() {
        
        if showProgress {
        }else {
            refresh.beginRefreshing()
        }
        WebServices.getSharedWebServices().getEventAttendees(event.id, successCallback: { (message:String, attendees:[Attendee]) -> Void in
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.attendees = attendees
                self.attendeesTbl.reloadData()
                self.setAttendeesLbl()
                if self.showProgress {
                }else {
                    self.refresh.endRefreshing()
                }
                self.showProgress = false
            })
            
        }, failureCallback: { (message:String) -> Void in
                
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                if self.showProgress {
                    Helper.showAlert("", message: message)
                }else {
                    self.refresh.endRefreshing()
                }
                self.showProgress = false
            })
            
        })
        
    }
    
    func setAttendeesLbl() {
    
        let userId = Helper.getUserId()!
        
        var attendeesCount = editBtn.hidden ? 0 : 0
        for attendee in attendees {
            if attendee.invited == 1 || (userId == attendee.id && attendee.invited != -1){
                attendeesCount += 1
            }
        }
        self.attendeesLbl.text = String(attendeesCount) + (attendeesCount == 1 ? " Attendee" : " Attendees")

    }

}

extension EventInviteViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("InviteCell")! as! InviteCell
        
        let attendee = attendees[indexPath.row]
        
        cell.profileImg.setImageWithURL(NSURL(string: attendee.profileImg)!, placeholderImage: UIImage(named:"profileImgPlaceholder"))
        cell.nameLbl.text = attendee.name
        cell.setInvited(attendee.invited)
        
        let userId = Helper.getUserId()!
        if userId == attendee.id {
            
            if attendee.invited != 1 {
                
                cell.inviteLbl.text = "ATTEND"
                
                cell.inviteCallback = {() -> () in
                    
                    WebServices.getSharedWebServices().eventInviteRespond(self.event.id, response: "1", successCallback:   { (message:String) -> Void in
                        
                        self.showProgress = true
                        self.loadDataFromServer()
                        
                        }, failureCallback: { (message:String) -> Void in
                            
                            Helper.showAlert("", message: message)
                            
                    })
                    
                }
                
            }
            
            
        }else if attendee.invited != 1 {
            
            cell.inviteCallback = {() -> () in
                
                WebServices.getSharedWebServices().sendEventInvite(self.event.id, receiverId: attendee.id, successCallback:  { (message:String) -> Void in
                    
                    
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
//                        Helper.showAlert("", message: message)
                        self.showProgress = true
                        self.loadDataFromServer()
                    })
                    
                    }, failureCallback: { (message:String) -> Void in
                        
                        dispatch_async(dispatch_get_main_queue(), { () -> Void in
                            Helper.showAlert("", message: message)
                        })
                        
                })
                
            }
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return attendees.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 58 / 600 * UIScreen.mainScreen().bounds.size.height
    }
    
}

extension EventInviteViewController : FBSDKSharingDelegate {
    
    func sharer(sharer: FBSDKSharing!, didFailWithError error: NSError!) {
        Helper.showAlert("", message: Helper.genericErrorMsg)
    }
    
    func sharerDidCancel(sharer: FBSDKSharing!) {
        Helper.showAlert("", message: Helper.genericErrorMsg)
        
    }
    
    func sharer(sharer: FBSDKSharing!, didCompleteWithResults results: [NSObject : AnyObject]!) {
        print("complete")
    }
    
}


extension EventInviteViewController {
    
    @IBAction func backAct(sender: UIButton) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func shareAct(sender: UIButton) {
        
        let facebookDataLoader = FacebookDataLoader()
        
        let details = event.location + "  " + event.description
        facebookDataLoader.shareEvent(titleLbl.text!, eventDetail: details, viewController: self, successCallback: { (message:String) in
            
            Helper.showAlert("", message: message)
            
        }) { (message:String) in
            
            Helper.showAlert("", message: message)
            
        }
        
    }
    @IBAction func editAct(sender: UIButton) {
        
        let addEventViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("AddEventViewController") as! AddEventViewController
        addEventViewController.event = event
        addEventViewController.showMenu = false
        presentViewController(addEventViewController, animated: true, completion: nil)
        
    }
    
    @IBAction func showLocationAct(sender: UIButton) {
        
        let url = "https://maps.google.com/?q=\(event.location.stringByReplacingOccurrencesOfString(" ", withString: "+"))"
        UIApplication.sharedApplication().openURL(NSURL(string: url)!)
        
    }
}