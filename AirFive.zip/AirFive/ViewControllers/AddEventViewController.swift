//
//  AddEventViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 04/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit
import FBSDKShareKit

class AddEventViewController : BaseViewController {
    
    @IBOutlet weak var titleLbl: UILabel!
    
    @IBOutlet weak var eventNameTxt: UITextField!
    @IBOutlet weak var dateTxt: UITextField!
    @IBOutlet weak var locationTxt: AutoCompleteTextField!
    @IBOutlet weak var locationProgressView: M13ProgressViewRing!
    @IBOutlet weak var descriptionTxt: UITextView!
    @IBOutlet weak var descriptionTxtHeight: NSLayoutConstraint!
    @IBOutlet weak var addBtn: UIButton!
    @IBOutlet weak var innerContainer:UIView!
    
    @IBOutlet weak var datePickerView: UIView!
    @IBOutlet weak var datePickerContainer: UIView!
    
    @IBOutlet weak var menuImg: UIImageView!
    @IBOutlet weak var backImg: UIImageView!
    @IBOutlet weak var privateEventTickImg: UIImageView!
    
    var showMenu = true
    
    var addBtnInitialY:CGFloat = -1,innerContainerInitialY:CGFloat = -1, titleLblInitialY:CGFloat = -1
    var keyboardOpened:Bool = false
    var keyboardHeight:CGFloat = 0
    let dateFormatter = NSDateFormatter()
    
    var successPopup:KLCPopup! = nil
    var alert:UIBlockAlert! = nil
    
    var successDissmissCallback:(()->())! = nil
    var progressViewCount = 0
    
    var event:Event! = nil
    
    var datePicker: CustomDateTimePicker! = nil
    var calendarDate:NSDate! = nil
    var isPrivateEvent = false
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        menuImg.hidden = !showMenu
        backImg.hidden = showMenu
        
        successDissmissCallback = {() -> () in
            
            var date:NSDate! = nil
            if self.datePicker == nil {
                self.dateFormatter.dateFormat = "MM/dd/yyyy"
                date = self.dateFormatter.dateFromString(String(format:"%02d",self.event.month) + "/" + String(format:"%02d",self.event.day) + "/" + String(self.event.year))
            }else {
                date = self.datePicker.date
            }
            
            Helper.saveValue(date, forKey: "newEventDate")
            if self.showMenu {
                let menuController = self.menuContainerViewController.leftMenuViewController as! MenuViewController
                menuController.openMenuItemWithTag(4)
            }else {
                self.dismissViewControllerAnimated(true, completion: nil)
                                
            }
        }
        
        descriptionTxt.textContainerInset = UIEdgeInsetsMake(10, -5, 0, 0)
        descriptionTxt.scrollEnabled = false
        descriptionTxt.text = "Description"
        descriptionTxt.textColor = Helper.getAppGreyColor()
        descriptionTxt.tag = 0
        
        locationProgressView.showPercentage = false
        locationProgressView.backgroundRingWidth = 2
        locationProgressView.indeterminate = true
        prefilData()
        
    }
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        if eventNameTxt != nil {
            setPlaceHolder("Event name", textField: eventNameTxt)
            addBottomBorder(eventNameTxt)
        }
        
        if dateTxt != nil {
            setPlaceHolder("Date & Time", textField: dateTxt)
            addBottomBorder(dateTxt)
        }
        
        if locationTxt != nil {
            setPlaceHolder("Location", textField: locationTxt)
            addBottomBorder(locationTxt)
        }
        
        if addBtn != nil && !keyboardOpened {
            addBtnInitialY = addBtn.frame.origin.y
        }
        
        if innerContainer != nil && !keyboardOpened {
            innerContainerInitialY = innerContainer.frame.origin.y
        }
        
        if titleLbl != nil && !keyboardOpened {
            titleLblInitialY = titleLbl.frame.origin.y
        }
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        configureLocationTextField()
        self.view.transform = CGAffineTransformIdentity
        SVProgressHUD.dismiss()
        
    }
    
    func configureLocationTextField() {
        
        locationTxt.autoCompleteTextColor = Helper.getAppWhiteColor()
        locationTxt.autoCompleteTextFont = Helper.getNormalFont()
        
        
        locationTxt.autoCompleteCellHeight = 25
        locationTxt.maximumAutoCompleteCount = 10
        
        locationTxt.hidesWhenSelected = true
        locationTxt.hidesWhenEmpty = true
        locationTxt.enableAttributedText = true
        
        
        let attributes = [NSForegroundColorAttributeName:Helper.getAppWhiteColor(), NSFontAttributeName : Helper.getBoldFont()]
        locationTxt.autoCompleteAttributes = attributes
        
        locationTxt.onTextChange = {(text:String) in
            
            if text.characters.count == 0 {
                
                self.locationTxt.autoCompleteStrings = []
                return
                
            }
            
            self.progressViewCount += 1
            self.locationProgressView.hidden = false
            
            GooglePlacesLoader.getSharedGooglePlacesLoader().placeAutocomplete(text, successCallback: { (places) in

                self.locationTxt.autoCompleteStrings = places
                self.progressViewCount -= 1
                if self.progressViewCount <= 0 {
                    self.locationProgressView.hidden = true
                }
                
            }, failureCallback: { (message) in
                
                self.progressViewCount -= 1
                if self.progressViewCount <= 0 {
                    self.locationProgressView.hidden = true
                }
                
            })
            
        }
        
        locationTxt.adjustAutoCompleteTable(locationTxt.frame.size.width, separatorColor: Helper.getAppWhiteColor(), tableBgColor: Helper.getAppGreenColor())
        locationTxt.autoCompleteStrings = []
        
    }
    
    func prefilData() {
    
        if event != nil {
            
            titleLbl.text = "Edit Event"
        
            eventNameTxt.text = event.title
            
            dateFormatter.dateFormat = "MM/dd/yyyy HH:mm"
            let date = dateFormatter.dateFromString(String(format:"%02d",event.month) + "/" + String(format:"%02d",event.day) + "/" + String(event.year) + " " + String(format:"%02d",event.hour) + ":" + String(format:"%02d",event.minute))
            dateFormatter.dateFormat = "MM/dd/yyyy hh:mm a"
            dateTxt.text = dateFormatter.stringFromDate(date!)
            
            locationTxt.text = event.location
            if event.description.characters.count > 1 {
                descriptionTxt.text = event.description
                descriptionTxt.tag = 1
                descriptionTxt.textColor = Helper.getAppBlackColor()
            }
            
            addBtn.setTitle("Save", forState: UIControlState.Normal)
            addBtn.titleLabel?.font = Helper.getNormalFont(14)
            
        }else if calendarDate != nil {
            
            dateFormatter.dateFormat = "MM/dd/yyyy hh:mm a"
            dateTxt.text = dateFormatter.stringFromDate(calendarDate!)
            
        }
        
    }
}

extension AddEventViewController {
    
    override func keyboardWillShow(notification: NSNotification) {
        
        if let userInfo = notification.userInfo {
            
            keyboardOpened = true
            
            let animationDuration = userInfo[UIKeyboardAnimationDurationUserInfoKey]?.doubleValue
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.unsignedLongValue ?? UIViewAnimationOptions.CurveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            
            let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).CGRectValue().size
            keyboardHeight = min(keyboardSize.height,keyboardSize.width);
            
            UIView.animateWithDuration(animationDuration!, delay: 0, options: animationCurve
                , animations: { () -> Void in
                    
                    let newY = self.addBtnInitialY - self.keyboardHeight - (180 + self.descriptionTxt.frame.size.height + 20)
                    var delta = newY - self.innerContainerInitialY
                    var titleDelta = (newY - self.titleLbl.frame.size.height) - self.titleLblInitialY
                    if delta > 0 {
                        delta = 0
                    }
                    if titleDelta > 0 {
                        titleDelta = 0
                    }
                    self.titleLbl.transform = CGAffineTransformMakeTranslation(0, titleDelta)
                    self.innerContainer.transform = CGAffineTransformMakeTranslation(0, delta)
                    self.addBtn.transform = CGAffineTransformMakeTranslation(0, -1 * self.keyboardHeight)
                    
                }, completion: nil)
            
        }
        
    }
    
    override func keyboardWillHide(notification: NSNotification) {
        
        if let userInfo = notification.userInfo {
            
            keyboardOpened = false
            
            let animationDuration = userInfo[UIKeyboardAnimationDurationUserInfoKey]?.doubleValue
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.unsignedLongValue ?? UIViewAnimationOptions.CurveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            
            UIView.animateWithDuration(animationDuration!, delay: 0, options: animationCurve
                , animations: { () -> Void in
                    
                    self.titleLbl.transform = CGAffineTransformMakeTranslation(0, 0)
                    self.innerContainer.transform = CGAffineTransformMakeTranslation(0, 0)
                    self.addBtn.transform = CGAffineTransformMakeTranslation(0, 0)
                    
                }, completion: nil)
            
        }
        
    }
    
}

extension AddEventViewController {

    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        
        if textField == dateTxt {
            dismissKeyboard()
            showDatePicker(true, delay: keyboardOpened ? 0.3 : 0.0)
            return false
        }else if datePicker != nil {
            showDatePicker(false)
        }
        return true
    }
    
    func showDatePicker(show:Bool, delay:Double = 0) {
        
        if datePicker == nil {
            datePicker = CustomDateTimePicker.getSharedDateTimePicker(datePickerContainer.bounds)
            datePickerContainer.addSubview(datePicker)
            
            if event != nil {
                
                dateFormatter.dateFormat = "MM/dd/yyyy HH:mm"
                let date = dateFormatter.dateFromString(String(format:"%02d",event.month) + "/" + String(format:"%02d",event.day) + "/" + String(event.year) + " " + String(format:"%02d",event.hour) + ":" + String(format:"%02d",event.minute))
                datePicker.date = date!
                datePicker.half = event.hour / 12
                datePicker.setPickerDate(false)
                
            }else if calendarDate != nil {
            
                dateFormatter.dateFormat = "HH"
                let hours = (dateFormatter.stringFromDate(calendarDate) as NSString).integerValue
                
                datePicker.date = calendarDate
                datePicker.half = hours / 12
                datePicker.setPickerDate(false)
                
            }
            
        }
        
        let newY = show ? -1 * datePickerView.frame.size.height : 0
        UIView.animateWithDuration(0.3, delay: NSTimeInterval(delay), options: [], animations: { () -> Void in
            self.datePickerView.transform = CGAffineTransformMakeTranslation(0, newY)
        }, completion: nil)
        
    }
    
    override func dismissKeyboard() {
        super.dismissKeyboard()
        showDatePicker(false)
    }
    
}

extension AddEventViewController : UITextViewDelegate {

    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        
        if textView.tag == 0 {
            textView.text = ""
            textView.tag = 1
            textView.textColor = Helper.getAppBlackColor()
        }
        return true
    }
    
    func textViewShouldEndEditing(textView: UITextView) -> Bool {
        if textView.text.characters.count ==  0 {
            textView.text = "Description"
            textView.textColor = Helper.getAppGreyColor()
            textView.tag = 0
        }
        return true
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textViewDidChange(textView: UITextView) {
        
        let constraintSize = CGSize(width: (textView.frame.size.width - 5), height: CGFloat(MAXFLOAT))
        let textRect = (textView.text as NSString).boundingRectWithSize(constraintSize, options: NSStringDrawingOptions.UsesLineFragmentOrigin, attributes: [NSFontAttributeName: textView.font!], context: nil)
        
        var height = textRect.size.height + 10
        height = height < 40 ? 40 : height > 120 ? 120 : height
        
        descriptionTxtHeight.constant = height
        
        UIView.animateWithDuration(0.1, delay: 0, options: []
            , animations: { () -> Void in
                
                let newY = self.addBtnInitialY - self.keyboardHeight - (180 + self.descriptionTxt.frame.size.height + 20)
                var delta = newY - self.innerContainerInitialY
                if delta > 0 {
                    delta = 0
                }
                self.innerContainer.transform = CGAffineTransformMakeTranslation(0, delta)
                self.addBtn.transform = CGAffineTransformMakeTranslation(0, -1 * self.keyboardHeight)
                
            }, completion: nil)
        
    }
}

extension AddEventViewController {
    
    override func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldReceiveTouch touch: UITouch) -> Bool {
        
        if touch.view?.isDescendantOfView(datePickerView) == true {
            return false
        }else if touch.view?.isDescendantOfView(addBtn) == true {
            return false
        }else if touch.view?.isDescendantOfView(locationTxt.autoCompleteTableView!) == true {
            return false
        }
        return true
        
    }
    
}

extension AddEventViewController : FBSDKSharingDelegate {
    
    func sharer(sharer: FBSDKSharing!, didFailWithError error: NSError!) {
        Helper.showAlert("", message: Helper.genericErrorMsg)
    }
    
    func sharerDidCancel(sharer: FBSDKSharing!) {
        Helper.showAlert("", message: Helper.genericErrorMsg)
        
    }
    
    func sharer(sharer: FBSDKSharing!, didCompleteWithResults results: [NSObject : AnyObject]!) {
        self.alert = UIBlockAlert(title: "Success", message: "Sharing done successfully.", cancelButtonTitle: "OK", otherButtonTitle: nil, callback: { (buttonIndex:Int) in
            self.successDissmissCallback()
        })
    }
    
}


extension AddEventViewController {

    @IBAction func topLeftBtnAct(sender: UIButton) {
        if showMenu {
            menuContainerViewController.toggleLeftSideMenuCompletion(nil)
        }else {
            dismissViewControllerAnimated(true, completion: nil)
        }
    }
    
    @IBAction func addEventAct(sender: UIButton) {
        
        if eventNameTxt.text?.characters.count == 0{
            Helper.showAlert("", message: "Add event name to continue.")
            return
        }else if dateTxt.text?.characters.count == 0{
            Helper.showAlert("", message: "Select date to continue.")
            return
        }else if locationTxt.text?.characters.count == 0 {
            Helper.showAlert("", message: "Add location to continue.")
            return
        }
        
        Helper.showCustomProgress(self)
        
        let description = descriptionTxt.text! == "Description" ? "" : descriptionTxt.text!
        dismissKeyboard()
        
        var date:NSDate! = nil
        if datePicker == nil {
            dateFormatter.dateFormat = "MM/dd/yyyy"
            date = dateFormatter.dateFromString(String(format:"%02d",event.month) + "/" + String(format:"%02d",event.day) + "/" + String(event.year))
        }else {
            date = datePicker.date
        }
        
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dateStr = dateFormatter.stringFromDate(date)
        
        var hour = 0, minute = 0
        if datePicker == nil {
            hour = event.hour
            minute = event.minute
        }else {
            (hour, minute) = datePicker.getHourMinute()
        }
        let timeStr = String(format:"%02d",hour) + ":" + String(format:"%02d",minute)
            + ":00 "
        
        let eventId:String? = event == nil ? nil : event.id
        let isPrivate = isPrivateEvent ? "true" : "false"
        WebServices.getSharedWebServices().addEvent(eventId, eventName: eventNameTxt.text!, date: dateStr, time: timeStr, location: locationTxt.text!, description: description, isPrivate: isPrivate, successCallback: { (message:String) -> Void in
            
            Helper.hideCustomProgress()
            self.showSuccessPopup()
            
        }, failureCallback:  { (message:String) -> Void in
            
            Helper.hideCustomProgress()
            Helper.showAlert("", message: message)
                
        })
        
    }
    
    @IBAction func datePickerDoneAct(sender: UIButton) {
        dateFormatter.dateFormat = "MM/dd/yyyy hh:mm a"
        dateTxt.text = dateFormatter.stringFromDate(datePicker.date)
        showDatePicker(false)
    }
    
    @IBAction func datePickerCancelAct(sender: UIButton) {
        showDatePicker(false)
    }
    
    @IBAction func toggleEventPrivacyAct(sender: AnyObject) {
        
        isPrivateEvent = !isPrivateEvent;
        privateEventTickImg.hidden = !isPrivateEvent
        
    }
    
    func showSuccessPopup() {
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapDissmiss:")
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.5))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        let tapGestureStop = UITapGestureRecognizer(target: self, action: "tapDissmissStop:")
        innerContainer.addGestureRecognizer(tapGestureStop)
        
        let titleLbl = UILabel(frame: CGRect(x: 20, y: 20, width: innerContainer.frame.size.width - 40, height: innerContainer.frame.size.height * 0.35))
        titleLbl.textColor = Helper.getAppBlackColor()
        titleLbl.font = Helper.getBoldFont(22)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.numberOfLines = 0
        var message = "created"
        if event != nil {
            message = "updated"
        }
        titleLbl.text = "Way to go! You " + message + " an event! That was easy. Let people know about it."
        
        
        innerContainer.addSubview(titleLbl)
        
        tmp = innerContainer.frame.size.height * 0.15
        let shareBtn = UIBlockButton(frame: CGRect(x: titleLbl.frame.origin.x, y: (titleLbl.frame.origin.y + titleLbl.frame.size.height + 10), width: titleLbl.frame.size.width, height: tmp))
        
        tmp = innerContainer.frame.size.height * 0.11
        let fbImg = UIImageView(frame: CGRect(x: 0, y: 0, width: tmp * 4, height: tmp))
        fbImg.center = shareBtn.center
        fbImg.image = UIImage(named: "fb_share")
        
        innerContainer.addSubview(shareBtn)
        innerContainer.addSubview(fbImg)
        
        
        tmp = innerContainer.frame.size.width * 0.25
        let acceptBtn = UIBlockButton(frame: CGRect(x: ((innerContainer.frame.size.width - tmp) / 2), y: (shareBtn.frame.origin.y + shareBtn.frame.size.height + 10), width: tmp, height: tmp * 1.14))
        
        tmp = innerContainer.frame.size.width * 0.35
        let handImg = UIImageView(frame:CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        handImg.image = UIImage(named:"hand.gif")
        
        handImg.center = acceptBtn.center
        innerContainer.addSubview(handImg)
        
        innerContainer.addSubview(acceptBtn)
        
        container.addSubview(innerContainer)
        
        tmp = innerContainer.frame.origin.y + innerContainer.frame.size.height
        let bottomContainer = UIView(frame: CGRect(x: innerContainer.frame.origin.x, y: tmp, width: innerContainer.frame.size.width, height: container.frame.size.height - tmp))
        
        tmp = bottomContainer.frame.size.width * 0.2
        let cancelBtn = UIBlockButton(frame: CGRect(x: ((bottomContainer.frame.size.width - tmp) / 2), y: ((bottomContainer.frame.size.height - tmp) / 2), width: tmp, height: tmp))
        cancelBtn.setBackgroundImage(UIImage(named: "notificationClose"), forState: UIControlState.Normal)
        
        
        bottomContainer.addSubview(cancelBtn)
        
        container.addSubview(bottomContainer)
        
        
        successPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        successPopup.dimmedMaskAlpha = 0.85
        
        
        acceptBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.successPopup.dismissPresentingPopup()
            self.successDissmissCallback()
            
        }
        
        shareBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.successPopup.dismissPresentingPopup()
            
            let facebookDataLoader = FacebookDataLoader()
            
            var date:NSDate! = nil
            if self.datePicker == nil {
                self.dateFormatter.dateFormat = "MM/dd/yyyy"
                date = self.dateFormatter.dateFromString(String(format:"%02d",self.event.month) + "/" + String(format:"%02d",self.event.day) + "/" + String(self.event.year))
            }else {
                date = self.datePicker.date
            }
            
            let calendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)!
            let dateComp = calendar.components([NSCalendarUnit.Year, NSCalendarUnit.Month, NSCalendarUnit.Day], fromDate: date)
            let weekDay = Helper.dayNameFromDate(String(dateComp.year) + "-" + String(dateComp.month) + "-" + String(dateComp.day))
            
            let detail = weekDay + " " + String(format:"%02d",dateComp.day) + "/" + String(format:"%02d",dateComp.month) + " - " + self.locationTxt.text!
            facebookDataLoader.shareEvent(self.eventNameTxt.text!, eventDetail: detail, viewController: self, successCallback: { (message:String) in
                
                self.alert = UIBlockAlert(title: "Success", message: message, cancelButtonTitle: "OK", otherButtonTitle: nil, callback: { (buttonIndex:Int) in
                    self.successDissmissCallback()
                })
                
            }) { (message:String) in
                
                Helper.showAlert("", message: message)
                
            }
            
        }
        
        cancelBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.successPopup.dismissPresentingPopup()
            self.successDissmissCallback()
            
        }
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        successPopup.showWithLayout(layout)
        
    }
    
    func tapDissmiss(tap:UITapGestureRecognizer) {
    
        self.successPopup.dismissPresentingPopup()
        self.successDissmissCallback()
        
    }
    func tapDissmissStop(tap:UITapGestureRecognizer) {
    }
}



