//
//  EditUserViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 16/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit
import MessageUI

class EditUserViewController: BaseViewController {
    
    
    @IBOutlet weak var container: UIView!
    
    @IBOutlet weak var coverImg: UIImageView!
    @IBOutlet weak var coverOverlay: FXBlurView!
    @IBOutlet weak var converOverlayDark: UIView!
    @IBOutlet weak var profileImg: UIImageView!
    
    @IBOutlet weak var nameTxt: UITextField!
    @IBOutlet weak var titleTxt: UITextField!
    @IBOutlet weak var schoolTxt: UITextField!
    @IBOutlet weak var secondSchoolTxt: AutoCompleteTextField!
    @IBOutlet weak var companyTxt: UITextField!

    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var passwordTxt: UITextField!
    @IBOutlet weak var phoneTxt: UITextField!
    
    @IBOutlet weak var facebookBtn: UIButton!
    @IBOutlet weak var linkedinBtn: UIButton!
    
    @IBOutlet weak var uploadBannerBtn: UIButton!
    
    @IBOutlet weak var menuIcon: UIImageView!
    @IBOutlet weak var backIcon: UIImageView!
    
    @IBOutlet weak var personalStmtLbl: UILabel!
    
    @IBOutlet weak var progressView: M13ProgressViewRing!
    var progressViewCount = 0
    
    var showMenu = true
    
    var maxMoveDelta:CGFloat = -1, containerInitialY:CGFloat = -1
    var viewMoveDelta:CGFloat = 0
    var keyboardOpened:Bool = false
    
    var imagePicker:UIImagePickerController! = nil
    var currentImg:UIImageView! = nil
    var coverImgUpdated:Bool = false, profileImgUpdated:Bool = false
    
    var blockAlert:UIBlockAlert!
    var schoolChangeAlert:UIBlockAlert!
    
    var emailChangePermissionAsked  = false, emailChangePermissionGranted = false
    var passwordChangePermissionAsked  = false, passwordChangePermissionGranted = false
    var phoneChangePermissionAsked  = false, phoneChangePermissionGranted = false
    
    var personalStmtEntryPopup:KLCPopup! = nil
    var personalStmtTxt:UITextView! = nil
    var personalStmtTxtBorder:UIView! = nil
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        coverOverlay.blurRadius = 0
        coverOverlay.dynamic = false
        loadUserData()
        
        if !showMenu {
            addDissmissWithSwipeGesture()
        }
        
        menuIcon.hidden = !showMenu
        backIcon.hidden = showMenu
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        configureSecondSchoolTextField()
        configurePhoneTextField()
        progressView.showPercentage = false
        progressView.backgroundRingWidth = 2
        progressView.indeterminate = true
        
    }
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        if nameTxt != nil {
            setPlaceHolder("First & last name", textField: nameTxt)
        }
        
        if titleTxt != nil {
            setPlaceHolder("Position", textField: titleTxt)
        }
        
        if schoolTxt != nil {
            setPlaceHolder("School", textField: schoolTxt)
        }
        
        if secondSchoolTxt != nil {
            setPlaceHolder("Second group", textField: secondSchoolTxt)
        }
        
        if companyTxt != nil {
            setPlaceHolder("Company", textField: companyTxt)
        }
        
        if emailTxt != nil {
            setPlaceHolder("Email", textField: emailTxt)
        }
        
        if passwordTxt != nil {
            setPlaceHolder("Password", textField: passwordTxt)
        }
        
        if phoneTxt != nil && !keyboardOpened {
            setPlaceHolder("Phone", textField: phoneTxt)
            let point = phoneTxt.superview?.convertPoint(phoneTxt.frame.origin, toView: container)
            maxMoveDelta = point!.y + phoneTxt.frame.size.height
        }
        
        if profileImg != nil {
            profileImg.clipsToBounds = true
            profileImg.layer.cornerRadius = profileImg.frame.size.height / 2
        }
        
        if facebookBtn != nil {
            facebookBtn.layer.cornerRadius = 5
            facebookBtn.layer.borderColor = Helper.getFacebookColor().CGColor
            facebookBtn.layer.borderWidth = 1
        }
        
        if linkedinBtn != nil {
            linkedinBtn.layer.cornerRadius = 5
            linkedinBtn.layer.borderColor = Helper.getLinkedinColor().CGColor
            linkedinBtn.layer.borderWidth = 1
        }
        
        if container != nil && !keyboardOpened {
            containerInitialY = container.frame.origin.y
        }
        
        if uploadBannerBtn != nil {
            uploadBannerBtn.clipsToBounds = true
            uploadBannerBtn.layer.cornerRadius = 5
            
            let text = "+ UPLOAD BANNER"
            let attributes = [NSFontAttributeName:Helper.getNormalFont(10), NSForegroundColorAttributeName:Helper.getAppWhiteColor()]
            let attributedString = NSMutableAttributedString(string: text, attributes: attributes)
            let range = (text as NSString).rangeOfString("+")
            attributedString.addAttributes([NSForegroundColorAttributeName:Helper.getAppGreenColor()], range: range)
            
            uploadBannerBtn.setAttributedTitle(attributedString, forState: UIControlState.Normal)
        }
        
    }
    
    func loadUserData() {
        
        let user = User.getSharedUser()
        
        nameTxt.text = user.name
        titleTxt.text = user.title
        schoolTxt.text = user.school
        secondSchoolTxt.text = user.secondSchool
        companyTxt.text = user.company
        
        emailTxt.text = user.email
        phoneTxt.text = user.phone
        
        profileImg.image = UIImage(named:"profileImgAdd")
        if user.profileImgLocal.characters.count > 0 {
            if let image = UIImage(contentsOfFile: user.profileImgLocal) {
                profileImg.image = image
            }
        }else {
            profileImg.setImageWithURL(NSURL(string: user.profileImgUrl)!, placeholderImage: UIImage(named:"profileImgAdd"))
        }
        
        
        coverImg.image = UIImage(named:"backgroundImg")
        if user.coverImgLocal.characters.count > 0 {
            if let image = UIImage(contentsOfFile: user.coverImgLocal) {
                coverImg.image = image
            }
        }else {
            coverImg.setImageWithURL(NSURL(string: user.coverImgUrl)!, placeholderImage: UIImage(named:"backgroundImg"))
        }
        
        if let signInFrom = Helper.getValueForKey("signInFrom") as? String {
            
            
            
            if signInFrom == "facebook" {
                
                facebookBtn.backgroundColor = Helper.getFacebookColor()
                facebookBtn.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
                
            }else if signInFrom == "linkedin" {
                
                linkedinBtn.backgroundColor = Helper.getLinkedinColor()
                linkedinBtn.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
                
            }
            
        }
        
        setPersonalStmt()
        
    }
    
    func configureSecondSchoolTextField() {
        
        secondSchoolTxt.autoCompleteTextColor = Helper.getAppWhiteColor()
        secondSchoolTxt.autoCompleteTextFont = Helper.getNormalFont()
        
        
        secondSchoolTxt.autoCompleteCellHeight = 25
        secondSchoolTxt.maximumAutoCompleteCount = 10
        
        secondSchoolTxt.hidesWhenSelected = true
        secondSchoolTxt.hidesWhenEmpty = true
        secondSchoolTxt.enableAttributedText = true
        
        
        let attributes = [NSForegroundColorAttributeName:Helper.getAppWhiteColor(), NSFontAttributeName : Helper.getBoldFont()]
        secondSchoolTxt.autoCompleteAttributes = attributes
        
        secondSchoolTxt.onTextChange = {(text:String) in
            
            if text.characters.count == 0 {
                
                self.secondSchoolTxt.autoCompleteStrings = []
                return
                
            }
            
            self.progressViewCount += 1
            self.progressView.hidden = false
            
            WebServices.getSharedWebServices().getSchool(text, successCallback: { (schools:[String]) in
                
                self.secondSchoolTxt.autoCompleteStrings = schools
                self.progressViewCount -= 1
                if self.progressViewCount <= 0 {
                    self.progressView.hidden = true
                }
                
                }, failureCallback: { (message:String) in
                    
                    self.progressViewCount -= 1
                    if self.progressViewCount <= 0 {
                        self.progressView.hidden = true
                    }
                    
            })
            
        }
        
        secondSchoolTxt.adjustAutoCompleteTable(schoolTxt.frame.size.width, separatorColor: Helper.getAppWhiteColor(), tableBgColor: Helper.getAppGreenColor(), viewControllersView: self.view)
        secondSchoolTxt.autoCompleteStrings = []
        
    }
    
    func configurePhoneTextField() {
    
        let barButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.Done, target: phoneTxt, action: "resignFirstResponder")
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: UIScreen.mainScreen().bounds.size.width, height: 44))
        toolbar.items = [barButton]
        
        phoneTxt.inputAccessoryView = toolbar
        
    }
    
    func setPersonalStmt() {
        
        let user = User.getSharedUser()
        if user.personalStmt.characters.count > 0 {
            personalStmtLbl.text = "\"\(user.personalStmt)\""
            personalStmtLbl.textColor = Helper.getAppGreenColor()
        }else {
            personalStmtLbl.text = "Enter personal statement"
            personalStmtLbl.textColor = Helper.getAppGreyColor()
        }
        
    }
    
}

extension EditUserViewController {

    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        if (textField == phoneTxt) {
            let newString = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
            let components = newString.componentsSeparatedByCharactersInSet(NSCharacterSet.decimalDigitCharacterSet().invertedSet)
            
            let decimalString = components.joinWithSeparator("") as NSString
            let length = decimalString.length
            let hasLeadingOne = length > 0 && decimalString.characterAtIndex(0) == (1 as unichar)
            
            if length == 0 || (length > 10 && !hasLeadingOne) || length > 11
            {
                let newLength = (textField.text! as NSString).length + (string as NSString).length - range.length as Int
                
                return (newLength > 10) ? false : true
            }
            var index = 0 as Int
            let formattedString = NSMutableString()
            
            if hasLeadingOne
            {
                formattedString.appendString("1 ")
                index += 1
            }
            if (length - index) > 3
            {
                let areaCode = decimalString.substringWithRange(NSMakeRange(index, 3))
                formattedString.appendFormat("(%@) ", areaCode)
                index += 3
            }
            if length - index > 3
            {
                let prefix = decimalString.substringWithRange(NSMakeRange(index, 3))
                formattedString.appendFormat("%@-", prefix)
                index += 3
            }
            
            let remainder = decimalString.substringFromIndex(index)
            formattedString.appendString(remainder)
            textField.text = formattedString as String
            return false
        }
        else
        {
            return true
        }
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        
        if textField == schoolTxt || (textField == secondSchoolTxt && User.getSharedUser().secondSchool.characters.count > 0) {

            schoolChangeAlert = UIBlockAlert(title: "", message: "If you'd like to change your school or group please email support@airfive.com", cancelButtonTitle: "OK", otherButtonTitle: "Email now", callback: { (btnIndex:Int) in
                if btnIndex > 0 {
                    self.openEmailViewContoller()
                }
            })
            
            return false
        }
        
        viewMoveDelta = 0
        if textField == emailTxt || textField == passwordTxt || textField == phoneTxt {
            viewMoveDelta = maxMoveDelta
        }
        
        if textField == emailTxt {
            if !emailChangePermissionAsked {
                blockAlert = UIBlockAlert(title: "Caution", message: "Are you sure you want to change your email?", cancelButtonTitle: "No", otherButtonTitle: "Yes", callback: {(buttonIndex:Int) in
                    self.emailChangePermissionGranted = buttonIndex == 1
                    if self.emailChangePermissionGranted {
                        self.emailTxt.becomeFirstResponder()
                    }
                })
                emailChangePermissionAsked = true
               
            }
            return emailChangePermissionGranted
        }
        
        if textField == passwordTxt {
            if !passwordChangePermissionAsked {
                blockAlert = UIBlockAlert(title: "Caution", message: "Are you sure you want to change your password?", cancelButtonTitle: "No", otherButtonTitle: "Yes", callback: {(buttonIndex:Int) in
                    self.passwordChangePermissionGranted = buttonIndex == 1
                    if self.passwordChangePermissionGranted {
                        self.passwordTxt.becomeFirstResponder()
                    }
                })
                passwordChangePermissionAsked = true
                
            }
            return passwordChangePermissionGranted
        }
        
        if textField == phoneTxt {
            if !phoneChangePermissionAsked {
                blockAlert = UIBlockAlert(title: "Caution", message: "Are you sure you want to change your phone?", cancelButtonTitle: "No", otherButtonTitle: "Yes", callback: {(buttonIndex:Int) in
                    self.phoneChangePermissionGranted = buttonIndex == 1
                    if self.phoneChangePermissionGranted {
                        self.phoneTxt.becomeFirstResponder()
                    }
                })
                phoneChangePermissionAsked = true
                
            }
            return phoneChangePermissionGranted
        }
        return true
        
    }
    
    func openEmailViewContoller() {
        
        if MFMailComposeViewController.canSendMail() {
            let mailComposer = MFMailComposeViewController()
            mailComposer.mailComposeDelegate = self
            mailComposer.setSubject("Change My School/Group")
            mailComposer.setToRecipients(["support@airfive.com"])
            presentViewController(mailComposer, animated: true, completion: nil)
            
        }else {
            Helper.showAlert("", message: "Email not supported. Kindly check your settings for email account.")
        }
    }
    
}

extension EditUserViewController : MFMailComposeViewControllerDelegate {
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        dismissViewControllerAnimated(true, completion: nil)
    }
}

extension EditUserViewController {
    
    override func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldReceiveTouch touch: UITouch) -> Bool {
        
        if touch.view?.isDescendantOfView(secondSchoolTxt.autoCompleteTableView!) == true {
            return false
        }
        return true
        
    }
    
}

extension EditUserViewController {

    override func keyboardWillShow(notification: NSNotification) {
        
        if let userInfo = notification.userInfo {
            
            keyboardOpened = true
            
            let animationDuration = userInfo[UIKeyboardAnimationDurationUserInfoKey]?.doubleValue
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.unsignedLongValue ?? UIViewAnimationOptions.CurveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            
            let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).CGRectValue().size
            let keyboardHeight = min(keyboardSize.height,keyboardSize.width);
            
            UIView.animateWithDuration(animationDuration!, delay: 0, options: animationCurve
                , animations: { () -> Void in
                    
                    let newY = (self.view.frame.size.height - keyboardHeight) - (self.viewMoveDelta)
                    var delta = newY - self.containerInitialY
                    if delta > 0 {
                        delta = 0
                    }
                    self.container.transform = CGAffineTransformMakeTranslation(0, delta)
                    
                }, completion: nil)
            
        }
        
    }
    
    override func keyboardWillHide(notification: NSNotification) {
        
        if let userInfo = notification.userInfo {
            
            keyboardOpened = false
            
            let animationDuration = userInfo[UIKeyboardAnimationDurationUserInfoKey]?.doubleValue
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.unsignedLongValue ?? UIViewAnimationOptions.CurveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            
            UIView.animateWithDuration(animationDuration!, delay: 0, options: animationCurve
                , animations: { () -> Void in
                    
                    self.container.transform = CGAffineTransformMakeTranslation(0, 0)
                    
                }, completion: nil)
            
        }
        
    }
    
}

extension EditUserViewController : UIActionSheetDelegate {
    
    func actionSheet(actionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int) {
        
        if buttonIndex == 0 {//cancel
            return
        }
        if imagePicker == nil {
            imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.allowsEditing = false
        }

        if buttonIndex == 1 {// camera
            
            if !UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.Camera) {
                Helper.showAlert("", message: "Camera not detected.")
                return
            }
            self.imagePicker.sourceType = UIImagePickerControllerSourceType.Camera
            
        }else {
            
            self.imagePicker.sourceType = UIImagePickerControllerSourceType.PhotoLibrary
            
        }
        self.presentViewController(self.imagePicker, animated: true, completion: nil)
        
    }

}

extension EditUserViewController : UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        let image : UIImage = (info[UIImagePickerControllerOriginalImage] as? UIImage)!
        
        if currentImg == coverImg {
            
            currentImg.image = image
            coverImgUpdated = true
            coverOverlay.updateAsynchronously(true, completion: nil)
            dismissViewControllerAnimated(true, completion: nil)
            
        }else {
            
            dismissViewControllerAnimated(false, completion: { () -> Void in
                
                var imageCropVC : RSKImageCropViewController!
                imageCropVC = RSKImageCropViewController(image: image, cropMode: RSKImageCropMode.Circle)
                imageCropVC.delegate = self
                self.presentViewController(imageCropVC, animated: true, completion: nil)
                
            })
        
        }
        
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        
        self.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
}

extension EditUserViewController : RSKImageCropViewControllerDelegate {
    
    func imageCropViewControllerDidCancelCrop(controller: RSKImageCropViewController) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func imageCropViewController(controller: RSKImageCropViewController, didCropImage croppedImage: UIImage, usingCropRect cropRect: CGRect) {
        
        profileImg.image = croppedImage
        profileImgUpdated = true
        self.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    func imageCropViewController(controller: RSKImageCropViewController, didCropImage croppedImage: UIImage, usingCropRect cropRect: CGRect, rotationAngle: CGFloat) {
        
        profileImg.image = croppedImage
        profileImgUpdated = true
        self.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
}

extension EditUserViewController : UITextViewDelegate {
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        
        if textView.tag == 0 {
            textView.text = ""
            textView.tag = 1
            textView.textColor = Helper.getAppBlackColor()
        }
        return true
    }
    
    func textViewShouldEndEditing(textView: UITextView) -> Bool {
        if textView.text.characters.count ==  0 {
            textView.text = "Enter personal statement"
            textView.textColor = Helper.getAppGreenColor()
            textView.tag = 0
        }
        return true
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textViewDidChange(textView: UITextView) {
        
        let constraintSize = CGSize(width: (textView.frame.size.width - 5), height: CGFloat(MAXFLOAT))
        let textRect = (textView.text as NSString).boundingRectWithSize(constraintSize, options: NSStringDrawingOptions.UsesLineFragmentOrigin, attributes: [NSFontAttributeName: textView.font!], context: nil)
        
        var height = textRect.size.height + 10
        height = height < 25 ? 25 : height > 60 ? 60 : height
        
        textView.frame.size.height = height
        if personalStmtTxtBorder != nil {
            personalStmtTxtBorder.frame.origin.y = textView.frame.origin.y + textView.frame.size.height
        }
        
    }
}

extension EditUserViewController {
    
    @IBAction func topLeftBtnAct(sender: UIButton) {
        if shouldUpdate() {
            saveHelper()
        }else {
            if showMenu {
                menuContainerViewController.toggleLeftSideMenuCompletion(nil)
            }else {
                dismissViewControllerAnimated(true, completion: nil)
            }
        }
    }
    
    @IBAction func addCoverAct(sender: UIButton) {
        
        currentImg = coverImg
        let actionSheet = UIActionSheet(title: "Choose image source", delegate: self, cancelButtonTitle: "Cancel", destructiveButtonTitle: nil, otherButtonTitles: "Camera", "Photo Gallery")
        actionSheet.showInView(view)
        
    }
    
    @IBAction func changeProfileImgAct(sender: UIButton) {
        
        currentImg = profileImg
        let actionSheet = UIActionSheet(title: "Choose image source", delegate: self, cancelButtonTitle: "Cancel", destructiveButtonTitle: nil, otherButtonTitles: "Camera", "Photo Gallery")
        actionSheet.showInView(view)
        
    }
    
    @IBAction func syncFacebookAct(sender: UIButton) {
    }
    
    @IBAction func syncLinkedinAct(sender: UIButton) {
    }
    
    func shouldUpdate() -> Bool {
    
        let user = User.getSharedUser()
        if self.nameTxt.text! != user.name || self.titleTxt.text! != user.title || self.companyTxt.text! != user.company || self.schoolTxt.text! != user.school || self.secondSchoolTxt.text! != user.secondSchool || self.emailTxt.text! != user.email || self.passwordTxt.text!.characters.count > 0 || self.phoneTxt.text! != user.phone || coverImgUpdated || profileImgUpdated {
            return true
        }
        return false
        
    }
    
    @IBAction func saveAct(sender: UIButton) {
        
        if shouldUpdate() {
            saveHelper()
        }
        
    }
    
    func saveHelper() {
    
        let updateUser = {() in
            
            var parameters:[String:AnyObject] = [String:AnyObject]()
            
            parameters["username"] = self.nameTxt.text!
            parameters["title"] = self.titleTxt.text!
            parameters["company"] = self.companyTxt.text!
            parameters["school"] = self.schoolTxt.text!
            parameters["second_school"] = self.secondSchoolTxt.text!
            
            parameters["email"] = self.emailTxt.text!
            if self.passwordTxt.text!.characters.count > 0 {
                parameters["password"] = self.passwordTxt.text!
            }
            parameters["phone_number"] = self.phoneTxt.text!
            
            WebServices.getSharedWebServices().setUser(parameters, successCallback: { (message:String) -> Void in
                
                Helper.hideCustomProgress()
                if self.showMenu {
                    self.menuContainerViewController.toggleLeftSideMenuCompletion(nil)
                }else {
                    self.dismissViewControllerAnimated(true, completion: nil)
                }
                
            }, failureCallback: { (message:String) -> Void in
                    
                Helper.hideCustomProgress()
                Helper.showAlert("", message: message)
                
            })
        }
        
        let profileImgUpload = {() in
            
            let profileImgData = UIImageJPEGRepresentation(self.profileImg.image!, 0.1)
            
            WebServices.getSharedWebServices().uploadImage("profile", imageData:profileImgData!, successCallback: { (message:String) -> Void in
                
                self.profileImgUpdated = false
                updateUser()
                
            }, failureCallback: { (message:String) -> Void in
                    
                Helper.hideCustomProgress()
                Helper.showAlert("", message: message)
                    
                    
            })
        }
        
        let coverImgUpload = {() in
            
            let coverImgData = UIImageJPEGRepresentation(self.coverImg.image!, 0.1)
            
            WebServices.getSharedWebServices().uploadImage("cover", imageData:coverImgData!, successCallback: { (message:String) -> Void in
                
                self.coverImgUpdated = false
                if self.profileImgUpdated {
                    
                    profileImgUpload()
                    
                }else {
                    
                    updateUser()
                    
                }
                
            }, failureCallback: { (message:String) -> Void in
                    
                    Helper.hideCustomProgress()
                    Helper.showAlert("", message: message)
                    
                    
            })
        }
        
        
        
        if coverImgUpdated {
            
            Helper.showCustomProgress(self)
            
            coverImgUpload()
            
        }else if profileImgUpdated {
            
            Helper.showCustomProgress(self)
            
            profileImgUpload()
            
        }else {
            
            updateUser()
        
        }
        
    }
    
    @IBAction func changePersonalStmtAct() {
        showPersonalStmtEntryPopup()
    }
    
    func showPersonalStmtEntryPopup() {
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapDissmiss:")
        tapGesture.delegate = self
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.5))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        let tapGestureStop = UITapGestureRecognizer(target: self, action: "tapDissmissStop:")
        tapGestureStop.delegate = self
        innerContainer.addGestureRecognizer(tapGestureStop)
        
        tmp = innerContainer.frame.size.height * 0.35
        let titleLbl = UILabel(frame: CGRect(x: 20, y: 30, width: innerContainer.frame.size.width - 40, height: tmp))
        titleLbl.textColor = Helper.getAppBlackColor()
        titleLbl.font = Helper.getBoldFont(20)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.numberOfLines = 0
        titleLbl.text = "Your personal statement says a little about you in a sentence or two. This will appear on your profile."
        
        innerContainer.addSubview(titleLbl)
        
        tmp = innerContainer.frame.size.height * 0.08
        
        personalStmtTxt = UITextView(frame: CGRect(x: titleLbl.frame.origin.x, y: (titleLbl.frame.origin.y + titleLbl.frame.size.height + 10), width: titleLbl.frame.size.width, height: 25))
        
        personalStmtTxt.delegate = self
        personalStmtTxt.textContainerInset = UIEdgeInsetsMake(5, -5, 0, 0)
        personalStmtTxt.scrollEnabled = false
        personalStmtTxt.font = Helper.getNormalFont()
        
        if User.getSharedUser().personalStmt.characters.count > 0 {
            personalStmtTxt.text = User.getSharedUser().personalStmt
            personalStmtTxt.textColor = Helper.getAppBlackColor()
            personalStmtTxt.tag = 1
        }else {
            personalStmtTxt.text = "Enter personal statement"
            personalStmtTxt.textColor = Helper.getAppGreenColor()
            personalStmtTxt.tag = 0
        }
        personalStmtTxt.autocorrectionType = .No
        personalStmtTxt.returnKeyType = UIReturnKeyType.Done
        
        personalStmtTxtBorder = UIView(frame: CGRect(x: personalStmtTxt.frame.origin.x, y: personalStmtTxt.frame.origin.y + personalStmtTxt.frame.size.height, width: personalStmtTxt.frame.size.width, height: 1))
        personalStmtTxtBorder.backgroundColor = Helper.getAppGreyColor()
        
        
        tmp = innerContainer.frame.size.width * 0.25
        let remainingHeight = innerContainer.frame.size.height - (personalStmtTxt.frame.origin.y + personalStmtTxt.frame.size.height)
        
        let acceptBtn = UIBlockButton(frame: CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        acceptBtn.center = CGPoint(x: innerContainer.frame.size.width / 2, y: (personalStmtTxt.frame.origin.y + personalStmtTxt.frame.size.height) + remainingHeight / 2)
        
        tmp = innerContainer.frame.size.width * 0.35
        let handImg = UIImageView(frame:CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        handImg.image = UIImage(named:"hand.gif")
        
        handImg.center = acceptBtn.center
        innerContainer.addSubview(handImg)
        
        innerContainer.addSubview(acceptBtn)
        
        innerContainer.addSubview(personalStmtTxt)
        innerContainer.addSubview(personalStmtTxtBorder)
        
        container.addSubview(innerContainer)
        
        personalStmtEntryPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        personalStmtEntryPopup.dimmedMaskAlpha = 0.85
        
        
        acceptBtn.callback = {(button:UIBlockButton) -> Void in
            
            if self.personalStmtTxt.text?.characters.count == 0 || self.personalStmtTxt.text! == "Enter personal statement" {
                Helper.showAlert("", message: "Please enter personal statement")
                return
            }
            
            let parameters = ["personal_statement":self.personalStmtTxt.text!]
            WebServices.getSharedWebServices().setUser(parameters, successCallback: { (message:String) -> Void in
                
                self.personalStmtEntryPopup.dismissPresentingPopup()
                self.setPersonalStmt()
                
                }, failureCallback: { (message:String) -> Void in
                    
                    self.personalStmtEntryPopup.dismissPresentingPopup()
                    Helper.showAlert("", message: message)
                    
            })
            
        }
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        personalStmtEntryPopup.showWithLayout(layout)
        
    }
    
    func tapDissmiss(tap:UITapGestureRecognizer) {
        if personalStmtEntryPopup != nil {
            personalStmtEntryPopup.dismissPresentingPopup()
        }
    }
    
    func tapDissmissStop(tap:UITapGestureRecognizer) {
    }
    
}




