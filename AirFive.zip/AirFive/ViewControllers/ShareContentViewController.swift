//
//  ShareContentViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 5/11/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class ShareContentViewController: BaseViewController {

    @IBOutlet weak var urlTxt: UITextField!
    
    @IBOutlet weak var metaContainer: UIView!
    @IBOutlet weak var metaImg: UIImageView!
    @IBOutlet weak var metaTitle: UILabel!
    @IBOutlet weak var metaLblsX: NSLayoutConstraint!
    
    @IBOutlet weak var selectedSchoolView: UIView!
    @IBOutlet weak var selectedSchoolLbl: UILabel!
    @IBOutlet weak var changeSchoolArrImg: UIImageView!
    
    @IBOutlet weak var schoolBgView: UIView!
    @IBOutlet weak var schoolTbl: UITableView!
    
    @IBOutlet weak var cancelBtn: UIButton!
    @IBOutlet weak var progressView: M13ProgressViewRing!
    @IBOutlet weak var errorLbl: UILabel!
    
    let borderColorNormal = UIColor(red: 224.0/255.0, green: 231.0/255.0, blue: 238.0/255.0, alpha: 1.0)
    let borderColorSelected = UIColor(red: 132.0/255.0, green: 191.0/255.0, blue: 255.0/255.0, alpha: 1.0)
    
    var selectedSchoolIndex = 0
    
    var contentMetaTimer:NSTimer! = nil
    var contentMetaLoaded = false
    var timePassed = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        selectedSchoolLbl.text = User.getSharedUser().school
        selectedSchoolIndex = 0

        metaContainer.hidden = true
        contentMetaTimer = NSTimer.scheduledTimerWithTimeInterval(1.0, target: self, selector: "loadContentMeta", userInfo: nil, repeats: true)
        
    }
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        if urlTxt != nil {
            setPlaceHolder("Paste url here to share", textField: urlTxt, white: true)
        }
        
        if metaContainer != nil {
            metaContainer.layer.borderColor = UIColor(white: 203.0/255.0, alpha: 1.0).CGColor
            metaContainer.layer.borderWidth = 1
        }
        
        if selectedSchoolView != nil {
            selectedSchoolView.layer.cornerRadius = 5
            selectedSchoolView.layer.borderColor = borderColorNormal.CGColor
            selectedSchoolView.layer.borderWidth = 1
        }
        
        if cancelBtn != nil {
            cancelBtn.layer.borderColor = Helper.getAppGreenColor().CGColor
            cancelBtn.layer.borderWidth = 1
        }
        
        if schoolBgView != nil {
            schoolBgView.layer.cornerRadius = 5
            schoolBgView.layer.borderColor = borderColorNormal.CGColor
            schoolBgView.layer.borderWidth = 1
        }
        
        if schoolTbl != nil {
            schoolTbl.tableFooterView = UIView()
        }
        
        if progressView != nil {
            progressView.backgroundRingWidth = 2
            progressView.showPercentage = false
            progressView.indeterminate = true
        }
        
    }
    
    func loadContentMeta() {
        if !contentMetaLoaded && urlTxt.text?.characters.count > 0 {
            timePassed += 1
            if timePassed >= 2 {
                
                progressView.hidden = false
                WebServices.getSharedWebServices().getContentMeta(urlTxt.text!, successCallback: { (message:String, contentMeta:ContentMeta) in
                    
                    self.progressView.hidden = true
                    self.metaContainer.hidden = contentMeta.title.characters.count == 0
                    self.errorLbl.hidden = contentMeta.title.characters.count != 0
                    
                    self.metaTitle.text = contentMeta.title
                    
                    if contentMeta.imgUrl.characters.count > 0 {
                        self.metaImg.hidden = false
                        self.metaImg.setImageWithURL(NSURL(string: contentMeta.imgUrl)!, placeholderImage: UIImage(named:""))
                        self.metaLblsX.constant = 8
                    }else {
                        self.metaImg.hidden = true
                        self.metaLblsX.constant = -self.metaImg.frame.size.width
                    }
                    
                    }, failureCallback: { (message:String) in
                        
                        self.progressView.hidden = true
                        self.metaContainer.hidden = true
                        self.errorLbl.hidden = false
                        
                })
                contentMetaLoaded = true
            }
        }
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        
        urlTxt.text = UIPasteboard.generalPasteboard().string
        loadContentMeta()
        
    }

}

extension ShareContentViewController {
    
    func textFieldDidBeginEditing(textField: UITextField) {
        
        UIMenuController.sharedMenuController().menuVisible = true
        textField.selectAll(self)
        
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        let newTxt = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        if newTxt.characters.count == 0 {
            
            metaImg.image = UIImage(named: "")
            metaTitle.text = ""
            metaContainer.hidden = true
            progressView.hidden = true
            errorLbl.hidden = true
            
        }else {
            
            timePassed = 0
            contentMetaLoaded = false
            
        }
        
        return true
    }
    
}

extension ShareContentViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("SchoolCell")! as! SchoolCell
        
        switch indexPath.row {
        case 0:
            cell.schoolLbl.text = User.getSharedUser().school
        case 1:
            cell.schoolLbl.text = User.getSharedUser().secondSchool
        default:
            break
        }
        
        if indexPath.row == selectedSchoolIndex {
            cell.backgroundColor = UIColor(red: 246.0/255.0, green: 247.0/255.0, blue: 249.0/255.0, alpha: 1.0)
        }else {
            cell.backgroundColor = UIColor.clearColor()
        }
        
        return cell
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return User.getSharedUser().secondSchool.characters.count > 0 ? 2 : 1
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return selectedSchoolView.frame.size.height
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        selectedSchoolIndex = indexPath.row
        tableView.reloadData()
        hideSchoolTbl(true)
        
    }
    
}


extension ShareContentViewController {

    @IBAction func changeSchoolAct(sender: UIButton) {
        
        hideSchoolTbl(!schoolBgView.hidden)
        
    }
    
    func hideSchoolTbl(hide:Bool) {
        
        if hide {
            selectedSchoolLbl.text = selectedSchoolIndex == 0 ? User.getSharedUser().school : User.getSharedUser().secondSchool
            changeSchoolArrImg.image = UIImage(named: "arrowDownIcon")
            schoolBgView.hidden = true
        }else {
            selectedSchoolLbl.text = "Which School?"
            changeSchoolArrImg.image = UIImage(named: "arrowUpIcon")
            schoolBgView.hidden = false
        }
        
    }
    
    @IBAction func cancelAct(sender: UIButton) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func postAct(sender: UIButton) {
        
        if urlTxt.text?.characters.count == 0 {
            Helper.showAlert("", message: "Add url to share.")
        }else if selectedSchoolLbl.text == "Which School?" {
            Helper.showAlert("", message: "Select a school url to continue.")
        }else {
        
            WebServices.getSharedWebServices().shareContent(urlTxt.text!, school: selectedSchoolLbl.text!, successCallback: { (message:String) in
                
                Helper.saveValue("true", forKey: "refreshContent")
                self.dismissViewControllerAnimated(true, completion: nil)
                
                }, failureCallback: { (message:String) in
                    Helper.showAlert("", message: message)
            })
            
        }
        
    }

}





