//
//  SettingsViewController.swift
//  AirFive
//
//  Created by Muhammad Umair on 6/28/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit
import MessageUI

class SettingsViewController: BaseViewController {

    let fbUrl = "https://www.facebook.com"
    let twitterUrl = "https://www.twitter.com"
    let contactEmail = "team@airfive.com"
    let aboutUrl = "https://www.airfive.com/about"
    let termsUrl = "https://www.iubenda.com/privacy-policy/7832268"
    
    func openUrl(urlStr:String) {
        
        let url = NSURL(string: urlStr)!
        if !UIApplication.sharedApplication().canOpenURL(url) {
            Helper.showAlert("", message:Helper.genericErrorMsg)
            return
        }
        UIApplication.sharedApplication().openURL(url)
        
    }
    
    func openEmailViewContoller(email:String) {
        
        if MFMailComposeViewController.canSendMail() {
            let mailComposer = MFMailComposeViewController()
            mailComposer.mailComposeDelegate = self
            mailComposer.setToRecipients([email])
            presentViewController(mailComposer, animated: true, completion: nil)
            
        }else {
            Helper.showAlert("", message: "Email not supported. Kindly check your settings for email account.")
        }
    }
    
}

extension SettingsViewController : MFMailComposeViewControllerDelegate {
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        dismissViewControllerAnimated(true, completion: nil)
    }
}

extension SettingsViewController {

    @IBAction func topLeftBtnAct(sender: UIButton) {
        menuContainerViewController.toggleLeftSideMenuCompletion(nil)
    }
    
    @IBAction func settingsAct(sender:UIButton) {
        switch sender.tag {
        case 0:
            openUrl(fbUrl)
        case 1:
            openUrl(twitterUrl)
        case 2:
            openEmailViewContoller(contactEmail)
        case 3:
            openUrl(aboutUrl)
        case 4:
            openUrl(termsUrl)
        default:
            break
        }
        
    }

}
