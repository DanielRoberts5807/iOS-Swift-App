//
//  SocialConnectionsViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 18/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation

class SocialConnectionsViewController : BaseViewController {

    var socialConnections:SocialConnections! = nil
    
    var profileLinkPopup:KLCPopup! = nil
    
    @IBOutlet weak var socialConnectionsTbl: UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        socialConnectionsTbl.tableFooterView = UIView()
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        loadDataFromServer()
        
    }
    
    func loadDataFromServer() {
        
        WebServices.getSharedWebServices().getSocialConnections({ (message:String, socialConnections:SocialConnections) -> Void in
            
            self.socialConnections = socialConnections
            self.socialConnectionsTbl.reloadData()
            
        }, failureCallback: { (message:String) -> Void in
                
            Helper.showAlert("", message: message)
            
        })
        
    }
    
}

extension SocialConnectionsViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("SocialConnectionCell")! as! SocialConnectionCell
        
        let height = 60 / 600 * UIScreen.mainScreen().bounds.size.height
        
        let failureCallback = {(message:String) -> () in
            if !message.containsString("User Canceled") {
                Helper.showAlert("", message: Helper.genericErrorMsg)
            }
        }
        
        let setSocialConnectionCallback = {(showAlert:Bool, parameters:[String:String], successCallback:(() -> ())) -> () in
            WebServices.getSharedWebServices().setSocialConnection(parameters, successCallback: { (message:String) -> Void in
                
                if showAlert {
                    let msg = message.stringByReplacingOccurrencesOfString("u{1f44c}", withString: "\u{1f44c}")
                    Helper.showAlert("", message: msg)
                }
                successCallback()
                
            }, failureCallback: { (message:String) -> Void in
                    
                if showAlert {
                    let msg = message.stringByReplacingOccurrencesOfString("u{1f914}", withString: "\u{1f914}")
                    Helper.showAlert("", message: msg)
                }
                
            })
        }
        
        switch indexPath.row {
        case 0:
            cell.connectionNameLbl.text = "FACEBOOK"
            cell.connectionImg.image = UIImage(named: "socialFacebook")
            cell.connectionImgHeight.constant = height * 0.31
            cell.connectionImgWidth.constant = cell.connectionImgHeight.constant * 0.5
            
            cell.connectBtn.hidden = socialConnections.facebookUrl.characters.count != 0
            
            cell.connectedBtn.hidden = socialConnections.facebookUrl.characters.count == 0
            cell.connectedCheckImg.hidden = socialConnections.facebookUrl.characters.count == 0
            cell.connectedTickImg.hidden = socialConnections.facebookUrl.characters.count == 0 || !socialConnections.facebookUrlVisibility
            
            cell.connectCallback = {()->() in
                
                let delayTime = dispatch_time(DISPATCH_TIME_NOW, Int64(0.1 * Double(NSEC_PER_SEC)))
                dispatch_after(delayTime, dispatch_get_main_queue()) {
                    let facebookLoader = FacebookDataLoader()
                    facebookLoader.processLogin(self, successCallback: { (socialConnectionsData:[String : AnyObject]) in
                        
                        if socialConnectionsData.keys.contains("link") {
                            let url = socialConnectionsData["link"]! as! String
                            print(url)
                            setSocialConnectionCallback(true, ["facebook_url" :url], {() -> () in
                                self.socialConnections.facebookUrl = url
                                self.socialConnectionsTbl.reloadData()
                            })
                        }else {
                            failureCallback("No data")
                        }
                        
                        }, failureCallback: failureCallback)
                }
                
            }
            
            cell.changeVisibilityCallback = {()->() in
                
                let visibility = self.socialConnections.facebookUrlVisibility ? "0" : "1"
                let parameters = ["facebook_url" : self.socialConnections.facebookUrl, "facebook_url_visiblity": visibility]
                setSocialConnectionCallback(false, parameters, {() -> () in
                    self.socialConnections.facebookUrlVisibility = !self.socialConnections.facebookUrlVisibility
                    self.socialConnectionsTbl.reloadData()
                })
                
            }
            
        case 1:
            cell.connectionNameLbl.text = "TWITTER"
            cell.connectionImg.image = UIImage(named: "socialTwitter")
            cell.connectionImgHeight.constant = height * 0.24
            cell.connectionImgWidth.constant = cell.connectionImgHeight.constant * 1.28
            
            cell.connectBtn.hidden = socialConnections.twitterUrl.characters.count != 0
            
            cell.connectedBtn.hidden = socialConnections.twitterUrl.characters.count == 0
            cell.connectedCheckImg.hidden = socialConnections.twitterUrl.characters.count == 0
            cell.connectedTickImg.hidden = socialConnections.twitterUrl.characters.count == 0 || !socialConnections.twitterUrlVisibility
            
            cell.connectCallback = {()->() in
                
                self.showProfileLinkPopup("Twitter", url: self.socialConnections.twitterUrl, callback: { (url:String) in
                    
                    setSocialConnectionCallback(true, ["twitter_url" : url], {() -> () in
                        self.socialConnections.twitterUrl = url
                        self.socialConnectionsTbl.reloadData()
                    })
                    
                })
                
            }
            
            cell.changeVisibilityCallback = {()->() in
                
                let visibility = self.socialConnections.twitterUrlVisibility ? "0" : "1"
                let parameters = ["twitter_url" : self.socialConnections.twitterUrl, "twitter_url_visiblity": visibility]
                setSocialConnectionCallback(false, parameters, {() -> () in
                    self.socialConnections.twitterUrlVisibility = !self.socialConnections.twitterUrlVisibility
                    self.socialConnectionsTbl.reloadData()
                })
                
            }
            
        case 2:
            cell.connectionNameLbl.text = "INSTAGRAM"
            cell.connectionImg.image = UIImage(named: "socialInstagram")
            cell.connectionImgHeight.constant = height * 0.37
            cell.connectionImgWidth.constant = cell.connectionImgHeight.constant * 0.945
            
            cell.connectBtn.hidden = socialConnections.instagramUrl.characters.count != 0
            
            cell.connectedBtn.hidden = socialConnections.instagramUrl.characters.count == 0
            cell.connectedCheckImg.hidden = socialConnections.instagramUrl.characters.count == 0
            cell.connectedTickImg.hidden = socialConnections.instagramUrl.characters.count == 0 || !socialConnections.instagramUrlVisibility
            
            cell.connectCallback = {()->() in
                
                self.showProfileLinkPopup("Instagram", url: self.socialConnections.instagramUrl, callback: { (url:String) in
                    
                    setSocialConnectionCallback(true, ["instagram_url" : url], {() -> () in
                        self.socialConnections.instagramUrl = url
                        self.socialConnectionsTbl.reloadData()
                    })
                    
                })
                
            }
            
            cell.changeVisibilityCallback = {()->() in
                
                let visibility = self.socialConnections.instagramUrlVisibility ? "0" : "1"
                let parameters = ["instagram_url" : self.socialConnections.instagramUrl, "instagram_url_visiblity": visibility]
                setSocialConnectionCallback(false, parameters, {() -> () in
                    self.socialConnections.instagramUrlVisibility = !self.socialConnections.instagramUrlVisibility
                    self.socialConnectionsTbl.reloadData()
                })
                
            }
            
        case 3:
            cell.connectionNameLbl.text = "SNAPCHAT"
            cell.connectionImg.image = UIImage(named: "socialSnapchat")
            cell.connectionImgHeight.constant = height * 0.34
            cell.connectionImgWidth.constant = cell.connectionImgHeight.constant * 1.058
            
            cell.connectBtn.hidden = socialConnections.snapchatUrl.characters.count != 0
            
            cell.connectedBtn.hidden = socialConnections.snapchatUrl.characters.count == 0
            cell.connectedCheckImg.hidden = socialConnections.snapchatUrl.characters.count == 0
            cell.connectedTickImg.hidden = socialConnections.snapchatUrl.characters.count == 0 || !socialConnections.snapchatUrlVisibility
            
            cell.connectCallback = {()->() in
                
                self.showProfileLinkPopup("Snapchat", url: self.socialConnections.snapchatUrl, callback: { (url:String) in
                    
                    setSocialConnectionCallback(true, ["snapchat_url" : url], {() -> () in
                        self.socialConnections.snapchatUrl = url
                        self.socialConnectionsTbl.reloadData()
                    })
                    
                })
                
            }
            
            cell.changeVisibilityCallback = {()->() in
                
                let visibility = self.socialConnections.snapchatUrlVisibility ? "0" : "1"
                let parameters = ["snapchat_url" : self.socialConnections.snapchatUrl, "snapchat_url_visiblity": visibility]
                setSocialConnectionCallback(false, parameters, {() -> () in
                    self.socialConnections.snapchatUrlVisibility = !self.socialConnections.snapchatUrlVisibility
                    self.socialConnectionsTbl.reloadData()
                })
                
            }
            
        case 4:
            cell.connectionNameLbl.text = "LINKEDIN"
            cell.connectionImg.image = UIImage(named: "socialLinkedin")
            cell.connectionImgHeight.constant = height * 0.27
            cell.connectionImgWidth.constant = cell.connectionImgHeight.constant * 1.074
            
            cell.connectBtn.hidden = socialConnections.linkedinUrl.characters.count != 0
            
            cell.connectedBtn.hidden = socialConnections.linkedinUrl.characters.count == 0
            cell.connectedCheckImg.hidden = socialConnections.linkedinUrl.characters.count == 0
            cell.connectedTickImg.hidden = socialConnections.linkedinUrl.characters.count == 0 || !socialConnections.linkedinUrlVisibility
            
            cell.connectCallback = {()->() in
                
                self.showProfileLinkPopup("Linkedin", url: self.socialConnections.linkedinUrl, callback: { (url:String) in
                    
                    setSocialConnectionCallback(true, ["linkedin_url" : url], {() -> () in
                        self.socialConnections.linkedinUrl = url
                        self.socialConnectionsTbl.reloadData()
                    })
                    
                })
                
            }
            
            cell.changeVisibilityCallback = {()->() in
                
                let visibility = self.socialConnections.linkedinUrlVisibility ? "0" : "1"
                let parameters = ["linkedin_url" : self.socialConnections.linkedinUrl, "linkedin_url_visiblity": visibility]
                setSocialConnectionCallback(false, parameters, {() -> () in
                    self.socialConnections.linkedinUrlVisibility = !self.socialConnections.linkedinUrlVisibility
                    self.socialConnectionsTbl.reloadData()
                })
                
            }
           
        case 5:
            cell.connectionNameLbl.text = "TUMBLR"
            cell.connectionImg.image = UIImage(named: "socialTumblr")
            cell.connectionImgHeight.constant = height * 0.31
            cell.connectionImgWidth.constant = cell.connectionImgHeight.constant * 0.566
            
            cell.connectBtn.hidden = socialConnections.tumlbrUrl.characters.count != 0
            
            cell.connectedBtn.hidden = socialConnections.tumlbrUrl.characters.count == 0
            cell.connectedCheckImg.hidden = socialConnections.tumlbrUrl.characters.count == 0
            cell.connectedTickImg.hidden = socialConnections.tumlbrUrl.characters.count == 0 || !socialConnections.tumlbrUrlVisibility
            
            cell.connectCallback = {()->() in
                
                self.showProfileLinkPopup("Tumblr", url: self.socialConnections.tumlbrUrl, callback: { (url:String) in
                    
                    setSocialConnectionCallback(true, ["tumlbr_url" : url], {() -> () in
                        self.socialConnections.tumlbrUrl = url
                        self.socialConnectionsTbl.reloadData()
                    })
                    
                })
                
            }
        
            cell.changeVisibilityCallback = {()->() in
                
                let visibility = self.socialConnections.twitterUrlVisibility ? "0" : "1"
                let parameters = ["tumlbr_url" : self.socialConnections.twitterUrl, "tumlbr_url_visiblity": visibility]
                setSocialConnectionCallback(false, parameters, {() -> () in
                    self.socialConnections.twitterUrlVisibility = !self.socialConnections.twitterUrlVisibility
                    self.socialConnectionsTbl.reloadData()
                })
                
            }
            
        case 6:
            cell.connectionNameLbl.text = "GOOGLE"
            cell.connectionImg.image = UIImage(named: "socialGoogle")
            cell.connectionImgHeight.constant = height * 0.34
            cell.connectionImgWidth.constant = cell.connectionImgHeight.constant * 0.647
            
            cell.connectBtn.hidden = socialConnections.googleUrl.characters.count != 0
            
            cell.connectedBtn.hidden = socialConnections.googleUrl.characters.count == 0
            cell.connectedCheckImg.hidden = socialConnections.googleUrl.characters.count == 0
            cell.connectedTickImg.hidden = socialConnections.googleUrl.characters.count == 0 || !socialConnections.googleUrlVisibility
            
            cell.connectCallback = {()->() in
                
                self.showProfileLinkPopup("Google", url: self.socialConnections.googleUrl, callback: { (url:String) in
                    
                    setSocialConnectionCallback(true, ["google_url" : url], {() -> () in
                        self.socialConnections.googleUrl = url
                        self.socialConnectionsTbl.reloadData()
                    })
                    
                })
                
            }
            
            cell.changeVisibilityCallback = {()->() in
                
                let visibility = self.socialConnections.googleUrlVisibility ? "0" : "1"
                let parameters = ["google_url" : self.socialConnections.googleUrl, "google_url_visiblity": visibility]
                setSocialConnectionCallback(false, parameters, {() -> () in
                    self.socialConnections.googleUrlVisibility = !self.socialConnections.googleUrlVisibility
                    self.socialConnectionsTbl.reloadData()
                })
                
            }
            
        default:
            break
        }
        
        return cell
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return socialConnections == nil ? 0 : 7
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60 / 600 * UIScreen.mainScreen().bounds.size.height
    }
    
    func showProfileLinkPopup(source:String, url: String, callback:((String) -> ())) {
        
        var message = ""
        var placeHolder = ""
        switch source {
        case "Instagram", "Snapchat", "Twitter":
            message = "Please enter username or handle for " + source
            placeHolder = "User name or handle"
        default:
            message = "Please enter profile url for " + source
            placeHolder = "Profile url"
        }
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapDissmiss:")
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.5))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        let tapGestureStop = UITapGestureRecognizer(target: self, action: "tapDissmissStop:")
        innerContainer.addGestureRecognizer(tapGestureStop)
        
        let titleLbl = UILabel(frame: CGRect(x: 20, y: 20, width: innerContainer.frame.size.width - 40, height: innerContainer.frame.size.height * 0.20))
        titleLbl.textColor = Helper.getAppBlackColor()
        titleLbl.font = Helper.getBoldFont(22)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.numberOfLines = 0
        titleLbl.text = message
        
        innerContainer.addSubview(titleLbl)
        
        tmp = innerContainer.frame.size.height * 0.08
        let textField = UITextField(frame: CGRect(x: titleLbl.frame.origin.x, y: (titleLbl.frame.origin.y + titleLbl.frame.size.height + 10), width: titleLbl.frame.size.width, height: tmp))
        textField.delegate = self
        textField.returnKeyType = UIReturnKeyType.Done
        textField.autocorrectionType = UITextAutocorrectionType.No
        
        innerContainer.addSubview(textField)
        
        addBottomBorder(textField)
        setPlaceHolder(placeHolder, textField: textField)
        textField.text = url
        
        tmp = innerContainer.frame.size.width * 0.25
        let acceptBtn = UIBlockButton(frame: CGRect(x: ((innerContainer.frame.size.width - tmp) / 2), y: (textField.frame.origin.y + textField.frame.size.height + (innerContainer.frame.size.height * 0.15)), width: tmp, height: tmp * 1.14))
        
        tmp = innerContainer.frame.size.width * 0.35
        let handImg = UIImageView(frame:CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        handImg.image = UIImage(named:"hand.gif")
        
        handImg.center = acceptBtn.center
        innerContainer.addSubview(handImg)
        
        innerContainer.addSubview(acceptBtn)
        
        container.addSubview(innerContainer)
        
        profileLinkPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        profileLinkPopup.dimmedMaskAlpha = 0.85
        
        
        acceptBtn.callback = {(button:UIBlockButton) -> Void in
            
            if textField.text?.characters.count == 0 {
                Helper.showAlert("", message: "Please copy/paste URL")
                return
            }
            callback(textField.text!)
            self.profileLinkPopup.dismissPresentingPopup()
            
        }
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        profileLinkPopup.showWithLayout(layout)
        
    }
    
    func tapDissmiss(tap:UITapGestureRecognizer) {
        self.profileLinkPopup.dismissPresentingPopup()
    }
    func tapDissmissStop(tap:UITapGestureRecognizer) {
    }
    
}

extension SocialConnectionsViewController {
    
    @IBAction func backAct(sender: UIButton) {
        dismissViewControllerAnimated(true, completion: nil)
    }

}