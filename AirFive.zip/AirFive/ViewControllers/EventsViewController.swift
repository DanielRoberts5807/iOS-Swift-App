//
//  EventsViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 05/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class EventsViewController: BaseViewController {
    
    @IBOutlet weak var monthLbl: UILabel!
    @IBOutlet weak var calendarMenuContainer: UIView!
    @IBOutlet weak var calendarViewContainer: UIView!
    @IBOutlet weak var eventsTbl: UITableView!
    @IBOutlet weak var noEventLbl: UILabel!
    
    @IBOutlet weak var menuIcon: UIImageView!
    @IBOutlet weak var crossIcon: UIImageView!
    
    var showMenu = true
    
    var calendarMenuView: CVCalendarMenuView!
    var calendarView: CVCalendarView!
    var selectedDay:DayView! = nil
    var animationFinished = true
    
    var eventDotColor = UIColor(red: 27.0/255.0, green: 88.0/255.0, blue: 255.0/255.0, alpha: 1.0)
    var inviteDotColor = UIColor(red: 156.0/255.0, green: 0.0/255.0, blue: 195.0/255.0, alpha: 1.0)
    
    var calendar:NSCalendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)!
    var events:[Event] = []
    var filteredEvents:[Event] = []
    var dataLoadedFromServer = false

    override func viewDidLoad() {
        
        super.viewDidLoad()
        monthLbl.text = CVDate(date: NSDate()).globalDescription
        
        let width = UIScreen.mainScreen().bounds.size.width - 40
        calendarMenuView = CVCalendarMenuView(frame: CGRect(x: 20, y: 0, width: width, height: calendarMenuContainer.frame.size.height))
        calendarMenuView.menuViewDelegate = self
        calendarMenuContainer.addSubview(calendarMenuView)
        
        calendarView = CVCalendarView(frame: CGRect(x: 20, y: 0, width: width, height: calendarViewContainer.frame.size.height))
        calendarView.calendarDelegate = self
        calendarView.calendarAppearanceDelegate = self
        calendarViewContainer.addSubview(calendarView)
        
        eventsTbl.tableFooterView = UIView()
        
        menuIcon.hidden = !showMenu
        crossIcon.hidden = showMenu
        
    }
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        calendarView.commitCalendarViewUpdate()
        calendarMenuView.commitMenuViewUpdate()
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        
        if let newEventDate = Helper.getValueForKey("newEventDate") {
            calendarView.toggleViewWithDate(newEventDate as! NSDate)
            Helper.saveValue(nil, forKey: "newEventDate")
            dataLoadedFromServer = false
        }
    
        if !dataLoadedFromServer {
            loadDataFromServer()
            dataLoadedFromServer = true
        }
        
    }
    
    func updateData() {
        
        calendarView.contentController.refreshPresentedMonth()
        reloadEventTbl( selectedDay == nil ? NSDate() : selectedDay.date.convertedDate()!)
        
    }
    
    func loadDataFromServer() {
        
        WebServices.getSharedWebServices().getEvents({ (message:String, events:[Event]) -> Void in
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.events = events
                self.updateData()
            })
            
        }, failureCallback: { (message:String) -> Void in
                
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                Helper.showAlert("", message: message)
            })
                
        })
        
    }
    
}

extension EventsViewController {

    func createDummyData() {
    
        events = Event.createDummyEvents()
        
    }
    
    func filterEventsForDate(date:NSDate) {
        
        let dateComp = calendar.components([NSCalendarUnit.Year, NSCalendarUnit.Month, NSCalendarUnit.Day], fromDate: date)
        
        filteredEvents = []
        for event in events {
            if event.belongToDate(dateComp.day, month: dateComp.month, year: dateComp.year) {
                filteredEvents.append(event)
            }
        }
        
    }
    
    func showEventsForDate(dayView:DayView, type:EventType) -> Bool {
        
        for event in events {
            if event.belongToDate(dayView.date.day, month: dayView.date.month, year: dayView.date.year) && event.type == type {
                return true
            }
        }
        return false
    }
    
    func reloadEventTbl(date:NSDate) {
        filterEventsForDate(date)
        eventsTbl.reloadData()
        eventsTbl.hidden = filteredEvents.count == 0
        noEventLbl.hidden = filteredEvents.count > 0
    }
}

extension EventsViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("EventCell")! as! EventCell
        
        let event = filteredEvents[indexPath.row]
        
        cell.setEventType(event.type)
        cell.messageLbl.text = event.title
        var time = String(format: "%02d",event.hour % 12) + ":" + String(format: "%02d",event.minute) + " "
        if event.hour > 12 {
            time += "PM"
        }else {
            time += "AM"
        }
        cell.timeLbl.text = time
        
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredEvents.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 80 / 600 * UIScreen.mainScreen().bounds.size.height
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let eventInviteViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("EventInviteViewController") as! EventInviteViewController
        eventInviteViewController.event = filteredEvents[indexPath.row]
        presentViewController(eventInviteViewController, animated: true, completion: nil)
        
    }
    
}

extension EventsViewController: CVCalendarMenuViewDelegate {

    func dayOfWeekFont() -> UIFont {
        return Helper.getNormalFont()
    }
    
    func dayOfWeekTextColor() -> UIColor {
        return UIColor.whiteColor()
    }
    
}

extension EventsViewController: CVCalendarViewDelegate {
    
    func presentationMode() -> CalendarMode {
        return .MonthView
    }
    
    func firstWeekday() -> Weekday {
        return .Sunday
    }
    
    func shouldShowWeekdaysOut() -> Bool {
        return true
    }
    
    func didSelectDayView(dayView: CVCalendarDayView, animationDidFinish: Bool) {
        selectedDay = dayView
        calendarView.contentController.refreshPresentedMonth()
        reloadEventTbl(selectedDay.date.convertedDate()!)
    }
    
    func presentedDateUpdated(date: CVDate) {
        if monthLbl.text != date.globalDescription && self.animationFinished {
            let updatedmonthLbl = UILabel()
            updatedmonthLbl.textColor = monthLbl.textColor
            updatedmonthLbl.font = monthLbl.font
            updatedmonthLbl.textAlignment = .Center
            updatedmonthLbl.text = date.globalDescription
            updatedmonthLbl.sizeToFit()
            updatedmonthLbl.alpha = 0
            updatedmonthLbl.center = self.monthLbl.center
            
            let offset = CGFloat(48)
            updatedmonthLbl.transform = CGAffineTransformMakeTranslation(0, offset)
            updatedmonthLbl.transform = CGAffineTransformMakeScale(1, 0.1)
            
            UIView.animateWithDuration(0.35, delay: 0, options: UIViewAnimationOptions.CurveEaseIn, animations: {
                self.animationFinished = false
                self.monthLbl.transform = CGAffineTransformMakeTranslation(0, -offset)
                self.monthLbl.transform = CGAffineTransformMakeScale(1, 0.1)
                self.monthLbl.alpha = 0
                
                updatedmonthLbl.alpha = 1
                updatedmonthLbl.transform = CGAffineTransformIdentity
                
                }) { _ in
                    
                    self.animationFinished = true
                    self.monthLbl.frame = updatedmonthLbl.frame
                    self.monthLbl.text = updatedmonthLbl.text
                    self.monthLbl.transform = CGAffineTransformIdentity
                    self.monthLbl.alpha = 1
                    updatedmonthLbl.removeFromSuperview()
            }
            
            self.view.insertSubview(updatedmonthLbl, aboveSubview: self.monthLbl)
        }
    }
    
    func preliminaryView(viewOnDayView dayView: DayView) -> UIView {
        let circleView = CVAuxiliaryView(dayView: dayView, rect: dayView.bounds, shape: CVShape.Circle)
        circleView.fillColor = UIColor(white: 0, alpha: 0.1)
        return circleView
    }
    
    func preliminaryView(shouldDisplayOnDayView dayView: DayView) -> Bool {
        if (dayView.isCurrentDay) {
            return true
        }
        return false
    }
    
    func dotMarker(shouldShowOnDayView dayView: CVCalendarDayView) -> Bool {
        if showEventsForDate(dayView, type: EventType.Event) || showEventsForDate(dayView, type: EventType.Invite) {
            return true
        }
        return false
    }
    
    func dotMarker(colorOnDayView dayView: CVCalendarDayView) -> [UIColor] {
        
        var colors:[UIColor] = []
        if showEventsForDate(dayView, type: EventType.Invite) {
            colors.append(inviteDotColor)
        }
        if showEventsForDate(dayView, type: EventType.Event) {
            colors.append(eventDotColor)
        }
        return colors
        
    }
    
    func dotMarker(shouldMoveOnHighlightingOnDayView dayView: CVCalendarDayView) -> Bool {
        return false
    }
    
    func dotMarker(sizeOnDayView dayView: DayView) -> CGFloat {
        return 14
    }
    
}

extension EventsViewController: CVCalendarViewAppearanceDelegate {
    
    func dayLabelPresentWeekdayInitallyBold() -> Bool {
        return false
    }
    
    func spaceBetweenDayViews() -> CGFloat {
        return 2
    }

}

extension EventsViewController {

    @IBAction func topLeftBtnAct(sender: UIButton) {
        if showMenu {
            menuContainerViewController.toggleLeftSideMenuCompletion(nil)
        }else {
            dismissViewControllerAnimated(true, completion: nil)
        }
    }
    
    @IBAction func addEventAct(sender: UIButton) {
        
        let addEventViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("AddEventViewController") as! AddEventViewController
        addEventViewController.showMenu = false
        
        if selectedDay != nil {
            addEventViewController.calendarDate = selectedDay.date.convertedDate()!
        }else {
            addEventViewController.calendarDate = NSDate()
        }
        
        self.presentViewController(addEventViewController, animated: true, completion: nil)
        
    }
}


