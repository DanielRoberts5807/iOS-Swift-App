//
//  InviteViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 21/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import Foundation
import MessageUI

class InviteViewController: BaseViewController {
    
    @IBOutlet weak var searchTxt: UITextField!
    @IBOutlet weak var noContactsLbl: UILabel!
    
    @IBOutlet weak var contactsTbl: UITableView!
    
    @IBOutlet weak var txtTabIndicator: UIView!
    @IBOutlet weak var emailTabIndicator: UIView!
    
    var allContacts = [DeviceContact]()
    var filteredContacts = [DeviceContact]()
    var currentRecipients = [String]()
    let maxSimultaniousInvites = 100
    
    var deviceContacts = DeviceContactLoader()
    var currentTab = 0
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        contactsTbl.tableFooterView = UIView()
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        loadData()
        adjustTabs()
        
    }
    
    func loadData() {
    
        allContacts = deviceContacts.deviceContacts
        filteredContacts = allContacts
        for contact in allContacts {
            contact.selectedForInvite = false
        }
        contactsTbl.reloadData()
        contactsTbl.hidden = filteredContacts.count == 0
        noContactsLbl.hidden = filteredContacts.count > 0
        
    }
    
    func filterContacts(searchStr:String) {
    
        filteredContacts = allContacts.filter({ (contact:DeviceContact) -> Bool in
            
            let nameOk = searchStr.characters.count > 0 ? contact.name.lowercaseString.containsString(searchStr.lowercaseString) : true
            let tabOk = currentTab == 0 ? contact.number.characters.count > 0 : contact.email.characters.count > 0
            return nameOk && tabOk
            
        })
        
    }
    
    func adjustTabs() {
    
        txtTabIndicator.hidden = currentTab != 0
        emailTabIndicator.hidden = currentTab == 0
        
    }
    
}

extension InviteViewController {
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        let searchTxt = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        if searchTxt.characters.count == 0 {
            
            filteredContacts = allContacts
            
        }else {
            
            filterContacts(searchTxt)

        }
        
        contactsTbl.reloadData()
        contactsTbl.hidden = filteredContacts.count == 0
        noContactsLbl.hidden = filteredContacts.count > 0
        
        return true
    }

}

extension InviteViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("InviteCell")! as! InviteCell
        
        let contact = filteredContacts[indexPath.row]
        
        cell.profileImg.setImageWithURL(NSURL(string: "")!, placeholderImage: UIImage(named:"profileImgPlaceholder"))
        cell.nameLbl.text = contact.name
        
        cell.inviteCallback = {() -> () in
            
            if self.currentTab == 0 {
                if contact.number.characters.count == 0 {
                    Helper.showAlert("", message: "Can't invite.No number found for contact.")
                }else {
                    self.sendMessage([contact.number])
                }
            }else {
                if contact.email.characters.count == 0 {
                    Helper.showAlert("", message: "Can't invite.No email address found for contact.")
                }else {
                    self.sendEmail(contact.email)
                }
            }
            
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredContacts.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 58 / 600 * UIScreen.mainScreen().bounds.size.height
    }
    
    func sendMessage(recipients:[String]) {
        currentRecipients = recipients
        if !MFMessageComposeViewController.canSendText() {
            Helper.showAlert("", message: "Message not supported on device")
        }else {
            let messageComposer = MFMessageComposeViewController()
            messageComposer.messageComposeDelegate = self
            messageComposer.body = "Hey! Checkout this amazing app. " + Helper.appLink
            messageComposer.recipients = recipients
            presentViewController(messageComposer, animated: true, completion: nil)
        }
    }
    
    func getSelectedForInviteCount() -> Int {
        var count = 0
        for contact in allContacts {
            if contact.selectedForInvite {
                count += 1
            }
        }
        return count
    }
    
    func sendEmail(emailAddress:String) {
        
        if MFMailComposeViewController.canSendMail() {
            let mailComposer = MFMailComposeViewController()
            mailComposer.mailComposeDelegate = self
            mailComposer.setToRecipients([emailAddress])
            presentViewController(mailComposer, animated: true, completion: nil)
            
        }else {
            Helper.showAlert("", message: "Email not supported. Kindly check your settings for email account.")
        }
    }
    
}

extension InviteViewController : MFMessageComposeViewControllerDelegate {

    func messageComposeViewController(controller: MFMessageComposeViewController, didFinishWithResult result: MessageComposeResult) {
        controller.dismissViewControllerAnimated(true, completion: nil)
        if result == MessageComposeResultSent || true {
            for contact in allContacts {
                for recipient in currentRecipients {
                    if recipient == contact.number {
                        contact.invited = 0
                        break
                    }
                }
            }
            contactsTbl.reloadData()
        }
    }
}

extension InviteViewController : MFMailComposeViewControllerDelegate {
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        dismissViewControllerAnimated(true, completion: nil)
    }
}


extension InviteViewController {

    @IBAction func openMenuAct(sender: UIButton) {
        menuContainerViewController.toggleLeftSideMenuCompletion(nil)
    }
    
    @IBAction func facebookInviteAct(sender: UIButton) {
        FacebookDataLoader().invite(self, applink:Helper.appLink)
    }
    
    @IBAction func inviteAllAct(sender: UIButton) {
        
        
        if getSelectedForInviteCount() == 0 {
            Helper.showAlert("", message: "No contacts to invite.")
        }else {
        
            var recipients = [String]()
            for contact in allContacts {
                if contact.number.characters.count > 0 && contact.selectedForInvite {
                    recipients.append(contact.number)
                }
            }
            if recipients.count == 0 {
                Helper.showAlert("", message: "No contact with number found.")
            }else {
                sendMessage(recipients)
            }
        }
    }
    
    @IBAction func changeTabAct(sender: UIButton) {
        
        currentTab = sender.tag
        adjustTabs()
        filterContacts(searchTxt.text!)
        contactsTbl.reloadData()
        contactsTbl.hidden = filteredContacts.count == 0
        noContactsLbl.hidden = filteredContacts.count > 0
        
    }
    
}








