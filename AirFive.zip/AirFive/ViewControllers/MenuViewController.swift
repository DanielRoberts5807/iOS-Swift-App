//
//  MenuViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 18/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class MenuViewController : UIViewController {
    
    @IBOutlet weak var coverImg: UIImageView!
    @IBOutlet weak var nameLbl: TopAlignedLabel!
    @IBOutlet weak var schoolImg: UIImageView!
    @IBOutlet weak var schoolLbl: TopAlignedLabel!
    @IBOutlet weak var eventsCountLbl: UILabel!
    
    var currentMenuItemTag = 1
    
    override func viewWillLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        
        if eventsCountLbl != nil {
            eventsCountLbl.layer.masksToBounds = true
            eventsCountLbl.layer.cornerRadius = eventsCountLbl.frame.size.height / 2
        }
    }
    
    func getViewControllerIdentifier(menuItemTag:Int) -> String? {
        
        var viewControllerIdentifier:String?
        switch menuItemTag {
        case 1:
            viewControllerIdentifier = "DashBoardViewController"
        case 2:
            viewControllerIdentifier = "ContactsViewController"
        case 3:
            viewControllerIdentifier = "FeedsViewController"
        case 4:
            viewControllerIdentifier = "EventsViewController"
        case 5:
            viewControllerIdentifier = "SettingsViewController"
        case 6:
            Helper.saveValue(FeedsFilter.Jobs.rawValue, forKey: "feedsFilter")
            viewControllerIdentifier = "FeedsViewController"
        case 8:
            viewControllerIdentifier = "InviteViewController"
        default:
            break
        }
        return viewControllerIdentifier
        
    }
    
}

extension MenuViewController {

    @IBAction func menuItemClickedAct(sender: UIButton) {
        
        let menuItemTag = sender.tag
        openMenuItemWithTag(menuItemTag)
        
    }
    
    func openMenuItemWithTag(menuItemTag:Int) {
    
        if menuItemTag == 7 { //Logout
            
            Helper.saveUserId(nil)
            menuContainerViewController.setMenuState(MFSideMenuStateClosed, completion: nil)
            Helper.presentViewControllerWithIdentifier("SignInViewController", animated: true)
            return
            
        }else if menuItemTag == 9 { //facebook invite
            
            FacebookDataLoader().invite(Helper.getTopRootViewController(), applink:Helper.appLink)
            menuContainerViewController.setMenuState(MFSideMenuStateClosed, completion: nil)
            return
            
        }
        
        if menuItemTag != currentMenuItemTag {
            if let viewControllerIdentifier = getViewControllerIdentifier(menuItemTag) {
                
                let viewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier(viewControllerIdentifier)
                menuContainerViewController.centerViewController = viewController
                
            }
        }
        currentMenuItemTag = menuItemTag
        menuContainerViewController.setMenuState(MFSideMenuStateClosed, completion: nil)
        
    }
    
}








