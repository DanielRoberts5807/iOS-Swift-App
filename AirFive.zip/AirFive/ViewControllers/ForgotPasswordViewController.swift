//
//  ForgotPasswordViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 12/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class ForgotPasswordViewController : BaseViewController {
    
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var sendBtn: UIButton!
    
    var alertPopup:KLCPopup! = nil
    var successAlert:UIBlockAlert! = nil
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        if emailTxt != nil {
            setPlaceHolder("Email", textField: emailTxt)
            addBottomBorder(emailTxt)
        }
        
        if sendBtn != nil {
            sendBtn.layer.cornerRadius = sendBtn.frame.size.height / 2
        }
        
    }

}

extension ForgotPasswordViewController {
    
    @IBAction func backAct(sender: UIButton) {
        
        dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    @IBAction func sendAct(sender: UIButton) {
        
        if emailTxt.text?.characters.count == 0 {
            Helper.showAlert("", message: "SMH, you didn't type an email.")
            return
        }else if Helper.isValidEmail(emailTxt.text!) == false {
            Helper.showAlert("", message: "Ahem, we’ll need a valid email address to get going.")
            return
        }
        
        WebServices.getSharedWebServices().forgotPassword(emailTxt.text!, successCallback: { (message:String) -> Void in
            
            self.dismissKeyboard()
            self.successAlert = UIBlockAlert(title: "", message: message, cancelButtonTitle: "OK", otherButtonTitle: nil, callback: { (btn:Int) in
                self.dismissViewControllerAnimated(true, completion: nil)
            })
            
        }, failureCallback:  { (message:String) -> Void in
                
            Helper.showAlert("", message: message)
                
        })
        
    }

}
