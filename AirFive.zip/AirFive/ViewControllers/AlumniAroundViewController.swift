//
//  AlumniAroundViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 30/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class AlumniAroundViewController : BaseViewController {
    
    @IBOutlet weak var searchTxt: UITextField!
    @IBOutlet weak var searchBtmLine: UIView!
    @IBOutlet weak var alumniTbl: UITableView!
    @IBOutlet weak var progressView: M13ProgressViewRing!
    @IBOutlet weak var noAlumniLbl: UILabel!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        addDissmissWithSwipeGesture()
        
    }
    
    var alumniAround:[Alumni] = []
    var alumniTblData:[Alumni] = []
    var blockAlert:UIBlockAlert! = nil
    var progressViewCount = 0
    
    var confirmationPopup:KLCPopup! = nil
    var currentAlumniId:String! = nil
    var currentInvitation:String! = nil
    
    var instructionPopup:KLCPopup! = nil
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        loadDataFromServer()
        
    }
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        if searchBtmLine != nil {
            searchBtmLine.layer.shadowColor = Helper.getAppGreyColor().CGColor
            searchBtmLine.layer.shadowOffset = CGSize(width: 0, height: 2)
            searchBtmLine.layer.shadowOpacity = 1
            searchBtmLine.layer.masksToBounds = false
            
        }
        
        if alumniTbl != nil {
            alumniTbl.tableFooterView = UIView()
        }
        
        if progressView != nil {
            progressView.backgroundRingWidth = 2
            progressView.showPercentage = false
            progressView.indeterminate = true
        }
    }

    func loadDataFromServer() {
        
        WebServices.getSharedWebServices().getAlumniAround({ (message:String, alumniArr:[Alumni]) -> Void in
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.alumniAround = alumniArr
                self.alumniTblData = self.alumniAround
                self.alumniTbl.reloadData()
                
                self.alumniTbl.hidden = self.alumniTblData.count == 0
                self.noAlumniLbl.hidden = self.alumniTblData.count > 0
                
            })
            
            }, failureCallback: { (message:String) -> Void in
                
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    Helper.showAlert("", message: message)
                })
                
        })
        
    }
    
}

extension AlumniAroundViewController {
    
    func textFieldDidBeginEditing(textField: UITextField) {
//        alumniTblData = []
//        alumniTbl.reloadData()
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
//        alumniTblData = alumniAround
//        alumniTbl.reloadData()
    }

    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        let searchTxt = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        if searchTxt.characters.count == 0 {
            
            alumniTblData = alumniAround
            alumniTbl.reloadData()
            alumniTbl.hidden = alumniTblData.count == 0
            noAlumniLbl.hidden = alumniTblData.count > 0
            
        }else {
            progressViewCount += 1
            progressView.hidden = false
            WebServices.getSharedWebServices().searchAlumni(searchTxt, successCallback:{ (message:String, alumniArr:[Alumni]) -> Void in
                
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    self.progressViewCount -= 1
                    if self.progressViewCount <= 0 {
                        self.progressView.hidden = true
                    }
                    if self.searchTxt.text!.characters.count > 0 {
                        
                        self.alumniTblData = alumniArr
                        self.alumniTbl.reloadData()
                        self.alumniTbl.hidden = self.alumniTblData.count == 0
                        self.noAlumniLbl.hidden = self.alumniTblData.count > 0
                        
                    }
                })
                
            }, failureCallback: { (message:String) -> Void in
                    
                self.progressViewCount -= 1
                if self.progressViewCount <= 0 {
                    self.progressView.hidden = true
                }
                    
            })
        }
        
        return true
    }
    
}

extension AlumniAroundViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("AlumniCell")! as! AlumniCell
        
        let alumni = alumniTblData[indexPath.row]
        
        cell.profileImg.setImageWithURL(NSURL(string: alumni.profileImg)!, placeholderImage: UIImage(named:"profileImgPlaceholder"))
        cell.nameLbl.text = alumni.name
        if alumni.title.characters.count > 0 && alumni.company.characters.count > 0 {
            cell.titleLbl.text = alumni.title + " at " + alumni.company
        }else {
            cell.titleLbl.text = alumni.title + alumni.company
        }
        
        cell.selectedLblCallback = {(selectedLblPosition:SelectedLblPosition) in
            
            var invite = ""
            var foodCaffiene = ""
            if selectedLblPosition == SelectedLblPosition.Left {
                invite = "coffee"
                foodCaffiene = "caffeine"
            }else {
                invite = "bite"
                foodCaffiene = "food"
            }
            
            self.dismissKeyboard()
            self.showConfirmationPopup(invite, foodCaffiene:foodCaffiene, alumni: alumni)
            
        }
        
        cell.tapCallback = {
            
            self.showInstructionPopup(alumni)
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumniTblData.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 120 / 600 * UIScreen.mainScreen().bounds.size.height
    }
    
    func showConfirmationPopup(invitation:String, foodCaffiene:String, alumni:Alumni) {
        
        currentAlumniId = alumni.id
        currentInvitation = invitation
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapDissmiss:")
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.5))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        let tapGestureStop = UITapGestureRecognizer(target: self, action: "tapDissmissStop:")
        innerContainer.addGestureRecognizer(tapGestureStop)
        
        let titleLbl = UILabel(frame: CGRect(x: 10, y: 20, width: innerContainer.frame.size.width - 20, height: innerContainer.frame.size.height * 0.4))
        titleLbl.textColor = Helper.getAppBlackColor()
        titleLbl.font = Helper.getBoldFont(22)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.numberOfLines = 0
        
        if alumni.isAdmin {
            titleLbl.text = "Jeremy loves grabbing coffee and will grab one with anyone!"
        }else {
            titleLbl.text = "Super duper! You want a " + invitation + " with " + alumni.name + ". May the " + foodCaffiene + " be with you!"
        }
        
        innerContainer.addSubview(titleLbl)
        
        tmp = innerContainer.frame.size.width * 0.25
        let acceptBtn = UIBlockButton(frame: CGRect(x: ((innerContainer.frame.size.width - tmp) / 2), y: (titleLbl.frame.origin.y + titleLbl.frame.size.height + 4), width: tmp, height: tmp * 1.14))
        
        tmp = innerContainer.frame.size.width * 0.35
        let handImg = UIImageView(frame:CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        handImg.image = UIImage(named:"hand.gif")
        
        handImg.center = acceptBtn.center
        innerContainer.addSubview(handImg)
        
        innerContainer.addSubview(acceptBtn)
        
        tmp = innerContainer.frame.size.height * 0.25
        let rejectBtn = UIBlockButton(frame: CGRect(x: titleLbl.frame.origin.x, y: (innerContainer.frame.size.height - tmp), width: titleLbl.frame.size.width, height: tmp))
        
        rejectBtn.setTitleColor(Helper.getAppBlackColor(), forState: UIControlState.Normal)
        rejectBtn.setTitle(("Whoops! That isn't what I wanted to do"), forState: UIControlState.Normal)
        rejectBtn.titleLabel?.font = Helper.getNormalFont()
        rejectBtn.titleLabel?.textAlignment = NSTextAlignment.Center
        
        let attributes = [NSUnderlineStyleAttributeName: NSUnderlineStyle.StyleSingle.rawValue]
        let attributedText = NSAttributedString(string: rejectBtn.currentTitle!, attributes: attributes)
        
        rejectBtn.titleLabel?.attributedText = attributedText
        
        innerContainer.addSubview(rejectBtn)
        
        container.addSubview(innerContainer)
        
        tmp = innerContainer.frame.origin.y + innerContainer.frame.size.height
        let bottomContainer = UIView(frame: CGRect(x: innerContainer.frame.origin.x, y: tmp, width: innerContainer.frame.size.width, height: container.frame.size.height - tmp))
        
        tmp = bottomContainer.frame.size.width * 0.2
        let cancelBtn = UIBlockButton(frame: CGRect(x: ((bottomContainer.frame.size.width - tmp) / 2), y: ((bottomContainer.frame.size.height - tmp) / 2), width: tmp, height: tmp))
        cancelBtn.setBackgroundImage(UIImage(named: "notificationClose"), forState: UIControlState.Normal)
        
        
        bottomContainer.addSubview(cancelBtn)
        
        container.addSubview(bottomContainer)
        
        
        confirmationPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: false, dismissOnContentTouch: false)
        confirmationPopup.dimmedMaskAlpha = 0.85
        
        acceptBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.confirmationPopup.dismissPresentingPopup()
            self.sendInvite(invitation, alumniId: alumni.id)
            
        }
        
        rejectBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.confirmationPopup.dismissPresentingPopup()
            
        }
        
        cancelBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.confirmationPopup.dismissPresentingPopup()
            self.sendInvite(invitation, alumniId: alumni.id)
            
        }
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        confirmationPopup.showWithLayout(layout)
        
    }
    
    func tapDissmiss(tap:UITapGestureRecognizer) {
        
        self.confirmationPopup.dismissPresentingPopup()
        if currentInvitation != nil {
            self.sendInvite(currentInvitation, alumniId: currentAlumniId)
        }
        
    }
    
    func tapDissmissStop(tap:UITapGestureRecognizer) {
    }
    
    func sendInvite(invitation:String, alumniId:String) {
        
        WebServices.getSharedWebServices().inviteAlumi(alumniId, invite:invitation, successCallback:   { (message:String) -> Void in
            
//            Helper.showAlert("", message: message)
            
        }, failureCallback: { (message:String) -> Void in
                
            Helper.showAlert("", message: message)
                
        })
        
    }
    
    func showInstructionPopup(alumni:Alumni) {
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let margin:CGFloat = 20
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapInstructinDissmiss:")
        tapGesture.delegate = self
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: margin, y: margin, width: width - 2 * margin, height: height - 2 * margin))
        innerContainer.backgroundColor = UIColor(white: 65.0/255.0, alpha: 1.0)
        innerContainer.layer.cornerRadius = 5
        
        tmp = innerContainer.frame.size.height * 0.35
        let dragLeftLbl = UILabel(frame: CGRect(x: margin, y: margin, width: innerContainer.frame.size.width - 2 * margin, height: 30))
        dragLeftLbl.textColor = UIColor(white: 120.0/255.0, alpha: 0.8)
        dragLeftLbl.font = Helper.getNormalFont(14)
        dragLeftLbl.textAlignment = NSTextAlignment.Center
        dragLeftLbl.numberOfLines = 0
        dragLeftLbl.text = "Drag to left to grab coffee"
        
        innerContainer.addSubview(dragLeftLbl)
        
        let dragRightLbl = UILabel(frame: CGRect(x: margin, y: innerContainer.frame.size.height - (margin + 30), width: innerContainer.frame.size.width - 2 * margin, height: 30))
        dragRightLbl.textColor = UIColor(white: 120.0/255.0, alpha: 0.8)
        dragRightLbl.font = Helper.getNormalFont(14)
        dragRightLbl.textAlignment = NSTextAlignment.Center
        dragRightLbl.numberOfLines = 0
        dragRightLbl.text = "Drag to right to grab a bite to eat"
        
        innerContainer.addSubview(dragRightLbl)
        
        let profileImg = UIImageView(frame: CGRect(x: 0, y: 0, width: 120, height: 120))
        profileImg.center = CGPoint(x: innerContainer.frame.size.width / 2, y: innerContainer.frame.size.height / 2)
        profileImg.image = UIImage(named: "profileImgPlaceholder")
        profileImg.setImageWithURL(NSURL(string: alumni.profileImg)!, placeholderImage: UIImage(named:"profileImgPlaceholder"))
        profileImg.clipsToBounds = true
        profileImg.layer.cornerRadius = profileImg.frame.size.height / 2
        
        innerContainer.addSubview(profileImg)
        
        tmp = profileImg.frame.origin.y - 35
        let titleCompLbl = UILabel(frame: CGRect(x: margin, y: tmp, width: innerContainer.frame.size.width - 2 * margin, height: 25))
        titleCompLbl.textColor = Helper.getAppGreenColor()
        titleCompLbl.font = Helper.getNormalFont(14)
        titleCompLbl.textAlignment = NSTextAlignment.Center
        
        if alumni.title.characters.count > 0 && alumni.company.characters.count > 0 {
            titleCompLbl.text = alumni.title + " @ " + alumni.company
        }else {
            titleCompLbl.text = alumni.title + alumni.company
        }
        
        innerContainer.addSubview(titleCompLbl)
        
        tmp = titleCompLbl.frame.origin.y - 35
        let nameLbl = UILabel(frame: CGRect(x: margin, y: tmp, width: innerContainer.frame.size.width - 2 * margin, height: 25))
        nameLbl.textColor = Helper.getAppGreenColor()
        nameLbl.font = Helper.getBoldFont(16)
        nameLbl.textAlignment = NSTextAlignment.Center
        nameLbl.text = alumni.name
        
        innerContainer.addSubview(nameLbl)
        
        tmp = profileImg.frame.origin.y + profileImg.frame.size.height + 10
        let personalStmtTitleLbl = UILabel(frame: CGRect(x: margin, y: tmp, width: innerContainer.frame.size.width - 2 * margin, height: 20))
        personalStmtTitleLbl.textColor = Helper.getAppGreyColor()
        personalStmtTitleLbl.font = Helper.getNormalFont(10)
        personalStmtTitleLbl.textAlignment = NSTextAlignment.Center
        personalStmtTitleLbl.text = "Personal Statement"
        
        innerContainer.addSubview(personalStmtTitleLbl)
        
        tmp = personalStmtTitleLbl.frame.origin.y + personalStmtTitleLbl.frame.size.height + 10
        let personalStmtLbl = TopAlignedLabel(frame: CGRect(x: margin, y: tmp, width: innerContainer.frame.size.width - 2 * margin, height: 40))
        personalStmtLbl.textColor = Helper.getAppWhiteColor()
        personalStmtLbl.font = Helper.getNormalFont(14)
        personalStmtLbl.textAlignment = NSTextAlignment.Center
        personalStmtLbl.text = alumni.personalStmt.characters.count > 0 ? "\"\(alumni.personalStmt)\"" : ""
        
        innerContainer.addSubview(personalStmtLbl)
        
        container.addSubview(innerContainer)
        
        instructionPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        instructionPopup.dimmedMaskAlpha = 0.85
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        instructionPopup.showWithLayout(layout)
        
    }
    
    func tapInstructinDissmiss(tap:UITapGestureRecognizer) {
        if instructionPopup != nil {
            instructionPopup.dismissPresentingPopup()
        }
    }
    
}

extension AlumniAroundViewController {

    @IBAction func backAct(sender: UIButton) {
        
        dismissViewControllerAnimated(true, completion: nil)
        
    }
    
}


