//
//  SignInViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 10/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class SignInViewController : BaseViewController {
    
    @IBOutlet weak var emailTxt: UITextField!
    @IBOutlet weak var passwordTxt: UITextField!
    
    @IBOutlet weak var forgotPasswordView: UIView!
    @IBOutlet weak var signUpView: UIView!
    @IBOutlet weak var facebookView: UIView!
    @IBOutlet weak var linkedinView: UIView!
    
    @IBOutlet weak var signInBtnView: UIView!
    @IBOutlet weak var innerTopContainer: UIView!
    
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var backImg: UIImageView!
    
    var signInBtnInitialY:CGFloat = -1, innerTopContainerInitialY:CGFloat = -1
    var keyboardOpened:Bool = false
    var alertPopup:KLCPopup! = nil
    
    var processingPopupView:UIView! = nil
    var processingProgressView:M13ProgressViewRing! = nil
    
    var hideBack = true
    
    var schoolEntryPopup:KLCPopup! = nil
    var schoolAutoTxt:AutoCompleteTextField! = nil
    var popupSchPrView:M13ProgressViewRing! = nil
    var popupSchPrCount = 0
    
    var socialImg:UIImage! = nil
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        backBtn.hidden = hideBack
        backImg.hidden = hideBack
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        if processingProgressView != nil {
            processingProgressView.indeterminate = true
        }
    }
    
    override func viewDidLayoutSubviews() {
        
        view.tag = 20
        
        super.viewDidLayoutSubviews()
        if emailTxt != nil {
            setPlaceHolder("Email", textField: emailTxt)
            addBottomBorder(emailTxt)
        }
        
        if passwordTxt != nil {
            setPlaceHolder("Password", textField: passwordTxt)
            addBottomBorder(passwordTxt)
        }
        
        if signInBtnView != nil && !keyboardOpened {
            signInBtnInitialY = signInBtnView.frame.origin.y
        }
        
        if innerTopContainer != nil && !keyboardOpened {
            innerTopContainerInitialY = innerTopContainer.frame.origin.y
        }
        
    }
    
}

extension SignInViewController {
    
    override func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldReceiveTouch touch: UITouch) -> Bool {
        
        if schoolAutoTxt != nil && touch.view?.isDescendantOfView(schoolAutoTxt.autoCompleteTableView!) == true {
            return false
        }else if touch.view?.isDescendantOfView(signInBtnView!) == true {
            return false
        }
        return true
        
    }
    
}

extension SignInViewController {

    override func keyboardWillShow(notification: NSNotification) {
        
        if let userInfo = notification.userInfo {
            
            keyboardOpened = true
            
            let animationDuration = userInfo[UIKeyboardAnimationDurationUserInfoKey]?.doubleValue
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.unsignedLongValue ?? UIViewAnimationOptions.CurveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            
            let keyboardSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).CGRectValue().size
            let keyboardHeight = min(keyboardSize.height,keyboardSize.width);
            
            UIView.animateWithDuration(animationDuration!, delay: 0, options: animationCurve
                , animations: { () -> Void in
                
                    let newY = self.signInBtnInitialY - keyboardHeight - 70 //70 height of 2 fields
                    var delta = newY - self.innerTopContainerInitialY
                    if delta > 0 {
                        delta = 0
                    }
                    self.innerTopContainer.transform = CGAffineTransformMakeTranslation(0, delta)
                    self.signInBtnView.transform = CGAffineTransformMakeTranslation(0, -1 * keyboardHeight)
                
                }, completion: nil)
            
        }
        
    }
    
    override func keyboardWillHide(notification: NSNotification) {
        
        if let userInfo = notification.userInfo {
            
            keyboardOpened = false
            
            let animationDuration = userInfo[UIKeyboardAnimationDurationUserInfoKey]?.doubleValue
            let animationCurveRawNSN = userInfo[UIKeyboardAnimationCurveUserInfoKey] as? NSNumber
            let animationCurveRaw = animationCurveRawNSN?.unsignedLongValue ?? UIViewAnimationOptions.CurveEaseInOut.rawValue
            let animationCurve:UIViewAnimationOptions = UIViewAnimationOptions(rawValue: animationCurveRaw)
            
            UIView.animateWithDuration(animationDuration!, delay: 0, options: animationCurve
                , animations: { () -> Void in
                    
                    self.innerTopContainer.transform = CGAffineTransformMakeTranslation(0, 0)
                    self.signInBtnView.transform = CGAffineTransformMakeTranslation(0, 0)
                    
                }, completion: nil)
            
        }
        
    }
    
}


extension SignInViewController {

    @IBAction func backAct(sender: UIButton) {
        
        dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    @IBAction func passwordHintAct(sender: UIButton) {
        
        passwordTxt.secureTextEntry = !passwordTxt.secureTextEntry
        
    }
    
    @IBAction func signInWithFacebookAct(sender: UIButton) {
        
        showProcessingPopup("Getting data from Facebook")
        performSelector("signInWithFacebookHelper", withObject: nil, afterDelay: 0.2)
        
    }
    
    func signInWithFacebookHelper() {
    
        let fbDataLoader = FacebookDataLoader()
        
        fbDataLoader.processLogin(self, successCallback: { (userData:[String : AnyObject]) -> Void in
            
            print(userData)
            let email = userData["email"] as! String
            let name = userData["name"] as! String
            let url = userData["link"] as! String
            let imgUrl = ((userData["picture"] as! [String: AnyObject])["data"] as! [String: AnyObject])["url"] as! String
            WebServices.getSharedWebServices().getImage(imgUrl, successCallback: { (img:UIImage) -> Void in
                self.socialImg = img;
                self.signUpHelper(email, name:name, signUpFrom: SignUpFrom.Facebook, url: url)
            }, failureCallback:  { (message:String) -> Void in
                print(message)
                self.signUpHelper(email, name:name, signUpFrom: SignUpFrom.Facebook, url: url)
            })
            
        }, failureCallback: { (message:String) -> Void in
            
            self.processingPopupView.removeFromSuperview()
            print(message)
            if !message.containsString("User Canceled") {
                Helper.showAlert("", message: Helper.genericErrorMsg)
            }
                
        })
        
    }
    
    @IBAction func signInWithLinkedInAct(sender: UIButton) {
        
        showProcessingPopup("Getting data from Linkedin")
        performSelector("signInWithLinkedinHelper", withObject: nil, afterDelay: 0.2)
        
    }
    
    func signInWithLinkedinHelper() {
        let liDataLoader = LinkedInDataLoader()
        liDataLoader.process(self, successCallback: { (userData:[String : AnyObject]) -> Void in
            
            print(userData)
            let email = userData["emailAddress"] as! String
            let name = (userData["firstName"] as! String) + " " + (userData["lastName"] as! String)
            let url = userData["publicProfileUrl"] as! String
            if userData.keys.contains("pictureUrl") == true {
                let imgUrl = userData["pictureUrl"] as! String
                WebServices.getSharedWebServices().getImage(imgUrl, successCallback: { (img:UIImage) -> Void in
                    self.socialImg = img;
                    self.signUpHelper(email, name:name, signUpFrom: SignUpFrom.Linkedin, url: url)
                }, failureCallback:  { (message:String) -> Void in
                    print(message)
                    self.signUpHelper(email, name:name, signUpFrom: SignUpFrom.Linkedin, url: url)
                })
            }else {
                self.signUpHelper(email, name:name, signUpFrom: SignUpFrom.Linkedin, url: url)
            }
            
        }, failureCallback: { (message:String) -> Void in
            
            self.processingPopupView.removeFromSuperview()
            print(message)
            if !message.containsString("User Canceled") {
                Helper.showAlert("", message: Helper.genericErrorMsg)
            }
                
        })
        
    }
    
    func signUpHelper(email:String, name:String, signUpFrom:SignUpFrom, url:String) {
        
        WebServices.getSharedWebServices().signUp(true, name: name, email: email, password: "", school: "", signUpFrom: signUpFrom, successCallback: { (userId:String, message:String, school:String, profileImg:String) -> Void in
            
            var parameters = [String: String]()
            if signUpFrom == SignUpFrom.Facebook {
                parameters = ["facebook_url": url]
            }else {
                parameters = ["linkedin_url": url]
            }
            Helper.saveValue(signUpFrom.rawValue, forKey: "signInFrom")
            
            if self.socialImg != nil && profileImg.characters.count == 0 {
                Helper.saveUserId(userId)
                let profileImgData = UIImageJPEGRepresentation(self.socialImg, 1.0)
                WebServices.getSharedWebServices().uploadImage("profile", imageData:profileImgData!, successCallback: { (msg:String) -> Void in
                    self.setSocialConnection(parameters, userId: userId, message: message, school: school)
                }, failureCallback: { (msg:String) -> Void in
                    self.setSocialConnection(parameters, userId: userId, message: message, school: school)
                })
            }else {
                self.setSocialConnection(parameters, userId: userId, message: message, school: school)
            }
      
            
        }, failureCallback:  { (message:String) -> Void in
                
            self.processingPopupView.removeFromSuperview()
            Helper.showAlert("", message: message)
                
        })
        
    }
    
    func setSocialConnection(parameters:[String:String], userId:String, message:String, school:String) {
       
        Helper.saveUserId(userId)
        let callback = {(msg:String) -> Void in
            Helper.saveUserId(nil)
            self.processingPopupView.removeFromSuperview()
            
            if school.characters.count > 0 {
                self.signInSuccessHelper(userId, message: message)
            }else {
                self.showSchoolEntryPopup(userId)
            }
        }
        
        WebServices.getSharedWebServices().setSocialConnection(parameters, successCallback: callback, failureCallback: callback)
        
    }
    
    @IBAction func signInAct(sender: UIButton) {
        
        if emailTxt.text?.characters.count == 0 || passwordTxt.text?.characters.count == 0 {
            Helper.showAlert("", message: "Oopsie Daisy - Please add a valid email address and password to proceed.")
            return
        }else if Helper.isValidEmail(emailTxt.text!) == false {
            Helper.showAlert("", message: "Ahem, we’ll need a valid email address to get going.")
            return
        }
        
        Helper.showCustomProgress(self)
        WebServices.getSharedWebServices().signIn(emailTxt.text!, password: passwordTxt.text!, successCallback: { (userId:String, message:String) -> Void in
            
            Helper.saveValue("email", forKey: "signInFrom")
            self.signInSuccessHelper(userId, message: message)
            
        }, failureCallback:  { (message:String) -> Void in
        
            Helper.hideCustomProgress()
            Helper.showAlert("", message: message)
            
        })
        
    }
    
    func signInSuccessHelper(userId:String, message:String) {
        
        dismissKeyboard()
        let delayTime = dispatch_time(DISPATCH_TIME_NOW, Int64(0.5 * Double(NSEC_PER_SEC)))
        dispatch_after(delayTime, dispatch_get_main_queue()) {
            Helper.hideCustomProgress()
            Helper.saveUserId(userId)
            Helper.saveValue("true", forKey: "shouldGetUserFromServer")
            
            Helper.presentViewControllerWithIdentifier("MenuRootViewController", animated: true)
            var msg = message.stringByReplacingOccurrencesOfString("u{1f44d}", withString: "\u{1f44d}")
            msg = msg.stringByReplacingOccurrencesOfString("u{1f44c}", withString: "\u{1f44c}")
            Helper.showAlert("", message: msg)
        }
        
    }
    
    func showProcessingPopup(message:String) {
        
        let width = UIScreen.mainScreen().bounds.size.width , height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        container.backgroundColor = UIColor(white: 0, alpha: 0.85)
        
        var tmp = (height - (height * 0.3)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.3))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        tmp = innerContainer.frame.size.width * 0.25
        let x = (innerContainer.frame.size.width - tmp) / 2
        processingProgressView = M13ProgressViewRing(frame: CGRect(x: x, y: 30, width: tmp, height: tmp), color:Helper.getAppBlackColor())
        processingProgressView.indeterminate = true
        processingProgressView.backgroundRingWidth = 5
        processingProgressView.showPercentage = false
        
        innerContainer.addSubview(processingProgressView)
        
        tmp = processingProgressView.frame.origin.y + processingProgressView.frame.size.height + 20
        let titleLbl = UILabel(frame: CGRect(x: 20, y: tmp, width: innerContainer.frame.size.width - 40, height: innerContainer.frame.size.height - tmp))
        titleLbl.textColor = Helper.getAppBlackColor()
        titleLbl.font = Helper.getBoldFont(16)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.numberOfLines = 0
        titleLbl.text = message
        
        innerContainer.addSubview(titleLbl)
        
        container.addSubview(innerContainer)
        
        processingPopupView = container
        self.view.addSubview(processingPopupView)
        
        dispatch_async(dispatch_get_main_queue()) {
            self.processingProgressView.indeterminate = true
        }
        
    }
    
    func setSchoolTextField() {
    
        schoolAutoTxt.autocorrectionType = UITextAutocorrectionType.No
        schoolAutoTxt.autoCompleteTextColor = Helper.getAppWhiteColor()
        schoolAutoTxt.autoCompleteTextFont = Helper.getNormalFont()
        
        
        schoolAutoTxt.autoCompleteCellHeight = 25
        schoolAutoTxt.maximumAutoCompleteCount = 10
        
        schoolAutoTxt.hidesWhenSelected = true
        schoolAutoTxt.hidesWhenEmpty = true
        schoolAutoTxt.enableAttributedText = true
        
        
        let attributes = [NSForegroundColorAttributeName:Helper.getAppWhiteColor(), NSFontAttributeName : Helper.getBoldFont()]
        schoolAutoTxt.autoCompleteAttributes = attributes
        
        schoolAutoTxt.onTextChange = {(text:String) in
            
            if text.characters.count == 0 {
                
                self.schoolAutoTxt.autoCompleteStrings = []
                return
                
            }
            
            self.popupSchPrCount += 1
            self.popupSchPrView.hidden = false
            
            WebServices.getSharedWebServices().getSchool(text, successCallback: { (schools:[String]) in
                
                self.schoolAutoTxt.autoCompleteStrings = schools
                self.popupSchPrCount -= 1
                if self.popupSchPrCount <= 0 {
                    self.popupSchPrView.hidden = true
                }
                
                }, failureCallback: { (message:String) in
                    
                    self.popupSchPrCount -= 1
                    if self.popupSchPrCount <= 0 {
                        self.popupSchPrView.hidden = true
                    }
                    
            })
            
        }
        
        schoolAutoTxt.adjustAutoCompleteTable(schoolAutoTxt.frame.size.width, separatorColor: Helper.getAppWhiteColor(), tableBgColor: Helper.getAppGreenColor())
        schoolAutoTxt.autoCompleteStrings = []
        
    }
    
    func showSchoolEntryPopup(userId:String) {
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapDissmiss:")
        tapGesture.delegate = self
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.5))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        let tapGestureStop = UITapGestureRecognizer(target: self, action: "tapDissmissStop:")
        tapGestureStop.delegate = self
        innerContainer.addGestureRecognizer(tapGestureStop)
        
        let titleLbl = UILabel(frame: CGRect(x: 20, y: 20, width: innerContainer.frame.size.width - 40, height: innerContainer.frame.size.height * 0.20))
        titleLbl.textColor = Helper.getAppBlackColor()
        titleLbl.font = Helper.getBoldFont(22)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.numberOfLines = 0
        titleLbl.text = "Welcome to AirFive!\nPlease select a"
        
        innerContainer.addSubview(titleLbl)
        
        tmp = innerContainer.frame.size.height * 0.08
        schoolAutoTxt = AutoCompleteTextField(frame: CGRect(x: titleLbl.frame.origin.x, y: (titleLbl.frame.origin.y + titleLbl.frame.size.height + 10), width: titleLbl.frame.size.width, height: tmp))
        
        let prHeight = tmp * 0.7
        popupSchPrView = M13ProgressViewRing(frame:CGRect(x: schoolAutoTxt.frame.origin.x + schoolAutoTxt.frame.size.width - (prHeight + 5.0), y: schoolAutoTxt.frame.origin.y, width: prHeight, height: prHeight), color:Helper.getAppGreyColor())
        popupSchPrView.showPercentage = false
        popupSchPrView.backgroundRingWidth = 2
        dispatch_async(dispatch_get_main_queue()) {
            self.popupSchPrView.indeterminate = true
        }
        popupSchPrView.hidden = true
        popupSchPrCount = 0
        
        tmp = innerContainer.frame.size.width * 0.25
        let acceptBtn = UIBlockButton(frame: CGRect(x: ((innerContainer.frame.size.width - tmp) / 2), y: (schoolAutoTxt.frame.origin.y + schoolAutoTxt.frame.size.height + (innerContainer.frame.size.height * 0.15)), width: tmp, height: tmp * 1.14))
        
        tmp = innerContainer.frame.size.width * 0.35
        let handImg = UIImageView(frame:CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        handImg.image = UIImage(named:"hand.gif")
        
        handImg.center = acceptBtn.center
        innerContainer.addSubview(handImg)
        
        innerContainer.addSubview(acceptBtn)
        
        innerContainer.addSubview(schoolAutoTxt)
        innerContainer.addSubview(popupSchPrView)

        schoolAutoTxt.setupAutocompleteTable(schoolAutoTxt.superview!)
        addBottomBorder(schoolAutoTxt)
        schoolAutoTxt.attributedPlaceholder = NSAttributedString(string: "School", attributes: [NSForegroundColorAttributeName : Helper.getAppGreenColor()])
        schoolAutoTxt.dismissKeyboardWhenSelected = true
        schoolAutoTxt.returnKeyType = UIReturnKeyType.Done
        
        schoolAutoTxt.delegate = self
        
        setSchoolTextField()
        
        container.addSubview(innerContainer)
        
        schoolEntryPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        schoolEntryPopup.dimmedMaskAlpha = 0.85
        
        
        acceptBtn.callback = {(button:UIBlockButton) -> Void in
            
            if self.schoolAutoTxt.text?.characters.count == 0 {
                Helper.showAlert("", message: "Please enter a school name")
                return
            }
            
            Helper.saveUserId(userId)

            Helper.showCustomProgress(self)
            
            let parameters = ["school":self.schoolAutoTxt.text!]
            WebServices.getSharedWebServices().setUser(parameters, successCallback: { (message:String) -> Void in
                
                self.schoolEntryPopup.dismissPresentingPopup()
                self.signInSuccessHelper(userId, message: "Welcome to AirFive nation! Be sure to have u{1f44d} fun")
                
            }, failureCallback: { (message:String) -> Void in
                
                self.schoolEntryPopup.dismissPresentingPopup()
                Helper.hideCustomProgress()
                Helper.showAlert("", message: message)
                
            })
            
        }
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        schoolEntryPopup.showWithLayout(layout)
        
    }
    
    func tapDissmiss(tap:UITapGestureRecognizer) {
        self.schoolEntryPopup.dismissPresentingPopup()
        processingPopupView.removeFromSuperview()
    }
    
    func tapDissmissStop(tap:UITapGestureRecognizer) {
    }
    
}