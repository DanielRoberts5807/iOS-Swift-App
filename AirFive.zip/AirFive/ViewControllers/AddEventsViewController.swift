//
//  AddEventsViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 18/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class AddEventsViewController : BaseViewController {
}

extension AddEventsViewController {
    
    @IBAction func openMenuAct(sender: UIButton) {
        slideMenuController()?.openLeft()
    }
    
}