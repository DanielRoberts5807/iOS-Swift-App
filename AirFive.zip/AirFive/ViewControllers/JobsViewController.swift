//
//  JobsViewController.swift
//  AirFive
//
//  Created by Muhammad Umair on 6/29/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit
import FBSDKShareKit

class JobsViewController : BaseViewController {
    
    
    @IBOutlet weak var tabBtnsScrollView: UIScrollView!
    @IBOutlet weak var selectedTabIndicatorView: UIView!
    @IBOutlet weak var selectedTabIndicatorLeadingSpace: NSLayoutConstraint!
    
    @IBOutlet weak var tabScrollView: UIScrollView!
    
    @IBOutlet weak var nearestTbl: UITableView!
    @IBOutlet weak var internshipTbl: UITableView!
    @IBOutlet weak var partTimeTbl: UITableView!
    @IBOutlet weak var fullTimeTbl: UITableView!
    
    @IBOutlet weak var newPostsBtmLine: UIView!
    
    @IBOutlet weak var nearestSrchTxt: UITextField!
    @IBOutlet weak var internshipSrchTxt: UITextField!
    @IBOutlet weak var partTimeSrchTxt: UITextField!
    @IBOutlet weak var fullTimeSrchTxt: UITextField!

    var nearestJobs:[Job] = []
    var nearestFilteredJobs:[Job] = []
    
    var internshipJobs:[Job] = []
    var internshipFilteredJobs:[Job] = []
    
    var partTimeJobs:[Job] = []
    var partTimeFitleredJobs:[Job] = []
    
    var fullTimeJobs:[Job] = []
    var fullTimeFilteredJobs:[Job] = []
    
    var nearestTblController:UITableViewController!
    var nearestRefresh:UIRefreshControl!
    
    var internshipTblController:UITableViewController!
    var internshipRefresh:UIRefreshControl!
    
    var partTimeTblController:UITableViewController!
    var partTimeRefresh:UIRefreshControl!
    
    var fullTimeTblController:UITableViewController!
    var fullTimeRefresh:UIRefreshControl!
    
    var showProgress:Bool = true
    var currentFilter:JobFilter = JobFilter.Nearest
    
    var openedDetailTbl:UITableView! = nil
    var openedDetailIndex = -1
    var detailHeight:CGFloat = 0
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        setRefreshControl()
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        handleTabChange()
        
    }
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        if newPostsBtmLine != nil {
            newPostsBtmLine.layer.shadowColor = Helper.getAppGreyColor().CGColor
            newPostsBtmLine.layer.shadowOffset = CGSize(width: 0, height: 2)
            newPostsBtmLine.layer.shadowOpacity = 1
            newPostsBtmLine.layer.masksToBounds = false
            
        }
        
        if nearestTbl != nil {
            nearestTbl.tableFooterView = UIView()
        }
        
        if internshipTbl != nil {
            internshipTbl.tableFooterView = UIView()
        }
        
        if partTimeTbl != nil {
            partTimeTbl.tableFooterView = UIView()
        }
        
        if fullTimeTbl != nil {
            fullTimeTbl.tableFooterView = UIView()
        }
        
    }
    
    func setRefreshControl() {
        
        nearestTblController = UITableViewController()
        nearestTblController.tableView = nearestTbl
        
        nearestRefresh = UIRefreshControl()
        setRefreshHelper(nearestRefresh)
        nearestTblController.refreshControl = nearestRefresh
        
        
        internshipTblController = UITableViewController()
        internshipTblController.tableView = internshipTbl
        
        internshipRefresh = UIRefreshControl()
        setRefreshHelper(internshipRefresh)
        internshipTblController.refreshControl = internshipRefresh
        
        
        partTimeTblController = UITableViewController()
        partTimeTblController.tableView = partTimeTbl
        
        partTimeRefresh = UIRefreshControl()
        setRefreshHelper(partTimeRefresh)
        partTimeTblController.refreshControl = partTimeRefresh
        
        
        fullTimeTblController = UITableViewController()
        fullTimeTblController.tableView = fullTimeTbl
        
        fullTimeRefresh = UIRefreshControl()
        setRefreshHelper(fullTimeRefresh)
        fullTimeTblController.refreshControl = fullTimeRefresh

        
    }
    
    func setRefreshHelper(refresh:UIRefreshControl) {
        
        refresh.tintColor = Helper.getAppBlackColor()
        let attributes = [NSForegroundColorAttributeName:Helper.getAppBlackColor(), NSFontAttributeName:Helper.getNormalFont(10)]
        refresh.attributedTitle = NSMutableAttributedString(string: "Loading...", attributes: attributes)
        refresh.addTarget(self, action: "loadDataFromServer", forControlEvents: UIControlEvents.ValueChanged)
        
    }
    
    func loadDataFromServer() {
        
        nearestSrchTxt.text = ""
        internshipSrchTxt.text = ""
        partTimeSrchTxt.text = ""
        fullTimeSrchTxt.text = ""
        openedDetailTbl = nil
        openedDetailIndex = -1
        
        if showProgress {
            Helper.showCustomProgress(self)
        }else {
            
            switch currentFilter {
            case .Nearest:
                nearestRefresh.beginRefreshing()
            case .Internship:
                internshipRefresh.beginRefreshing()
            case .PartTime:
                partTimeRefresh.beginRefreshing()
            case .FullTime:
                fullTimeRefresh.beginRefreshing()
            }
            
        }
        
        WebServices.getSharedWebServices().getJobs(currentFilter.rawValue, successCallback: { (message:String, jobs:[Job]) -> Void in
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                
                switch self.currentFilter {
                case .Nearest:
                    self.nearestJobs = jobs
                    self.nearestFilteredJobs = jobs
                    self.nearestTbl.reloadData()
                    self.nearestRefresh.endRefreshing()
                    
                case .Internship:
                    self.internshipJobs = jobs
                    self.internshipFilteredJobs = jobs
                    self.internshipTbl.reloadData()
                    self.internshipRefresh.endRefreshing()
                    
                case .PartTime:
                    self.partTimeJobs = jobs
                    self.partTimeFitleredJobs = jobs
                    self.partTimeTbl.reloadData()
                    self.partTimeRefresh.endRefreshing()
                    
                case .FullTime:
                    self.fullTimeJobs = jobs
                    self.fullTimeFilteredJobs = jobs
                    self.fullTimeTbl.reloadData()
                    self.fullTimeRefresh.endRefreshing()
                    
                }
                
                if self.showProgress {
                    Helper.hideCustomProgress()
                }
                self.showProgress = false
                
            })
            
            }, failureCallback: { (message:String) -> Void in
                
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    if self.showProgress {
                        Helper.hideCustomProgress()
                        Helper.showAlert("", message: message)
                    }else {
                        switch self.currentFilter {
                        case .Nearest:
                            self.nearestRefresh.endRefreshing()
                        case .Internship:
                            self.internshipRefresh.endRefreshing()
                        case .PartTime:
                            self.partTimeRefresh.endRefreshing()
                        case .FullTime:
                            self.fullTimeRefresh.endRefreshing()
                        }
                    }
                    self.showProgress = false
                })
                
        })
        
    }
    
}


extension JobsViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var job:Job! = nil
        
        if tableView == nearestTbl {
            job = nearestFilteredJobs[indexPath.row]
        }else if tableView == internshipTbl {
            job = internshipFilteredJobs[indexPath.row]
        }else if tableView == partTimeTbl {
            job = partTimeFitleredJobs[indexPath.row]
        }else if tableView == fullTimeTbl {
            job = fullTimeFilteredJobs[indexPath.row]
        }
        if job == nil {
            job = Job()
        }
        
        let cell = tableView.dequeueReusableCellWithIdentifier("JobDetailCell")! as! JobDetailCell
        
        cell.titleCompLbl.text = "\(job.title) @ \(job.company)"
        cell.detailLbl.text = job.detail
        cell.websiteLbl.text = job.website
        cell.experienceLbl.text = job.experience
        
        cell.detailCallback  = { (detailHeight:CGFloat, isDetailOpened:Bool) in
            
            self.detailHeight = detailHeight
            
            var rows = [NSIndexPath]()
            if self.openedDetailIndex != -1 && tableView == self.openedDetailTbl {
                rows.append(NSIndexPath(forRow: self.openedDetailIndex, inSection: 0))
            }
            
            if isDetailOpened {
                self.openedDetailIndex = indexPath.row
                rows.append(NSIndexPath(forRow: indexPath.row, inSection: 0))
            }else {
                self.openedDetailIndex = -1
            }
            self.openedDetailTbl = tableView
            
            tableView .reloadRowsAtIndexPaths(rows, withRowAnimation: UITableViewRowAnimation.Automatic)
            
        }
        
        cell.applyCallback = {
            
            WebServices.getSharedWebServices().applyForJob(job.id, successCallback: { (message:String) -> Void in
                
                Helper.showAlert("", message: message)

                
                }, failureCallback: { (message:String) -> Void in
                    
                    Helper.showAlert("", message: message)
                    
            })
            
        }
        
        if indexPath.row == openedDetailIndex && tableView == openedDetailTbl {
            cell.detailLblHeight.constant = self.detailHeight - 40
            cell.detailViewHeight.constant = self.detailHeight
            cell.setDetailOpened(true)
        }else {
            cell.detailLblHeight.constant = 45
            cell.detailViewHeight.constant = 45
            cell.setDetailOpened(false)
        }
        
        return cell
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var count = 0
        if tableView == nearestTbl {
            count = nearestFilteredJobs.count
        }else if tableView == internshipTbl {
            count = internshipFilteredJobs.count
        }else if tableView == partTimeTbl {
            count = partTimeFitleredJobs.count
        }else if tableView == fullTimeTbl {
            count = fullTimeFilteredJobs.count
        }
        
        return count
        
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {

        var height:CGFloat = 45
        if indexPath.row == openedDetailIndex && tableView == openedDetailTbl {
            height = detailHeight
        }
        return 85 / 600 * UIScreen.mainScreen().bounds.size.height + height
        
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
//        var job:Job! = nil
//        
//        if tableView == nearestTbl {
//            job = nearestJobs[indexPath.row]
//        }else if tableView == internshipTbl {
//            job = internshipJobs[indexPath.row]
//        }else if tableView == partTimeTbl {
//            job = partTimeJobs[indexPath.row]
//        }else if tableView == fullTimeTbl {
//            job = fullTimeJobs[indexPath.row]
//        }
//        
//        if job != nil {
//        
//            openUrl(job.url)
//            
//        }
        
    }
    
    func openUrl(urlStr:String) {
        
        let url = NSURL(string: urlStr)!
        if !UIApplication.sharedApplication().canOpenURL(url) {
            Helper.showAlert("", message:Helper.genericErrorMsg)
            return
        }
        UIApplication.sharedApplication().openURL(url)
        
    }
    
    
}

extension JobsViewController : UIScrollViewDelegate {
    
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if scrollView == tabScrollView && !decelerate {
            handleTabChange()
        }
    }
    
    func scrollViewDidEndDecelerating(scrollView: UIScrollView) {
        if scrollView == tabScrollView {
            handleTabChange()
        }
    }
    
}

extension JobsViewController {
    
    func filterJobs(jobs:[Job], searchStr:String) -> [Job] {
        
        return jobs.filter({ (job:Job) -> Bool in
            
            return job.title.lowercaseString.containsString(searchStr.lowercaseString)
            
        })
        
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        openedDetailTbl = nil
        openedDetailIndex = -1
        let searchStr = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
        
        if textField == nearestSrchTxt {
            
            if searchStr.characters.count == 0 {
                nearestFilteredJobs = nearestJobs
            }else {
                nearestFilteredJobs = filterJobs(nearestJobs, searchStr: searchStr)
            }
            nearestTbl.reloadData()
            
        }else if textField == internshipSrchTxt {
            
            if searchStr.characters.count == 0 {
                internshipFilteredJobs = internshipJobs
            }else {
                internshipFilteredJobs = filterJobs(internshipJobs, searchStr: searchStr)
            }
            internshipTbl.reloadData()
            
        }else if textField == partTimeSrchTxt {
            
            if searchStr.characters.count == 0 {
                partTimeFitleredJobs = partTimeJobs
            }else {
                partTimeFitleredJobs = filterJobs(partTimeJobs, searchStr: searchStr)
            }
            partTimeTbl.reloadData()
            
        }else if textField == fullTimeSrchTxt {
            
            if searchStr.characters.count == 0 {
                fullTimeFilteredJobs = fullTimeJobs
            }else {
                fullTimeFilteredJobs = filterJobs(fullTimeJobs, searchStr: searchStr)
            }
            fullTimeTbl.reloadData()
            
        }
        
        return true
        
    }
    
}


extension JobsViewController {
    
    @IBAction func topLeftBtnAct(sender: UIButton) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func changeTabAct(sender:UIButton) {
        
        tabScrollView.contentOffset = CGPoint(x: CGFloat(sender.tag) * tabScrollView.frame.size.width, y: 0)
        handleTabChange()
        
    }
    
    func handleTabChange() {
        
        let tabNo = Int(tabScrollView.contentOffset.x / tabScrollView.frame.size.width)
        
        selectedTabIndicatorLeadingSpace.constant = CGFloat(tabNo) * selectedTabIndicatorView.frame.size.width
        
        switch tabNo {
        case 0:
            currentFilter = JobFilter.Nearest
        case 1:
            currentFilter = JobFilter.Internship
        case 2:
            currentFilter = JobFilter.PartTime
        case 3:
            currentFilter = JobFilter.FullTime
        default:
            break
        }
        
        showProgress = true
        loadDataFromServer()
        
    }
    
    @IBAction func postJobAct() {
    
        openUrl(Helper.postJobUrl)
        
    }
    
}




