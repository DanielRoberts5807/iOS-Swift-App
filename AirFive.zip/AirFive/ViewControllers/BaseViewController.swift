//
//  BaseViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 10/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class BaseViewController : UIViewController {
    
    var dissmissSwipeWidth:CGFloat = 30
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        if view != nil {
            setDelegate(view)
            setTouchForKeyboard()
        }
        
    }
    
    func setDelegate(view:UIView) {
        
        for subView in view.subviews {
            
            if subView.isKindOfClass(UITextField.self) {
                
                let textField = subView as! UITextField
                textField.delegate = self
                
            }else if subView.subviews.count > 0 {
                
                setDelegate(subView)
                
            }
            
        }
        
    }
    
    func setPlaceHolder(placeHolder:String, textField:UITextField, white:Bool = false) {
        
        var color = Helper.getAppGreyColor()
        if white {
            color = UIColor.whiteColor()
        }
        textField.attributedPlaceholder = NSAttributedString(string: placeHolder, attributes: [NSForegroundColorAttributeName : color])
        
    }
    
    func addBottomBorder(view:UIView) {
        
        let border = CALayer()
        border.backgroundColor = Helper.getAppGreyColor().CGColor
        border.frame = CGRect(x: 0, y: view.frame.size.height - 1, width: view.frame.size.width, height: 1)
        view.layer.addSublayer(border)
        
    }
    
    func applyShadow(view:UIView) {
        
        view.layer.borderColor = Helper.getAppBlackColor().CGColor
        view.layer.borderWidth = 1
        view.layer.cornerRadius = view.frame.size.height / 2
        view.layer.shadowColor = Helper.getAppBlackColor().CGColor
        view.layer.shadowOffset = CGSize(width: 2, height: 2)
        view.layer.shadowOpacity = 1
        view.layer.shadowRadius = 1
        
    }
    
}

extension BaseViewController : UIGestureRecognizerDelegate {

    func setTouchForKeyboard() {
        
        let tap = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        tap.delegate = self
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        
    }
    
    func dismissKeyboard() {
        
        view.endEditing(true)
        
    }
    
    func gestureRecognizer(gestureRecognizer: UIGestureRecognizer, shouldReceiveTouch touch: UITouch) -> Bool {
        
        return true
        
    }
    
    func addDissmissWithSwipeGesture() {
        
        let swipeGesture = UISwipeGestureRecognizer(target: self, action: "dissmissSwipe:")
        swipeGesture.direction = UISwipeGestureRecognizerDirection.Right
        view.addGestureRecognizer(swipeGesture)
        
    }
    
    func dissmissSwipe(recognizer:UISwipeGestureRecognizer) {
        
        let location = recognizer.locationInView(view)
        if location.x < dissmissSwipeWidth {
            dismissViewControllerAnimated(true, completion: nil)
        }
        
    }
    
}

extension BaseViewController {
    
    override func viewWillAppear(animated: Bool) {
        
        super.viewWillAppear(animated)
        registerForKeyboardNotifications()
        
    }
    
    override func viewWillDisappear(animated: Bool) {
        
        super.viewWillDisappear(animated)
        unregisterForKeyboardNotfications()
        
    }

    func registerForKeyboardNotifications() {
    
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillShow:", name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "keyboardWillHide:", name: UIKeyboardWillHideNotification, object: nil)
        
    }
    
    func unregisterForKeyboardNotfications() {
        
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillShowNotification, object: nil)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillHideNotification, object: nil)
        
    }
    
    func keyboardWillShow(notification:NSNotification) {
        
    }
    
    func keyboardWillHide(notification:NSNotification) {
        
    }
    
    
}

extension BaseViewController : UITextFieldDelegate {
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
        
    }
    
}
