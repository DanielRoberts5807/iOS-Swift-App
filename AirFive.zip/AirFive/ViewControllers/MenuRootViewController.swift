//
//  MenuRootViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 18/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class MenuRootViewController : MFSideMenuContainerViewController {
    
    override func awakeFromNib() {
        
        leftMenuWidth = UIScreen.mainScreen().bounds.size.width * 0.75
        if let controller = self.storyboard?.instantiateViewControllerWithIdentifier("DashBoardViewController") {
            centerViewController = controller
        }
        if let controller = self.storyboard?.instantiateViewControllerWithIdentifier("MenuViewController") {
            leftMenuViewController = controller
        }
        super.awakeFromNib()
        
    }
    
    
}