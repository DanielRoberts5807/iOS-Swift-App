//
//  ContactsViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 14/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class ContactsViewController: BaseViewController {
    
    @IBOutlet weak var contactsList: UICollectionView!
    @IBOutlet weak var contactsListWidth: NSLayoutConstraint!
    @IBOutlet weak var noContactsLbl: UILabel!
    
    @IBOutlet weak var menuIcon: UIImageView!
    @IBOutlet weak var crossIcon: UIImageView!
    
    var showMenu = true
    
    var contacts:[Contact] = []
    var dataLoadedFromServer = false
    var cellWidth:CGFloat = 0, cellMargin:CGFloat = 0
    var notContactsAlert:CustomIOSAlertView! = nil
    
    var dashboardCallback:(()->())! = nil
    var dashboardViewController:DashBoardViewController! = nil
    
    var noContactsPopup:KLCPopup! = nil
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        let screenWidth = UIScreen.mainScreen().bounds.size.width
        contactsListWidth.constant = UIScreen.mainScreen().bounds.size.width * 0.97
        cellMargin = screenWidth * 0.015
        cellWidth = (UIScreen.mainScreen().bounds.size.width * 0.97 / 3) - (2 * cellMargin)
        
        menuIcon.hidden = !showMenu
        crossIcon.hidden = showMenu
        
    }

    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        if !dataLoadedFromServer {
            loadDataFromServer()
            dataLoadedFromServer = true
        }
        
    }
    
    func loadDataFromServer() {
        
        WebServices.getSharedWebServices().getContacts({ (message:String, contacts:[Contact]) -> Void in
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.contacts = contacts
                self.contactsList.reloadData()
                
                self.contactsList.hidden = self.contacts.count == 0
                self.noContactsLbl.hidden = self.contacts.count > 0
                
                if self.contacts.count == 0 {
                    self.showNoContactsPopup()
                }
            
            })
            
        }, failureCallback: { (message:String) -> Void in
                
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                Helper.showAlert("", message: message)
                
            })
                
        })
        
    }
    
    func showNoContactsAlert() {
        
        let text = "Right now, you don't have any contacts, schucks! Try inviting people out for coffee or creating an event. Just like Pokemon, you gotta catch 'em all"
        
        notContactsAlert = CustomIOSAlertView()
        let container = UIView(frame: CGRect(x: 0, y: 0, width: 250, height: 120))
        let messageLbl = UITextView(frame: CGRect(x: 10, y: 10, width: container.frame.size.width - 20, height: container.frame.size.height - 20))
        messageLbl.backgroundColor = UIColor.clearColor()
        messageLbl.editable = false
        messageLbl.scrollEnabled = false
        let atrStr = NSMutableAttributedString(string: text, attributes: [NSForegroundColorAttributeName: Helper.getAppBlackColor(), NSFontAttributeName: Helper.getNormalFont(14)])
        
        var range = (text as NSString).rangeOfString("inviting people out for coffee")
        atrStr.addAttributes([NSLinkAttributeName: "invite",  NSFontAttributeName: Helper.getBoldFont(14)], range: range)
        
        range = (text as NSString).rangeOfString("creating an event")
        atrStr.addAttributes([NSLinkAttributeName: "event",  NSFontAttributeName: Helper.getBoldFont(14)], range: range)
        
        messageLbl.attributedText = atrStr
        messageLbl.delegate = self
        messageLbl.linkTextAttributes = [NSForegroundColorAttributeName: Helper.getAppBlackColor()]
        messageLbl.textAlignment = NSTextAlignment.Center
        
        container.addSubview(messageLbl)
        
        notContactsAlert.containerView = container
        notContactsAlert.show()
    }
    
}

extension ContactsViewController : UITextViewDelegate {
    func textView(textView: UITextView, shouldInteractWithURL URL: NSURL, inRange characterRange: NSRange) -> Bool {
        
        if URL.absoluteString == "invite" {
            
            let alumniAroundViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("AlumniAroundViewController") as! AlumniAroundViewController
            presentViewController(alumniAroundViewController, animated: true, completion: nil)
            
        }else {
            
            if showMenu {
                let menuController = self.menuContainerViewController.leftMenuViewController as! MenuViewController
                menuController.openMenuItemWithTag(6)
            }else {
                dismissViewControllerAnimated(true, completion: nil)
                if dashboardViewController != nil {
                    Helper.saveValue("false", forKey: "shouldStopLoadData")
                    dashboardViewController.shoudlLoadDataFromServer = false
                }
                if dashboardCallback != nil {
                    dashboardCallback()
                }
            }
            
        }
        if notContactsAlert != nil {
            notContactsAlert.close()
        }
        return false
    }
}


extension ContactsViewController : UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return contacts.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("ContactCell", forIndexPath: indexPath) as! ContactCell
        let contact = contacts[indexPath.row]
        cell.profileImg.setImageWithURL(NSURL(string: contact.profileImage)!, placeholderImage: UIImage(named:"profileImgPlaceholder"))
        cell.nameLbl.text = contact.name
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAtIndex section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: cellMargin * 2, left: cellMargin, bottom: 0, right: cellMargin)
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        return CGSize(width: cellWidth, height: cellWidth)
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        
        let contactDetailViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("ContactDetailViewController") as! ContactDetailViewController
        contactDetailViewController.contact = contacts[indexPath.row]
        presentViewController(contactDetailViewController, animated: true, completion: nil)
        
    }
    
}

extension ContactsViewController {
    
    func openAlumniViewController() {
    
        let alumniAroundViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("AlumniAroundViewController") as! AlumniAroundViewController
        presentViewController(alumniAroundViewController, animated: true, completion: nil)
        
    }
    
    func openAddEventViewController() {
        
        if showMenu {
            let menuController = self.menuContainerViewController.leftMenuViewController as! MenuViewController
            menuController.openMenuItemWithTag(6)
        }else {
            dismissViewControllerAnimated(true, completion: nil)
            if dashboardViewController != nil {
                Helper.saveValue("false", forKey: "shouldStopLoadData")
                dashboardViewController.shoudlLoadDataFromServer = false
            }
            if dashboardCallback != nil {
                dashboardCallback()
            }
        }
        
    }

    func showNoContactsPopup() {
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapDissmiss:")
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.4)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.4))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        let tapGestureStop = UITapGestureRecognizer(target: self, action: "tapDissmissStop:")
        innerContainer.addGestureRecognizer(tapGestureStop)
        
        tmp = innerContainer.frame.size.height * 0.23
        let titleLbl = UILabel(frame: CGRect(x: 10, y: 20, width: innerContainer.frame.size.width - 20, height: tmp))
        titleLbl.textColor = Helper.getAppBlackColor()
        titleLbl.font = Helper.getBoldFont(16)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.numberOfLines = 0
        titleLbl.text = "Right now, you don't have any contacts, schucks! Try"
        
        innerContainer.addSubview(titleLbl)
        
        tmp = innerContainer.frame.size.height * 0.12
        let inviteBtn = UIBlockButton(frame: CGRect(x: titleLbl.frame.origin.x, y: (titleLbl.frame.origin.y + titleLbl.frame.size.height + 2), width: titleLbl.frame.size.width, height: tmp))
        inviteBtn.setTitleColor(Helper.getAppGreenColor(), forState: UIControlState.Normal)
        inviteBtn.setTitle(("inviting people out for coffee"), forState: UIControlState.Normal)
        inviteBtn.titleLabel?.font = Helper.getBoldFont(16)
        inviteBtn.titleLabel?.textAlignment = NSTextAlignment.Center
        
        innerContainer.addSubview(inviteBtn)
        
        let orLbl = UILabel(frame: CGRect(x: titleLbl.frame.origin.x, y: (inviteBtn.frame.origin.y + inviteBtn.frame.size.height + 2), width: titleLbl.frame.size.width, height: tmp))
        orLbl.textColor = Helper.getAppBlackColor()
        orLbl.font = Helper.getBoldFont(16)
        orLbl.textAlignment = NSTextAlignment.Center
        orLbl.text = "or"
        
        innerContainer.addSubview(orLbl)
        
        let eventBtn = UIBlockButton(frame: CGRect(x: titleLbl.frame.origin.x, y: (orLbl.frame.origin.y + orLbl.frame.size.height + 2), width: titleLbl.frame.size.width, height: tmp))
        eventBtn.setTitleColor(Helper.getAppGreenColor(), forState: UIControlState.Normal)
        eventBtn.setTitle(("creating an event"), forState: UIControlState.Normal)
        eventBtn.titleLabel?.font = Helper.getBoldFont(16)
        eventBtn.titleLabel?.textAlignment = NSTextAlignment.Center
        
        innerContainer.addSubview(eventBtn)
        
        tmp = innerContainer.frame.size.height * 0.23
        let bottomLbl = UILabel(frame: CGRect(x: titleLbl.frame.origin.x, y: (eventBtn.frame.origin.y + eventBtn.frame.size.height + 2), width: titleLbl.frame.size.width, height: tmp))
        bottomLbl.textColor = Helper.getAppBlackColor()
        bottomLbl.font = Helper.getBoldFont(16)
        bottomLbl.textAlignment = NSTextAlignment.Center
        bottomLbl.numberOfLines = 0
        bottomLbl.text = "Just like Pokemon, you gotta catch 'em all"
        
        innerContainer.addSubview(bottomLbl)
        
        container.addSubview(innerContainer)
        
        tmp = innerContainer.frame.origin.y + innerContainer.frame.size.height
        let bottomContainer = UIView(frame: CGRect(x: innerContainer.frame.origin.x, y: tmp, width: innerContainer.frame.size.width, height: container.frame.size.height - tmp))
        
        tmp = bottomContainer.frame.size.width * 0.2
        let cancelBtn = UIBlockButton(frame: CGRect(x: ((bottomContainer.frame.size.width - tmp) / 2), y: ((bottomContainer.frame.size.height - tmp) / 2), width: tmp, height: tmp))
        cancelBtn.setBackgroundImage(UIImage(named: "notificationClose"), forState: UIControlState.Normal)
        
        
        bottomContainer.addSubview(cancelBtn)
        
        container.addSubview(bottomContainer)
        
        
        noContactsPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: false, dismissOnContentTouch: false)
        noContactsPopup.dimmedMaskAlpha = 0.85
        
        inviteBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.noContactsPopup.dismissPresentingPopup()
            self.openAlumniViewController()
            
        }
        
        eventBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.noContactsPopup.dismissPresentingPopup()
            self.openAddEventViewController()
            
        }
        
        cancelBtn.callback = {(button:UIBlockButton) -> Void in
            self.noContactsPopup.dismissPresentingPopup()
        }
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        noContactsPopup.showWithLayout(layout)
        
    }
    
    func tapDissmiss(tap:UITapGestureRecognizer) {
        self.noContactsPopup.dismissPresentingPopup()
    }
    
    func tapDissmissStop(tap:UITapGestureRecognizer) {
    }
    
}

extension ContactsViewController {
    
    @IBAction func topLeftBtnAct(sender: UIButton) {
        if showMenu {
            menuContainerViewController.toggleLeftSideMenuCompletion(nil)
        }else {
            dismissViewControllerAnimated(true, completion: nil)
        }
    }
    
}


