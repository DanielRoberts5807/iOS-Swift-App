//
//  EventLocationViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 05/05/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit
import GoogleMaps

class EventLocationViewController: BaseViewController {

    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var mapView: GMSMapView!
    var event:Event! = nil
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        loadData()
        
    }
    
    func loadData() {
    
        if event != nil {
            
            titleLbl.text = event.title
            
            let camera = GMSCameraPosition.cameraWithLatitude(event.latitude, longitude:event.longitude, zoom:16)
            
            let marker = GMSMarker()
            marker.position = camera.target
            marker.snippet = event.title
            marker.appearAnimation = kGMSMarkerAnimationPop
            marker.map = mapView
            
            mapView.camera = camera
            
        }
        
    }
    
}

extension EventLocationViewController {

    @IBAction func backAct(sender: UIButton) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
}
