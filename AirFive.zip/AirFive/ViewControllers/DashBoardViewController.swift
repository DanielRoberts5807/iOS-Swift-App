//
//  DashBoardViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 12/03/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit
import CoreLocation
import EventKit

class DashBoardViewController : BaseViewController {
    
    @IBOutlet weak var findAluminiBtn: UIButton!
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var schoolImg: UIImageView!
    @IBOutlet weak var schoolLbl: UILabel!
    @IBOutlet weak var secondSchoolImg: UIImageView!
    @IBOutlet weak var secondSchoolLbl: UILabel!
    
    @IBOutlet weak var profileImg: UIImageView!
    @IBOutlet weak var coverImg: UIImageView!
    
    @IBOutlet weak var activityCountLbl: UILabel!
    @IBOutlet weak var eventsCountLbl: UILabel!
    
    @IBOutlet weak var containerScrollView: UIScrollView!
    @IBOutlet weak var container: UIView!
    @IBOutlet weak var likesView: UIView!
    @IBOutlet weak var likesLbl: UILabel!
    
    @IBOutlet weak var coverBtn: UIButton!
    @IBOutlet weak var profileBtn: UIButton!
    @IBOutlet weak var nameBtn: UIButton!
    @IBOutlet weak var titleBtn: UIButton!
    @IBOutlet weak var schoolBtn: UIButton!
    @IBOutlet weak var secondSchoolBtn: UIButton!
    
    @IBOutlet weak var personalStmtBtn: UIButton!
    @IBOutlet weak var personalStmtLbl: UILabel!
    
    @IBOutlet weak var enterEmailPhoneBtn: UIButton!
    @IBOutlet weak var changeVisibilityView: UIView!
    
    @IBOutlet weak var visibilityBg: UIView!
    @IBOutlet weak var visibilityTickImg: UIImageView!
    
    
    
    var dataLoadedFromServer = false
    
    var containerScrollViewInitY: CGFloat = 0, fontMaxDelta:CGFloat = 10
    var nameInitFont:CGFloat = 0, schoolInitFont:CGFloat = 0, secondSchoolInitFont:CGFloat = 0
    var shoudlLoadDataFromServer = true
    var shouldGetUserFromServer = false
    var liveDataLoaded = false
    
    var phoneEntryPopup:KLCPopup! = nil
    var phoneTxt:UITextField! = nil
    
    var personalStmtEntryPopup:KLCPopup! = nil
    var personalStmtTxt:UITextView! = nil
    var personalStmtTxtBorder:UIView! = nil
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        containerScrollViewInitY = containerScrollView.contentOffset.y
        nameInitFont = nameLbl.font.pointSize
        schoolInitFont = schoolLbl.font.pointSize
        secondSchoolInitFont = secondSchoolLbl.font.pointSize
        
        Helper.setTourShown()
        
        if Helper.getValueForKey("shouldGetUserFromServer") != nil {
            Helper.saveValue(nil, forKey: "shouldGetUserFromServer")
            shouldGetUserFromServer = true
        }
        
        if !shouldGetUserFromServer {
            if User.getSharedUser().name.characters.count == 0 {
                User.getSharedUser().loadLocal()
            }
            setDashboardData()
        }
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        
        if shouldGetUserFromServer {
            loadDataFromServer()
            shouldGetUserFromServer = false
        }else {
            if User.getSharedUser().name.characters.count == 0 {
                User.getSharedUser().loadLocal()
            }
            setUserData()
        }
        
        adjustViews()
        sendLocation()
//        getCalendarAccess()
        
        if !liveDataLoaded || true {
            loadLiveDataFromServer()
            liveDataLoaded = true
        }
        
    }
    
    func adjustViews() {
        
        if findAluminiBtn != nil {
            findAluminiBtn.layer.cornerRadius = findAluminiBtn.frame.size.height / 2
        }
        
        if profileImg != nil {
            profileImg.clipsToBounds = true
            profileImg.layer.cornerRadius = profileImg.frame.size.height / 2
        }
        
        if activityCountLbl != nil {
            activityCountLbl.clipsToBounds = true
            activityCountLbl.layer.cornerRadius = activityCountLbl.frame.size.height / 2
        }
        
        if eventsCountLbl != nil {
            eventsCountLbl.clipsToBounds = true
            eventsCountLbl.layer.cornerRadius = eventsCountLbl.frame.size.height / 2
        }
        
        if visibilityBg != nil {
            visibilityBg.clipsToBounds = true
            visibilityBg.layer.borderColor = Helper.getAppGreenColor().CGColor
            visibilityBg.layer.borderWidth = 1
            visibilityBg.layer.cornerRadius = visibilityBg.frame.size.height / 2
        }
        
        if enterEmailPhoneBtn != nil {
            enterEmailPhoneBtn.clipsToBounds = true
            enterEmailPhoneBtn.layer.borderColor = Helper.getAppGreenColor().CGColor
            enterEmailPhoneBtn.layer.borderWidth = 1
            enterEmailPhoneBtn.layer.cornerRadius = enterEmailPhoneBtn.frame.size.height / 2
        }
        
    }
    
    func sendLocation() {
        LocationLoader.getSharedLocationLoader().getLocation { (location:CLLocation, address:String) -> () in
            WebServices.getSharedWebServices().reportLocation(location)
            let locationStr = String(location.coordinate.latitude) + " " + String(location.coordinate.longitude)
            Helper.saveValue(locationStr, forKey: "userLocation")
        }
    }
    
    func loadLiveDataFromServer() {
    
        WebServices.getSharedWebServices().getLiveData({ (likes:Int, contentCount:Int, eventCount:Int, coffeeCount:Int, biteCount:Int, message:String) -> Void in
            
            self.likesLbl.text = "\(likes)"
            self.likesView.hidden = likes == 0
            let user = User.getSharedUser()
            user.setActivityCounts(contentCount, eventCount: eventCount, coffeeCount: coffeeCount, biteCount: biteCount)
            let activityCount = coffeeCount + contentCount + eventCount
            self.activityCountLbl.hidden = activityCount > 0 ? false : true
            
            }, failureCallback: { (message:String) -> Void in
                
                print(message)
                
        })
        
    }
    
    func loadDataFromServer(withProgress:Bool = true) {
        
        WebServices.getSharedWebServices().getUser({ (message:String) -> Void in
            
           self.setUserData()
            
        }, failureCallback: { (message:String) -> Void in
            
            if withProgress {
                Helper.showAlert("", message: message)
            }
            
        })
        
    }
    
    func setDashboardData() {
        
        let user = User.getSharedUser()
        
        nameLbl.text = user.name
        setUserTitleNCompany(12)
        schoolLbl.text = user.school
        schoolImg.hidden = user.school.characters.count == 0
        
        secondSchoolLbl.text = user.secondSchool
        secondSchoolImg.hidden = user.secondSchool.characters.count == 0
        secondSchoolBtn.hidden = user.secondSchool.characters.count == 0
        
        profileImg.image = UIImage(named:"profileImgPlaceholder")
        if user.profileImgLocal.characters.count > 0 {
            if let image = UIImage(contentsOfFile: user.profileImgLocal) {
                profileImg.image = image
            }
        }else {
            profileImg.setImageWithURL(NSURL(string: user.profileImgUrl)!, placeholderImage: UIImage(named:"profileImgPlaceholder"))
        }
        
        coverImg.image = UIImage(named:"backgroundImg")
        coverBtn.hidden = false
        if user.coverImgLocal.characters.count > 0 {
            if let image = UIImage(contentsOfFile: user.coverImgLocal) {
                coverImg.image = image
                coverBtn.hidden = true
            }
        }else if user.coverImgUrl.characters.count > 0 {
            coverImg.setImageWithURL(NSURL(string: user.coverImgUrl)!, placeholderImage: UIImage(named:"backgroundImg"))
            coverBtn.hidden = true
        }
        
        let activityCount = user.activityCoffeeCount + user.activityContentCount + user.activityEventCount
        activityCountLbl.hidden = activityCount > 0 ? false : true
        eventsCountLbl.hidden = user.eventsCount > 0 ? false : true
        
        setEmailPhonEntryViews()
        setPersonalStmt()
        
    }
    
    func setUserData() {
    
        let user = User.getSharedUser()
        let menuController = (menuContainerViewController.leftMenuViewController as! MenuViewController)
        
        nameLbl.text = user.name
        setUserTitleNCompany(12)
        schoolLbl.text = user.school
        schoolImg.hidden = user.school.characters.count == 0
        
        secondSchoolLbl.text = user.secondSchool
        secondSchoolImg.hidden = user.secondSchool.characters.count == 0
        secondSchoolBtn.hidden = user.secondSchool.characters.count == 0
        
        profileImg.image = UIImage(named:"profileImgPlaceholder")
        if user.profileImgLocal.characters.count > 0 {
            
            if let image = UIImage(contentsOfFile: user.profileImgLocal) {
                profileImg.image = image
            }
            
        }else if user.profileImgUrl.characters.count > 0 {
            profileImg.setImageWithURL(NSURL(string: user.profileImgUrl)!, placeholderImage: UIImage(named:"profileImgPlaceholder"))
        }
        
        
        coverImg.image = UIImage(named:"backgroundImg")
        menuController.coverImg.image = UIImage(named:"backgroundImg")
        coverBtn.hidden = false
        
        if user.coverImgLocal.characters.count > 0 {
            if let image = UIImage(contentsOfFile: user.coverImgLocal) {
                coverImg.image = image
                menuController.coverImg.image = image
                coverBtn.hidden = true
            }
        }else if  user.coverImgUrl.characters.count > 0 {
            coverImg.setImageWithURL(NSURL(string: user.coverImgUrl)!, placeholderImage: UIImage(named:"backgroundImg"))
            menuController.coverImg.setImageWithURL(NSURL(string: user.coverImgUrl)!, placeholderImage: UIImage(named:"backgroundImg"))
            coverBtn.hidden = true
        }
        
        let activityCount = user.activityCoffeeCount + user.activityContentCount + user.activityEventCount
        activityCountLbl.hidden = activityCount > 0 ? false : true
        eventsCountLbl.hidden = user.eventsCount > 0 ? false : true
        
        setEmailPhonEntryViews()
        setPersonalStmt()
        
        menuController.nameLbl.text = user.name
        menuController.schoolLbl.text = user.school
        menuController.schoolImg.hidden = user.school.characters.count == 0
        
        menuController.eventsCountLbl.text = String(user.eventsCount)
        menuController.eventsCountLbl.hidden = user.eventsCount > 0 ? false : true
        
    }
    
    func setUserTitleNCompany(fontSize:CGFloat) {
        let user = User.getSharedUser()
        var titleStr = ""
        if user.title.characters.count > 0 || user.company.characters.count > 0 {
            titleStr = user.title + " @ " + user.company
        }else {
            titleStr = "Enter Position @ Company"
        }
        let attributedStr = NSMutableAttributedString(string: titleStr, attributes: [NSFontAttributeName: Helper.getNormalFont(fontSize)])
        let range = (titleStr as NSString).rangeOfString("@")
        attributedStr.addAttributes([NSFontAttributeName: Helper.getNormalFont(fontSize - 4)], range: range)
        titleLbl.attributedText = attributedStr
    }
    
    func getCalendarAccess() {
    
        if let calendarAccessGranted = Helper.getValueForKey("calendarAccessGranted") {
            return
        }
        
        let store = EKEventStore()
        store.requestAccessToEntityType(.Event) {(granted, error) in
            Helper.saveValue(granted, forKey: "calendarAccessGranted")
        }
            
    }
    
    func setEmailPhonEntryViews() {
        
        let user = User.getSharedUser()
        let showPhoneEnter = user.email.characters.count == 0 || user.phone.characters.count == 0
        enterEmailPhoneBtn.hidden = !showPhoneEnter
        changeVisibilityView.hidden = showPhoneEnter
        visibilityTickImg.hidden = !user.emailPreference
        
    }
    
    func setPersonalStmt() {
    
        let user = User.getSharedUser()
        personalStmtLbl.text = "\"\(user.personalStmt)\""
        personalStmtLbl.hidden = user.personalStmt.characters.count == 0
        personalStmtBtn.hidden = user.personalStmt.characters.count != 0
        
    }
    
}

extension DashBoardViewController : UIScrollViewDelegate {
    
    func scrollViewDidScroll(scrollView: UIScrollView) {
        
    }
}

extension DashBoardViewController {

    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        if (phoneTxt != nil && textField == phoneTxt) {
            let newString = (textField.text! as NSString).stringByReplacingCharactersInRange(range, withString: string)
            let components = newString.componentsSeparatedByCharactersInSet(NSCharacterSet.decimalDigitCharacterSet().invertedSet)
            
            let decimalString = components.joinWithSeparator("") as NSString
            let length = decimalString.length
            let hasLeadingOne = length > 0 && decimalString.characterAtIndex(0) == (1 as unichar)
            
            if length == 0 || (length > 10 && !hasLeadingOne) || length > 11
            {
                let newLength = (textField.text! as NSString).length + (string as NSString).length - range.length as Int
                
                return (newLength > 10) ? false : Int(string) != nil
            }
            var index = 0 as Int
            let formattedString = NSMutableString()
            
            if hasLeadingOne
            {
                formattedString.appendString("1 ")
                index += 1
            }
            if (length - index) > 3
            {
                let areaCode = decimalString.substringWithRange(NSMakeRange(index, 3))
                formattedString.appendFormat("(%@) ", areaCode)
                index += 3
            }
            if length - index > 3
            {
                let prefix = decimalString.substringWithRange(NSMakeRange(index, 3))
                formattedString.appendFormat("%@-", prefix)
                index += 3
            }
            
            let remainder = decimalString.substringFromIndex(index)
            formattedString.appendString(remainder)
            textField.text = formattedString as String
            return false
        }
        else
        {
            return true
        }
    }
    
}

extension DashBoardViewController : UITextViewDelegate {
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        
        if textView.tag == 0 {
            textView.text = ""
            textView.tag = 1
            textView.textColor = Helper.getAppBlackColor()
        }
        return true
    }
    
    func textViewShouldEndEditing(textView: UITextView) -> Bool {
        if textView.text.characters.count ==  0 {
            textView.text = "Enter personal statement"
            textView.textColor = Helper.getAppGreenColor()
            textView.tag = 0
        }
        return true
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textViewDidChange(textView: UITextView) {
        
        let constraintSize = CGSize(width: (textView.frame.size.width - 5), height: CGFloat(MAXFLOAT))
        let textRect = (textView.text as NSString).boundingRectWithSize(constraintSize, options: NSStringDrawingOptions.UsesLineFragmentOrigin, attributes: [NSFontAttributeName: textView.font!], context: nil)
        
        var height = textRect.size.height + 10
        height = height < 25 ? 25 : height > 60 ? 60 : height
        
        textView.frame.size.height = height
        if personalStmtTxtBorder != nil {
            personalStmtTxtBorder.frame.origin.y = textView.frame.origin.y + textView.frame.size.height
        }
        
    }
}

extension DashBoardViewController {

    @IBAction func openMenuAct(sender: UIButton) {
        menuContainerViewController.toggleLeftSideMenuCompletion(nil)
    }
    
    @IBAction func openMenuItemAct(sender: UIButton) {
        
        var viewController:UIViewController! = nil
        switch sender.tag {
        case 2:
            let contactsViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("ContactsViewController") as! ContactsViewController
            contactsViewController.showMenu = false
            contactsViewController.dashboardViewController = self
            contactsViewController.dashboardCallback = {() -> () in
                
                let delayTime = dispatch_time(DISPATCH_TIME_NOW, Int64(0.3 * Double(NSEC_PER_SEC)))
                dispatch_after(delayTime, dispatch_get_main_queue()) {
                    self.shoudlLoadDataFromServer = true
                    let menuController = self.menuContainerViewController.leftMenuViewController as! MenuViewController
                    menuController.openMenuItemWithTag(6)
                }
            }
            viewController = contactsViewController
        case 3:
            let feedsViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("FeedsViewController") as! FeedsViewController
            feedsViewController.showMenu = false
            viewController = feedsViewController
            
        case 4:
            let eventsViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("EventsViewController") as! EventsViewController
            eventsViewController.showMenu = false
            viewController = eventsViewController
            
        case 5:
            let editUserViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("EditUserViewController") as! EditUserViewController
            editUserViewController.showMenu = false
            viewController = editUserViewController
            
        default:
          break
        }
        if viewController != nil {
            presentViewController(viewController, animated: true, completion: nil)
        }
        
    }
    
    @IBAction func enterPersonalStmtAct() {
        showPersonalStmtEntryPopup()
    }
    
    @IBAction func enterEmailPhoneAct() {
        showPhoneEntryPopup()
    }
    
    @IBAction func changeVisibilityAct() {
        
        let visibility = visibilityTickImg.hidden ? "true" : "false"

        var parameters:[String:AnyObject] = [String:AnyObject]()
        parameters["emailPreference"] = visibility
        parameters["phonePreference"] = visibility

        WebServices.getSharedWebServices().setUser(parameters, successCallback: { (message:String) -> Void in
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                
                self.visibilityTickImg.hidden = !self.visibilityTickImg.hidden
                
            })
            
            }, failureCallback: { (message:String) -> Void in
                
                dispatch_async(dispatch_get_main_queue(), { () -> Void in
                    
                    Helper.showAlert("", message: message)
                    self.visibilityTickImg.hidden = !User.getSharedUser().emailPreference
                    
                })
                
        })
        
    }
    
    @IBAction func changeCoverAct() {
        openEditScreen()
    }
    
    @IBAction func changeProfileAct() {
        if User.getSharedUser().profileImgUrl.characters.count == 0 {
            openEditScreen()
        }
    }
    
    @IBAction func changeTitleAct() {
        if User.getSharedUser().title.characters.count == 0 && User.getSharedUser().company.characters.count == 0 {
            openEditScreen()
        }
    }
    
    func openEditScreen() {
    
        let editUserViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("EditUserViewController") as! EditUserViewController
        editUserViewController.showMenu = false
        presentViewController(editUserViewController, animated: true, completion: nil)
        
        
    }
    
    func showPhoneEntryPopup() {
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapDissmiss:")
        tapGesture.delegate = self
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.5))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        let tapGestureStop = UITapGestureRecognizer(target: self, action: "tapDissmissStop:")
        tapGestureStop.delegate = self
        innerContainer.addGestureRecognizer(tapGestureStop)
        
        let titleLbl = UILabel(frame: CGRect(x: 20, y: 30, width: innerContainer.frame.size.width - 40, height: 25))
        titleLbl.textColor = Helper.getAppBlackColor()
        titleLbl.font = Helper.getBoldFont(22)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.numberOfLines = 0
        titleLbl.text = "Your email we have is"
        
        innerContainer.addSubview(titleLbl)
        
        tmp = innerContainer.frame.size.height * 0.08
        
        let emailTxt = UITextField(frame: CGRect(x: titleLbl.frame.origin.x, y: (titleLbl.frame.origin.y + titleLbl.frame.size.height + 10), width: titleLbl.frame.size.width, height: 25))
        emailTxt.font = Helper.getNormalFont()
        emailTxt.textColor = Helper.getAppBlackColor()
        
        emailTxt.text = User.getSharedUser().email
        
        
        phoneTxt = UITextField(frame: CGRect(x: titleLbl.frame.origin.x, y: (emailTxt.frame.origin.y + emailTxt.frame.size.height + 10), width: titleLbl.frame.size.width, height: 25))
        phoneTxt.font = Helper.getNormalFont()
        phoneTxt.textColor = Helper.getAppBlackColor()
        phoneTxt.keyboardType = UIKeyboardType.NumberPad
        phoneTxt.delegate = self
        
        let barButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.Done, target: phoneTxt, action: "resignFirstResponder")
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: UIScreen.mainScreen().bounds.size.width, height: 44))
        toolbar.items = [barButton]
        
        phoneTxt.inputAccessoryView = toolbar
        
        tmp = innerContainer.frame.size.width * 0.25
        let remainingHeight = innerContainer.frame.size.height - (phoneTxt.frame.origin.y + phoneTxt.frame.size.height)

        let acceptBtn = UIBlockButton(frame: CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        acceptBtn.center = CGPoint(x: innerContainer.frame.size.width / 2, y: (phoneTxt.frame.origin.y + phoneTxt.frame.size.height) + remainingHeight / 2)
        
        tmp = innerContainer.frame.size.width * 0.35
        let handImg = UIImageView(frame:CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        handImg.image = UIImage(named:"hand.gif")
        
        handImg.center = acceptBtn.center
        innerContainer.addSubview(handImg)
        
        innerContainer.addSubview(acceptBtn)
        
        innerContainer.addSubview(emailTxt)
        innerContainer.addSubview(phoneTxt)
        
        addBottomBorder(emailTxt)
        
        addBottomBorder(phoneTxt)
        phoneTxt.attributedPlaceholder = NSAttributedString(string: "Enter phone number", attributes: [NSForegroundColorAttributeName : Helper.getAppGreenColor()])
        phoneTxt.returnKeyType = UIReturnKeyType.Done
        
        container.addSubview(innerContainer)
        
        phoneEntryPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        phoneEntryPopup.dimmedMaskAlpha = 0.85
        
        
        acceptBtn.callback = {(button:UIBlockButton) -> Void in
            
            if self.phoneTxt.text?.characters.count == 0 {
                Helper.showAlert("", message: "Please enter a phone number")
                return
            }
            
            let parameters = ["phone_number":self.phoneTxt.text!]
            WebServices.getSharedWebServices().setUser(parameters, successCallback: { (message:String) -> Void in
                
                self.phoneEntryPopup.dismissPresentingPopup()
                self.setEmailPhonEntryViews()
                
                }, failureCallback: { (message:String) -> Void in
                    
                    self.phoneEntryPopup.dismissPresentingPopup()
                    Helper.showAlert("", message: message)
                    
            })
            
        }
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        phoneEntryPopup.showWithLayout(layout)
        
    }
    
    func showPersonalStmtEntryPopup() {
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapDissmiss:")
        tapGesture.delegate = self
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.5))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        let tapGestureStop = UITapGestureRecognizer(target: self, action: "tapDissmissStop:")
        tapGestureStop.delegate = self
        innerContainer.addGestureRecognizer(tapGestureStop)
        
        tmp = innerContainer.frame.size.height * 0.35
        let titleLbl = UILabel(frame: CGRect(x: 20, y: 30, width: innerContainer.frame.size.width - 40, height: tmp))
        titleLbl.textColor = Helper.getAppBlackColor()
        titleLbl.font = Helper.getBoldFont(20)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.numberOfLines = 0
        titleLbl.text = "Your personal statement says a little about you in a sentence or two. This will appear on your profile."
        
        innerContainer.addSubview(titleLbl)
        
        tmp = innerContainer.frame.size.height * 0.08
        
        personalStmtTxt = UITextView(frame: CGRect(x: titleLbl.frame.origin.x, y: (titleLbl.frame.origin.y + titleLbl.frame.size.height + 10), width: titleLbl.frame.size.width, height: 25))
        
        personalStmtTxt.delegate = self
        personalStmtTxt.textContainerInset = UIEdgeInsetsMake(5, -5, 0, 0)
        personalStmtTxt.scrollEnabled = false
        personalStmtTxt.font = Helper.getNormalFont()
        
        if User.getSharedUser().personalStmt.characters.count > 0 {
            personalStmtTxt.text = User.getSharedUser().personalStmt
            personalStmtTxt.textColor = Helper.getAppBlackColor()
            personalStmtTxt.tag = 1
        }else {
            personalStmtTxt.text = "Enter personal statement"
            personalStmtTxt.textColor = Helper.getAppGreenColor()
            personalStmtTxt.tag = 0
        }
        personalStmtTxt.autocorrectionType = .No
        personalStmtTxt.returnKeyType = UIReturnKeyType.Done
        
        personalStmtTxtBorder = UIView(frame: CGRect(x: personalStmtTxt.frame.origin.x, y: personalStmtTxt.frame.origin.y + personalStmtTxt.frame.size.height, width: personalStmtTxt.frame.size.width, height: 1))
        personalStmtTxtBorder.backgroundColor = Helper.getAppGreyColor()
        
        tmp = innerContainer.frame.size.width * 0.25
        let remainingHeight = innerContainer.frame.size.height - (personalStmtTxt.frame.origin.y + personalStmtTxt.frame.size.height)
        
        let acceptBtn = UIBlockButton(frame: CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        acceptBtn.center = CGPoint(x: innerContainer.frame.size.width / 2, y: (personalStmtTxt.frame.origin.y + personalStmtTxt.frame.size.height) + remainingHeight / 2)
        
        tmp = innerContainer.frame.size.width * 0.35
        let handImg = UIImageView(frame:CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        handImg.image = UIImage(named:"hand.gif")
        
        handImg.center = acceptBtn.center
        innerContainer.addSubview(handImg)
        
        innerContainer.addSubview(acceptBtn)
        
        innerContainer.addSubview(personalStmtTxt)
        innerContainer.addSubview(personalStmtTxtBorder)
        
        container.addSubview(innerContainer)
        
        personalStmtEntryPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        personalStmtEntryPopup.dimmedMaskAlpha = 0.85
        
        
        acceptBtn.callback = {(button:UIBlockButton) -> Void in
            
            if self.personalStmtTxt.text?.characters.count == 0 {
                Helper.showAlert("", message: "Please enter personal statement")
                return
            }
            
            let parameters = ["personal_statement":self.personalStmtTxt.text!]
            WebServices.getSharedWebServices().setUser(parameters, successCallback: { (message:String) -> Void in
                
                self.personalStmtEntryPopup.dismissPresentingPopup()
                self.setPersonalStmt()
                
                }, failureCallback: { (message:String) -> Void in
                    
                    self.personalStmtEntryPopup.dismissPresentingPopup()
                    Helper.showAlert("", message: message)
                    
            })
            
        }
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        personalStmtEntryPopup.showWithLayout(layout)
        
    }
    
    func tapDissmiss(tap:UITapGestureRecognizer) {
        if phoneEntryPopup != nil {
            phoneEntryPopup.dismissPresentingPopup()
        }
        if personalStmtEntryPopup != nil {
            personalStmtEntryPopup.dismissPresentingPopup()
        }
    }
    
    func tapDissmissStop(tap:UITapGestureRecognizer) {
    }

    
}
