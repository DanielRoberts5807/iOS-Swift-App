//
//  FeedsViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 01/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit
import FBSDKShareKit

class FeedsViewController : BaseViewController {
    
    
    @IBOutlet weak var tabBtnsScrollView: UIScrollView!
    @IBOutlet weak var selectedTabIndicatorView: UIView!
    @IBOutlet weak var selectedTabIndicatorLeadingSpace: NSLayoutConstraint!
    
    @IBOutlet weak var tabScrollView: UIScrollView!
   
    @IBOutlet weak var jobsTbl: UITableView!
    @IBOutlet weak var contentTbl: UITableView!
    @IBOutlet weak var eventsTbl: UITableView!
    @IBOutlet weak var coffeeTbl: UITableView!
    @IBOutlet weak var biteTbl: UITableView!

    @IBOutlet weak var contentCountLbl: UILabel!
    @IBOutlet weak var eventsCountLbl: UILabel!
    @IBOutlet weak var coffeeCountLbl: UILabel!
    @IBOutlet weak var biteCountLbl: UILabel!
    
    @IBOutlet weak var newPostsBtmLine: UIView!
    
    @IBOutlet weak var menuIcon: UIImageView!
    @IBOutlet weak var crossIcon: UIImageView!
    
    @IBOutlet weak var shareContentTxt: UITextField!
    
    var newPostsCount = 0
    var showMenu = true
    
    var contentFeed:[Feed] = []
    var eventsFeed:[Feed] = []
    var coffeeFeed:[Feed] = []
    var biteFeed:[Feed] = []
    
    var blockAlert:UIBlockAlert! = nil
    
    var notificationPopup:KLCPopup! = nil
    var currentFeedId:String! = nil
    
    var eventSuccessPopup:KLCPopup! = nil
    var currentEvent:Event! = nil
    
    var contentTblController:UITableViewController!
    var contentRefresh:UIRefreshControl!
    
    var eventsTblController:UITableViewController!
    var eventsRefresh:UIRefreshControl!
    
    var coffeeTblController:UITableViewController!
    var coffeeRefresh:UIRefreshControl!
    
    var biteTblController:UITableViewController!
    var biteRefresh:UIRefreshControl!
    
    var showProgress:Bool = true
    var currentFilter:FeedsFilter = FeedsFilter.Coffee
    
    var instructionPopup:KLCPopup! = nil
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        menuIcon.hidden = !showMenu
        crossIcon.hidden = showMenu
        setRefreshControl()
        UIApplication.sharedApplication().applicationIconBadgeNumber = 0
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        
        if let _ = Helper.getValueForKey("refreshContent") as? String {
            currentFilter = FeedsFilter.Content
            showProgress = true
            Helper.saveValue(currentFilter.rawValue, forKey: "feedsFilter")
            Helper.saveValue(nil, forKey: "refreshContent")
        }
        else if let feedsFilter = Helper.getValueForKey("feedsFilter") as? String {
            currentFilter = FeedsFilter(rawValue: feedsFilter)!
        }
        
        var tabNo = 0
        switch currentFilter {
        case .Jobs:
            tabNo = 0
        case .Content:
            tabNo = 1
        case .Events:
            tabNo = 2
        case .Coffee:
            tabNo = 3
        case .Bite:
            tabNo = 4
        }
        
        tabScrollView.contentOffset = CGPoint(x: CGFloat(tabNo) * tabScrollView.frame.size.width, y: 0)
        handleTabChange()

    }
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        if newPostsBtmLine != nil {
            newPostsBtmLine.layer.shadowColor = Helper.getAppGreyColor().CGColor
            newPostsBtmLine.layer.shadowOffset = CGSize(width: 0, height: 2)
            newPostsBtmLine.layer.shadowOpacity = 1
            newPostsBtmLine.layer.masksToBounds = false
            
        }
        
        if shareContentTxt != nil {
            setPlaceHolder("Paste url here to share", textField: shareContentTxt, white: true)
        }
        
        if jobsTbl != nil {
            jobsTbl.tableFooterView = UIView()
        }
        
        if contentTbl != nil {
            contentTbl.tableFooterView = UIView()
        }
        
        if eventsTbl != nil {
            eventsTbl.tableFooterView = UIView()
        }
        
        if coffeeTbl != nil {
            coffeeTbl.tableFooterView = UIView()
        }
        
        if biteTbl != nil {
            biteTbl.tableFooterView = UIView()
        }
        
        if contentCountLbl != nil {
            contentCountLbl.clipsToBounds = true
            contentCountLbl.layer.borderColor = Helper.getAppGreenColor().CGColor
            contentCountLbl.layer.borderWidth = 1
            contentCountLbl.layer.cornerRadius = contentCountLbl.frame.size.height / 2
        }
        
        if eventsCountLbl != nil {
            eventsCountLbl.clipsToBounds = true
            eventsCountLbl.layer.borderColor = Helper.getAppGreenColor().CGColor
            eventsCountLbl.layer.borderWidth = 1
            eventsCountLbl.layer.cornerRadius = eventsCountLbl.frame.size.height / 2
        }
        
        if coffeeCountLbl != nil {
            coffeeCountLbl.clipsToBounds = true
            coffeeCountLbl.layer.borderColor = Helper.getAppGreenColor().CGColor
            coffeeCountLbl.layer.borderWidth = 1
            coffeeCountLbl.layer.cornerRadius = coffeeCountLbl.frame.size.height / 2
        }
        
        if biteCountLbl != nil {
            biteCountLbl.clipsToBounds = true
            biteCountLbl.layer.borderColor = Helper.getAppGreenColor().CGColor
            biteCountLbl.layer.borderWidth = 1
            biteCountLbl.layer.cornerRadius = biteCountLbl.frame.size.height / 2
        }
        
        
    }
    
    func setRefreshControl() {
        
        contentTblController = UITableViewController()
        contentTblController.tableView = contentTbl
        
        contentRefresh = UIRefreshControl()
        setRefreshHelper(contentRefresh)
        contentTblController.refreshControl = contentRefresh
        
        
        eventsTblController = UITableViewController()
        eventsTblController.tableView = eventsTbl
        
        eventsRefresh = UIRefreshControl()
        setRefreshHelper(eventsRefresh)
        eventsTblController.refreshControl = eventsRefresh
        
        
        coffeeTblController = UITableViewController()
        coffeeTblController.tableView = coffeeTbl
        
        coffeeRefresh = UIRefreshControl()
        setRefreshHelper(coffeeRefresh)
        coffeeTblController.refreshControl = coffeeRefresh
        
        
        biteTblController = UITableViewController()
        biteTblController.tableView = biteTbl
        
        biteRefresh = UIRefreshControl()
        setRefreshHelper(biteRefresh)
        biteTblController.refreshControl = biteRefresh
        
    }
    
    func setRefreshHelper(refresh:UIRefreshControl) {
        
        refresh.tintColor = Helper.getAppBlackColor()
        let attributes = [NSForegroundColorAttributeName:Helper.getAppBlackColor(), NSFontAttributeName:Helper.getNormalFont(10)]
        refresh.attributedTitle = NSMutableAttributedString(string: "Loading...", attributes: attributes)
        refresh.addTarget(self, action: "loadDataFromServer", forControlEvents: UIControlEvents.ValueChanged)
        
    }
    
    func loadDataFromServer() {
        
        if showProgress {
            Helper.showCustomProgress(self)
        }else {
            
            switch currentFilter {
            case .Content:
                contentRefresh.beginRefreshing()
            case .Events:
                eventsRefresh.beginRefreshing()
            case .Coffee:
                coffeeRefresh.beginRefreshing()
            case .Bite:
                biteRefresh.beginRefreshing()
            default:
                break
            }
            
        }
        
        WebServices.getSharedWebServices().getFeeds(currentFilter.rawValue, successCallback: { (message:String, newPostsCount:Int, feeds:[Feed]) -> Void in
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                
                self.newPostsCount = newPostsCount
                let user = User.getSharedUser()
                
                switch self.currentFilter {
                case .Content:
                    user.activityContentCount = 0
                    self.contentFeed = feeds
                    self.contentTbl.reloadData()
                    
                case .Events:
                    user.activityEventCount = 0
                    self.eventsFeed = feeds
                    self.eventsTbl.reloadData()
                    
                case .Coffee:
                    user.activityCoffeeCount = 0
                    self.coffeeFeed = feeds
                    self.coffeeTbl.reloadData()
                    
                case .Bite:
                    user.activityBiteCount = 0
                    self.biteFeed = feeds
                    self.biteTbl.reloadData()
                    
                default:
                    break
                    
                }
                
                user.setActivityCounts(user.activityContentCount, eventCount: user.activityEventCount, coffeeCount: user.activityCoffeeCount, biteCount: user.activityBiteCount)
                self.setActivityCounts()
                
                if self.showProgress {
                    Helper.hideCustomProgress()
                }else {
                    
                    switch self.currentFilter {
                    case .Content:
                        self.contentRefresh.endRefreshing()
                    case .Events:
                        self.eventsRefresh.endRefreshing()
                    case .Coffee:
                        self.coffeeRefresh.endRefreshing()
                    case .Bite:
                        self.biteRefresh.endRefreshing()
                    default:
                        break
                    }
                    
                }
                self.showProgress = false
                
            })
            
        }, failureCallback: { (message:String) -> Void in
                
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                if self.showProgress {
                    Helper.hideCustomProgress()
                    Helper.showAlert("", message: message)
                }else {
                    
                    switch self.currentFilter {
                    case .Content:
                        self.contentRefresh.endRefreshing()
                    case .Events:
                        self.eventsRefresh.endRefreshing()
                    case .Coffee:
                        self.coffeeRefresh.endRefreshing()
                    case .Bite:
                        self.biteRefresh.endRefreshing()
                    default:
                        break
                    }
                    
                }
                self.showProgress = false
            })
                
        })
        
    }
    
    func setActivityCounts() {
    
        let user = User.getSharedUser()
        
        contentCountLbl.text = "\(user.activityContentCount)"
        contentCountLbl.hidden = user.activityContentCount <= 0
        
        eventsCountLbl.text = "\(user.activityEventCount)"
        eventsCountLbl.hidden = user.activityEventCount <= 0
        
        coffeeCountLbl.text = "\(user.activityCoffeeCount)"
        coffeeCountLbl.hidden = user.activityCoffeeCount <= 0
        
        biteCountLbl.text = "\(user.activityBiteCount)"
        biteCountLbl.hidden = user.activityBiteCount <= 0
        
    }
    
}


extension FeedsViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if tableView == jobsTbl {
        
            let cell = tableView.dequeueReusableCellWithIdentifier("FeedJobCell")! as! FeedJobCell
            switch indexPath.row {
            case 0:
                cell.titleLbl.text = "Find a Job"
            case 1:
                cell.titleLbl.text = "Post a Job"
            default:
                break
            }
            return cell
            
        }
        
        
        var feed:Feed! = nil
        if tableView == contentTbl {
            feed = contentFeed[indexPath.row]
        }else if tableView == eventsTbl {
            feed = eventsFeed[indexPath.row]
        }else if tableView == coffeeTbl {
            feed = coffeeFeed[indexPath.row]
        }else if tableView == biteTbl {
            feed = biteFeed[indexPath.row]
        }
        if feed == nil {
            feed = Feed()
        }
        
        var tblCell:UITableViewCell! = nil
        
        if feed.type == FeedType.Content {
        
            let cell = tableView.dequeueReusableCellWithIdentifier("ContentCell")! as! ContentCell
            
            cell.profileImg.setImageWithURL(NSURL(string: feed.profileImg)!, placeholderImage: UIImage(named:"profileImgPlaceholder"))
            
            let text = feed.name + " shared"
            let nameStr = NSMutableAttributedString(string: text, attributes: [NSForegroundColorAttributeName: Helper.getAppBlackColor(), NSFontAttributeName: Helper.getNormalFont(12)])
            
            let range = (text as NSString).rangeOfString(feed.name)
            nameStr.addAttributes([NSFontAttributeName: Helper.getBoldFont(12)], range: range)
            
            cell.nameLbl.attributedText = nameStr
            
            cell.likedImg.image = feed.contentLiked ? UIImage(named: "handIcon") : UIImage(named: "handIconGray")
            cell.likesLbl.textColor = feed.contentLiked ? Helper.getAppGreenColor() : Helper.getAppGreyColor()
            
            if feed.contentMeta != nil {
                cell.setContentMeta(feed.contentMeta)
                cell.likesLbl.text = "\(feed.contentLikes)"
                
                cell.selectedLblCallback = {(selectedLblPosition:SelectedLblPosition) in
                    
                    WebServices.getSharedWebServices().toggleLikeContent(feed.contentMeta.id,successCallback:   { (likesCount:Int, message:String) -> Void in
                        
                        feed.contentLikes = likesCount
                        feed.contentLiked = !feed.contentLiked
                        
                        cell.likesLbl.text = "\(feed.contentLikes)"
                        
                        cell.likedImg.image = feed.contentLiked ? UIImage(named: "handIcon") : UIImage(named: "handIconGray")
                        cell.likesLbl.textColor = feed.contentLiked ? Helper.getAppGreenColor() : Helper.getAppGreyColor()
                        
                        }, failureCallback: { (message:String) -> Void in
                          
                        Helper.showAlert("", message: message)
                            
                    })
                    
                }
                
                cell.openUrlCallback = {() in
                    
                    let contentDetailViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("ContentDetailViewController") as! ContentDetailViewController
                    contentDetailViewController.contentMeta = feed.contentMeta
                    self.presentViewController(contentDetailViewController, animated: true, completion: nil)
                    
                }
                
                cell.tapCallback = {
                    self.showInstructionPopup(feed)
                }
                
            }
            
            tblCell = cell
            
        }
        else if feed.action == FeedAction.Info {
            
            let cell = tableView.dequeueReusableCellWithIdentifier("FeedInfoCell")! as! FeedInfoCell
            cell.infoLbl.text = feed.message
            
            tblCell = cell
            
        }
        else {
        
            let cell = tableView.dequeueReusableCellWithIdentifier("FeedCell")! as! FeedCell
            
            cell.profileImg.setImageWithURL(NSURL(string: feed.profileImg)!, placeholderImage: UIImage(named:"profileImgPlaceholder"))
            cell.messageLbl.text = feed.message
            
            cell.actionLbl.text = feed.action.rawValue
            
            if feed.action == FeedAction.Event {
                
                cell.selectedLblCallback = {(selectedLblPosition:SelectedLblPosition) in
                    
                    WebServices.getSharedWebServices().eventInviteRespond(feed.id, response: "1", successCallback:   { (message:String) -> Void in
                        
                        let event = Event(event: feed.event)
                        self.showEventSuccessPopup(event)
                        self.loadDataFromServer()
                        Feed.removeFeed(feed.id, feedFor: self.currentFilter.rawValue)
                        
                        }, failureCallback: { (message:String) -> Void in
                            
                            Helper.showAlert("", message: message)
                            
                    })
                    
                }
                
            }else if feed.action == FeedAction.EventDetail {
                
                cell.selectedLblCallback = {(selectedLblPosition:SelectedLblPosition) in
                    
                    self.currentEvent = feed.event
                    self.openEventDetails()
                                    
                }
                
            }else if feed.action == FeedAction.Bite || feed.action == FeedAction.Coffee {
                
                cell.selectedLblCallback = {(selectedLblPosition:SelectedLblPosition) in
                    self.showNotificationView(feed)
                }
                
            }else if feed.action == FeedAction.InfoContact {
                
                cell.selectedLblCallback = {(selectedLblPosition:SelectedLblPosition) in
                    
                    let contact = Contact(id: feed.contactId, name: feed.contactName, profileImage: "")
                    let contactDetailViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("ContactDetailViewController") as! ContactDetailViewController
                    contactDetailViewController.contact = contact
                    self.presentViewController(contactDetailViewController, animated: true, completion: nil)
                    
                }
                
            }
            
            
            if feed.action == FeedAction.InfoEvent {
                cell.meLbl.text = "Cool"
            }else {
                cell.meLbl.text = "I'm"
            }
            
            cell.tapCallback = {
                self.showInstructionPopup(feed)
            }
            
            cell.enableMeLbl(feed.action == FeedAction.Event)
            tblCell = cell
            
        }
        
        if indexPath.row < newPostsCount {
            tblCell.backgroundColor = UIColor.clearColor()
        }else {
            tblCell.backgroundColor = UIColor(white: 250.0/255.0, alpha: 1.0)
        }
        
        return tblCell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        var count = 0
        if tableView == jobsTbl {
            count = 2
        }else if tableView == contentTbl {
            count = contentFeed.count
        }else if tableView == eventsTbl {
            count = eventsFeed.count
        }else if tableView == coffeeTbl {
            count = coffeeFeed.count
        }else if tableView == biteTbl {
            count = biteFeed.count
        }
        
        return count
        
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        if tableView == jobsTbl {
            return 50 / 600 * UIScreen.mainScreen().bounds.size.height
        }
        
        var feed:Feed! = nil
        if tableView == contentTbl {
            feed = contentFeed[indexPath.row]
        }else if tableView == eventsTbl {
            feed = eventsFeed[indexPath.row]
        }else if tableView == coffeeTbl {
            feed = coffeeFeed[indexPath.row]
        }else if tableView == biteTbl {
            feed = biteFeed[indexPath.row]
        }
        
        if feed == nil {
            return 0
        }
        
        if feed.type == FeedType.Content {
            return 200 / 600 * UIScreen.mainScreen().bounds.size.height
        }else if feed.action == FeedAction.Info {
            return 100 / 600 * UIScreen.mainScreen().bounds.size.height
        }
        return 120 / 600 * UIScreen.mainScreen().bounds.size.height
        
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        if tableView == jobsTbl {
        
            switch indexPath.row {
            case 0:
            
                let jobsViewController = storyboard?.instantiateViewControllerWithIdentifier("JobsViewController")
                presentViewController(jobsViewController!, animated: true, completion: nil)
                
                break
            case 1:
            
                let url = NSURL(string: Helper.postJobUrl)!
                if !UIApplication.sharedApplication().canOpenURL(url) {
                    Helper.showAlert("", message:Helper.genericErrorMsg)
                    return
                }
                UIApplication.sharedApplication().openURL(url)
                
                break
            default:
                break
            }
            
        }
        
    }
    
    func showNotificationView(feed:Feed) {
    
        currentFeedId = feed.id
        let invitation = feed.action == FeedAction.Bite ? "bite" : "coffee"
        let foodCaffine = feed.action == FeedAction.Bite ? "food" : "caffeine"
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapDissmiss:")
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.5))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        let tapGestureStop = UITapGestureRecognizer(target: self, action: "tapDissmissStop:")
        innerContainer.addGestureRecognizer(tapGestureStop)
        
        let titleLbl = UILabel(frame: CGRect(x: 10, y: 20, width: innerContainer.frame.size.width - 20, height: innerContainer.frame.size.height * 0.4))
        titleLbl.textColor = Helper.getAppBlackColor()
        titleLbl.font = Helper.getBoldFont(22)
        titleLbl.textAlignment = NSTextAlignment.Center
        titleLbl.numberOfLines = 0
        titleLbl.text = "Super duper! You want a " + invitation + " with " + feed.name + ". May the " + foodCaffine + " be with you!"
        
        innerContainer.addSubview(titleLbl)
        
        tmp = innerContainer.frame.size.width * 0.25
        let acceptBtn = UIBlockButton(frame: CGRect(x: ((innerContainer.frame.size.width - tmp) / 2), y: (titleLbl.frame.origin.y + titleLbl.frame.size.height + 4), width: tmp, height: tmp * 1.14))
        
        tmp = innerContainer.frame.size.width * 0.35
        let handImg = UIImageView(frame:CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        handImg.image = UIImage(named:"hand.gif")
        
        handImg.center = acceptBtn.center
        innerContainer.addSubview(handImg)
        
        innerContainer.addSubview(acceptBtn)
        
        tmp = innerContainer.frame.size.height * 0.25
        let rejectBtn = UIBlockButton(frame: CGRect(x: titleLbl.frame.origin.x, y: (innerContainer.frame.size.height - tmp), width: titleLbl.frame.size.width, height: tmp))
        rejectBtn.setTitleColor(Helper.getAppBlackColor(), forState: UIControlState.Normal)
        rejectBtn.setTitle(("I didn't mean to get a " + invitation + " with " + feed.name), forState: UIControlState.Normal)
        rejectBtn.titleLabel?.font = Helper.getNormalFont()
        rejectBtn.titleLabel?.textAlignment = NSTextAlignment.Center
        
        innerContainer.addSubview(rejectBtn)
        
        container.addSubview(innerContainer)
        
        tmp = innerContainer.frame.origin.y + innerContainer.frame.size.height
        let bottomContainer = UIView(frame: CGRect(x: innerContainer.frame.origin.x, y: tmp, width: innerContainer.frame.size.width, height: container.frame.size.height - tmp))
        
        tmp = bottomContainer.frame.size.width * 0.2
        let cancelBtn = UIBlockButton(frame: CGRect(x: ((bottomContainer.frame.size.width - tmp) / 2), y: ((bottomContainer.frame.size.height - tmp) / 2), width: tmp, height: tmp))
        cancelBtn.setBackgroundImage(UIImage(named: "notificationClose"), forState: UIControlState.Normal)
        
        
        bottomContainer.addSubview(cancelBtn)
        
        container.addSubview(bottomContainer)
        
        
        notificationPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: false, dismissOnContentTouch: false)
        notificationPopup.dimmedMaskAlpha = 0.85
        
        acceptBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.notificationPopup.dismissPresentingPopup()
            self.respondFeed(feed.id, response: "1")
            
        }
        
        rejectBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.notificationPopup.dismissPresentingPopup()
            self.respondFeed(feed.id, response: "2")
            
        }
        
        cancelBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.notificationPopup.dismissPresentingPopup()
            self.respondFeed(feed.id, response: "1")
            
        }
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        notificationPopup.showWithLayout(layout)
        
    }
    
    func tapDissmiss(tap:UITapGestureRecognizer) {
        
        self.notificationPopup.dismissPresentingPopup()
        if currentFeedId != nil {
            self.respondFeed(currentFeedId, response: "1")
        }
        
    }
    
    func tapDissmissStop(tap:UITapGestureRecognizer) {
    }
    
    func respondFeed(id:String, response:String) {
    
        WebServices.getSharedWebServices().respondFeed(id, response: response, successCallback:   { (message:String) -> Void in
            
//            Helper.showAlert("", message: message)
            self.loadDataFromServer()
            
        }, failureCallback: { (message:String) -> Void in
                
            Helper.showAlert("", message: message)
            
        })

        
    }
    
    func showEventSuccessPopup(event:Event) {
        
        currentEvent = event
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapEventDissmiss:")
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: width * 0.1, y: tmp, width: width * 0.8, height: height * 0.5))
        innerContainer.backgroundColor = UIColor.whiteColor()
        innerContainer.layer.cornerRadius = 5
        
        let tapGestureStop = UITapGestureRecognizer(target: self, action: "tapEventDissmissStop:")
        innerContainer.addGestureRecognizer(tapGestureStop)
        
        let titleLbl = UITextView(frame: CGRect(x: 20, y: 20, width: innerContainer.frame.size.width - 40, height: innerContainer.frame.size.height * 0.32))
        titleLbl.backgroundColor = UIColor.clearColor()
        titleLbl.editable = false
        titleLbl.scrollEnabled = false
        
        let text = "Solid! You are attending " + event.title + "! Be sure to check out the event details!"
        let atrStr = NSMutableAttributedString(string: text, attributes: [NSForegroundColorAttributeName: Helper.getAppBlackColor(), NSFontAttributeName: Helper.getNormalFont(20)])
        
        var range = (text as NSString).rangeOfString("event details")
        atrStr.addAttributes([NSLinkAttributeName: "details", NSUnderlineStyleAttributeName: 1], range: range)
        
        titleLbl.attributedText = atrStr
        titleLbl.delegate = self
        titleLbl.linkTextAttributes = [NSForegroundColorAttributeName: Helper.getAppGreenColor()]
        titleLbl.textAlignment = NSTextAlignment.Center
        
        innerContainer.addSubview(titleLbl)
        
        tmp = innerContainer.frame.size.height * 0.11
        let shareBtn = UIBlockButton(frame: CGRect(x: titleLbl.frame.origin.x, y: (titleLbl.frame.origin.y + titleLbl.frame.size.height + 10), width: titleLbl.frame.size.width, height: tmp))
        
        tmp = innerContainer.frame.size.height * 0.11
        let fbImg = UIImageView(frame: CGRect(x: 0, y: 0, width: tmp * 4, height: tmp))
        fbImg.center = shareBtn.center
        fbImg.image = UIImage(named: "fb_share")
        
        innerContainer.addSubview(shareBtn)
        innerContainer.addSubview(fbImg)
        
        
        tmp = innerContainer.frame.size.width * 0.25
        let acceptBtn = UIBlockButton(frame: CGRect(x: ((innerContainer.frame.size.width - tmp) / 2), y: (shareBtn.frame.origin.y + shareBtn.frame.size.height + 10), width: tmp, height: tmp * 1.14))
        
        tmp = innerContainer.frame.size.width * 0.35
        let handImg = UIImageView(frame:CGRect(x: 0, y: 0, width: tmp, height: tmp * 1.14))
        handImg.image = UIImage(named:"hand.gif")
        
        handImg.center = acceptBtn.center
        innerContainer.addSubview(handImg)
        
        innerContainer.addSubview(acceptBtn)
        
        tmp = innerContainer.frame.size.height * 0.25
        let rejectBtn = UIBlockButton(frame: CGRect(x: titleLbl.frame.origin.x, y: (innerContainer.frame.size.height - tmp), width: titleLbl.frame.size.width, height: tmp))
        
        let rejectLbl = UILabel(frame: rejectBtn.frame)
        rejectLbl.textColor = Helper.getAppBlackColor()
        rejectLbl.text = "In the last few miliseconds, I've changed my mind. I no longer want to attend."
        rejectLbl.font = Helper.getNormalFont()
        rejectLbl.textAlignment = NSTextAlignment.Center
        rejectLbl.numberOfLines = 0
    
        innerContainer.addSubview(rejectLbl)
        innerContainer.addSubview(rejectBtn)
        
        container.addSubview(innerContainer)
        
        tmp = innerContainer.frame.origin.y + innerContainer.frame.size.height
        let bottomContainer = UIView(frame: CGRect(x: innerContainer.frame.origin.x, y: tmp, width: innerContainer.frame.size.width, height: container.frame.size.height - tmp))
        
        tmp = bottomContainer.frame.size.width * 0.2
        let cancelBtn = UIBlockButton(frame: CGRect(x: ((bottomContainer.frame.size.width - tmp) / 2), y: ((bottomContainer.frame.size.height - tmp) / 2), width: tmp, height: tmp))
        cancelBtn.setBackgroundImage(UIImage(named: "notificationClose"), forState: UIControlState.Normal)
        
        bottomContainer.addSubview(cancelBtn)
        
        container.addSubview(bottomContainer)
        
        
        eventSuccessPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        eventSuccessPopup.dimmedMaskAlpha = 0.85
        
        
        acceptBtn.callback = {(button:UIBlockButton) -> Void in
            self.openEventDetails()
        }
        
        shareBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.eventSuccessPopup.dismissPresentingPopup()
            
            let facebookDataLoader = FacebookDataLoader()
            
            let weekDay = Helper.dayNameFromDate(String(event.year) + "-" + String(event.month) + "-" + String(event.day))
            let detail = weekDay + " " + String(format:"%02d",event.day) + "/" + String(format:"%02d",event.month) + " - " + event.location
            facebookDataLoader.shareEvent(event.title, eventDetail: detail, viewController: self, successCallback: { (message:String) in
                
                Helper.showAlert("", message: message)
                
            }) { (message:String) in
                
                Helper.showAlert("", message: message)
                
            }
            
        }
        
        rejectBtn.callback = {(button:UIBlockButton) -> Void in
            
            self.eventSuccessPopup.dismissPresentingPopup()
            WebServices.getSharedWebServices().eventInviteRespond(event.id, response: "2", successCallback:   { (message:String) -> Void in
                
//                Helper.showAlert("", message: message)
                self.loadDataFromServer()
                
            }, failureCallback: { (message:String) -> Void in
                    
                Helper.showAlert("", message: message)
                    
            })
            
        }
        
        cancelBtn.callback = {(button:UIBlockButton) -> Void in
           self.openEventDetails()
        }
        
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        eventSuccessPopup.showWithLayout(layout)
        
    }
    
    func openEventDetails() {
        
        if eventSuccessPopup != nil {
            eventSuccessPopup.dismissPresentingPopup()
        }
        if currentEvent != nil {
            let eventInviteViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("EventInviteViewController") as! EventInviteViewController
            eventInviteViewController.event = currentEvent
            presentViewController(eventInviteViewController, animated: true, completion: nil)
        }
        
    }
    
    func tapEventDissmiss(tap:UITapGestureRecognizer) {
        openEventDetails()
    }
    
    func tapEventDissmissStop(tap:UITapGestureRecognizer) {
    }
    
    func showInstructionPopup(feed:Feed) {
        
        let width = UIScreen.mainScreen().bounds.size.width, height = UIScreen.mainScreen().bounds.size.height
        let margin:CGFloat = 20
        let container = UIView(frame: CGRect(x: 0, y: 0, width: width, height: height))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "tapInstructinDissmiss:")
        tapGesture.delegate = self
        container.addGestureRecognizer(tapGesture)
        
        var tmp = (height - (height * 0.5)) / 2
        let innerContainer = UIView(frame: CGRect(x: margin, y: margin, width: width - 2 * margin, height: height - 2 * margin))
        innerContainer.backgroundColor = UIColor(white: 65.0/255.0, alpha: 1.0)
        innerContainer.layer.cornerRadius = 5
        
        tmp = innerContainer.frame.size.height * 0.35
        
        let dragRightLbl = UILabel(frame: CGRect(x: margin, y: innerContainer.frame.size.height - (margin + 30), width: innerContainer.frame.size.width - 2 * margin, height: 30))
        dragRightLbl.textColor = UIColor(white: 120.0/255.0, alpha: 0.8)
        dragRightLbl.font = Helper.getNormalFont(14)
        dragRightLbl.textAlignment = NSTextAlignment.Center
        dragRightLbl.numberOfLines = 0
        
        if feed.type == FeedType.Content {
            dragRightLbl.text = "Drag to right to like"
        }else if feed.action == FeedAction.InfoContact {
            dragRightLbl.text = "Drag to right to see contact details"
        }else if feed.action == FeedAction.EventDetail {
            dragRightLbl.text = "Drag to right to see event details"
        }else {
            dragRightLbl.text = "Drag to right to accept"
        }
        
        innerContainer.addSubview(dragRightLbl)
        
        let profileImg = UIImageView(frame: CGRect(x: 0, y: 0, width: 120, height: 120))
        profileImg.center = CGPoint(x: innerContainer.frame.size.width / 2, y: innerContainer.frame.size.height / 2)
        profileImg.image = UIImage(named: "profileImgPlaceholder")
        profileImg.setImageWithURL(NSURL(string: feed.profileImg)!, placeholderImage: UIImage(named:"profileImgPlaceholder"))
        profileImg.clipsToBounds = true
        profileImg.layer.cornerRadius = profileImg.frame.size.height / 2
        
        innerContainer.addSubview(profileImg)
        
        tmp = profileImg.frame.origin.y - 35
        let titleCompLbl = UILabel(frame: CGRect(x: margin, y: tmp, width: innerContainer.frame.size.width - 2 * margin, height: 25))
        titleCompLbl.textColor = Helper.getAppGreenColor()
        titleCompLbl.font = Helper.getNormalFont(14)
        titleCompLbl.textAlignment = NSTextAlignment.Center
        
        if feed.title.characters.count > 0 && feed.company.characters.count > 0 {
            titleCompLbl.text = feed.title + " @ " + feed.company
        }else {
            titleCompLbl.text = feed.title + feed.company
        }
        
        innerContainer.addSubview(titleCompLbl)
        
        tmp = titleCompLbl.frame.origin.y - 35
        let nameLbl = UILabel(frame: CGRect(x: margin, y: tmp, width: innerContainer.frame.size.width - 2 * margin, height: 25))
        nameLbl.textColor = Helper.getAppGreenColor()
        nameLbl.font = Helper.getBoldFont(16)
        nameLbl.textAlignment = NSTextAlignment.Center
        nameLbl.text = feed.name
        
        innerContainer.addSubview(nameLbl)
        
        tmp = profileImg.frame.origin.y + profileImg.frame.size.height + 10
        let personalStmtTitleLbl = UILabel(frame: CGRect(x: margin, y: tmp, width: innerContainer.frame.size.width - 2 * margin, height: 20))
        personalStmtTitleLbl.textColor = Helper.getAppGreyColor()
        personalStmtTitleLbl.font = Helper.getNormalFont(10)
        personalStmtTitleLbl.textAlignment = NSTextAlignment.Center
        personalStmtTitleLbl.text = "Personal Statement"
        
        innerContainer.addSubview(personalStmtTitleLbl)
        
        tmp = personalStmtTitleLbl.frame.origin.y + personalStmtTitleLbl.frame.size.height + 10
        let personalStmtLbl = TopAlignedLabel(frame: CGRect(x: margin, y: tmp, width: innerContainer.frame.size.width - 2 * margin, height: 40))
        personalStmtLbl.textColor = Helper.getAppWhiteColor()
        personalStmtLbl.font = Helper.getNormalFont(14)
        personalStmtLbl.textAlignment = NSTextAlignment.Center
        personalStmtLbl.text = feed.personalStmt.characters.count > 0 ? "\"\(feed.personalStmt)\"" : ""
        
        innerContainer.addSubview(personalStmtLbl)
        
        container.addSubview(innerContainer)
        
        instructionPopup = KLCPopup(contentView: container, showType: KLCPopupShowType.BounceInFromTop, dismissType: KLCPopupDismissType.BounceOutToBottom, maskType: KLCPopupMaskType.Dimmed, dismissOnBackgroundTouch: true, dismissOnContentTouch: false)
        instructionPopup.dimmedMaskAlpha = 0.85
        let layout = KLCPopupLayoutMake(KLCPopupHorizontalLayout.Center, KLCPopupVerticalLayout.Center)
        instructionPopup.showWithLayout(layout)
        
    }
    
    func tapInstructinDissmiss(tap:UITapGestureRecognizer) {
        if instructionPopup != nil {
            instructionPopup.dismissPresentingPopup()
            instructionPopup = nil
        }
    }
    
}

extension FeedsViewController : FBSDKSharingDelegate {
    
    func sharer(sharer: FBSDKSharing!, didFailWithError error: NSError!) {
        Helper.showAlert("", message: Helper.genericErrorMsg)
    }
    
    func sharerDidCancel(sharer: FBSDKSharing!) {
        Helper.showAlert("", message: Helper.genericErrorMsg)
    }
    
    func sharer(sharer: FBSDKSharing!, didCompleteWithResults results: [NSObject : AnyObject]!) {
//        Helper.showAlert("", message: "Sharing done successfully.")
    }
    
}

extension FeedsViewController : UITextViewDelegate {
    func textView(textView: UITextView, shouldInteractWithURL URL: NSURL, inRange characterRange: NSRange) -> Bool {
        
        if URL.absoluteString == "details" {
            openEventDetails()
        }
        return false
    }
}

extension FeedsViewController : UIScrollViewDelegate {
    
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if scrollView == tabScrollView && !decelerate {
            handleTabChange()
        }
    }
    
    func scrollViewDidEndDecelerating(scrollView: UIScrollView) {
        if scrollView == tabScrollView {
            handleTabChange()
        }
    }
    
}

extension FeedsViewController {
    
    @IBAction func topLeftBtnAct(sender: UIButton) {
        if showMenu {
            menuContainerViewController.toggleLeftSideMenuCompletion(nil)
        }else {
            dismissViewControllerAnimated(true, completion: nil)
        }
    }
    
    @IBAction func changeTabAct(sender:UIButton) {
    
        tabScrollView.contentOffset = CGPoint(x: CGFloat(sender.tag) * tabScrollView.frame.size.width, y: 0)
        handleTabChange()
        
    }
    
    func handleTabChange() {
    
        let tabNo = Int(tabScrollView.contentOffset.x / tabScrollView.frame.size.width)
        
        selectedTabIndicatorLeadingSpace.constant = CGFloat(tabNo) * selectedTabIndicatorView.frame.size.width
        
        switch tabNo {
        case 0:
            currentFilter = FeedsFilter.Jobs
        case 1:
            currentFilter = FeedsFilter.Content
            contentFeed = Feed.loadFeedsForFilter(currentFilter.rawValue)
            contentTbl.reloadData()
        case 2:
            currentFilter = FeedsFilter.Events
            eventsFeed = Feed.loadFeedsForFilter(currentFilter.rawValue)
            eventsTbl.reloadData()
        case 3:
            currentFilter = FeedsFilter.Coffee
            coffeeFeed = Feed.loadFeedsForFilter(currentFilter.rawValue)
            coffeeTbl.reloadData()
        case 4:
            currentFilter = FeedsFilter.Bite
            biteFeed = Feed.loadFeedsForFilter(currentFilter.rawValue)
            biteTbl.reloadData()
        default:
            break
        }
        if tabNo == 0 {
            tabBtnsScrollView.contentOffset = CGPoint(x: 0, y: 0)
        }else if tabNo == 4 {
            tabBtnsScrollView.contentOffset = CGPoint(x: selectedTabIndicatorView.frame.size.width, y: 0)
        }
        
        Helper.saveValue(currentFilter.rawValue, forKey: "feedsFilter")
        setTabCounts()
        if currentFilter == .Jobs {
            return
        }
        
        showProgress = true
        loadDataFromServer()
        
    }
    
    func setTabCounts() {
        
        resetCountLbl(contentCountLbl)
        resetCountLbl(eventsCountLbl)
        resetCountLbl(coffeeCountLbl)
        resetCountLbl(biteCountLbl)
        
        setActivityCounts()
        
        switch currentFilter {
        case FeedsFilter.Coffee:
            selectCountLbl(coffeeCountLbl)
        case FeedsFilter.Bite:
            selectCountLbl(biteCountLbl)
        case FeedsFilter.Content:
            selectCountLbl(contentCountLbl)
        case FeedsFilter.Events:
            selectCountLbl(eventsCountLbl)
        default:
            break
        }
        
    }
    
    func resetCountLbl(lbl:UILabel) {
        lbl.backgroundColor = Helper.getAppGreenColor()
        lbl.textColor = UIColor.whiteColor()
    }
    
    func selectCountLbl(lbl:UILabel) {
        lbl.backgroundColor = UIColor.clearColor()
        lbl.textColor = Helper.getAppGreenColor()
    }
    
    @IBAction func openShareContentAct(sender: UIButton) {
        
        let shareContentViewController = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle()).instantiateViewControllerWithIdentifier("ShareContentViewController") as! ShareContentViewController
        self.presentViewController(shareContentViewController, animated: true, completion: nil)
        
    }
}



