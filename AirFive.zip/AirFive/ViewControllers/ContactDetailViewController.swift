//
//  ContactDetailViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 15/04/2016.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit
import MessageUI

class ContactDetailViewController: BaseViewController {
    
    @IBOutlet weak var nameLbl: UILabel!
    
    @IBOutlet weak var coverImg: UIImageView!
    @IBOutlet weak var profileImg: UIImageView!
    
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var schoolImg: UIImageView!
    @IBOutlet weak var schoolLbl: UILabel!
    @IBOutlet weak var secondSchoolImg: UIImageView!
    @IBOutlet weak var secondSchoolLbl: UILabel!
    
    @IBOutlet weak var personalStmtLbl: UILabel!
    
    @IBOutlet weak var detailTbl: UITableView!
    @IBOutlet weak var containerScrollView: UIScrollView!
    
    var contact:Contact! = nil
    var contactDetail:ContactDetail! = nil
    
    var containerScrollViewInitY: CGFloat = 0, fontMaxDelta:CGFloat = 10
    var nameInitFont:CGFloat = 0, schoolInitFont:CGFloat = 0, secondSchoolInitFont:CGFloat = 0
    var currentPhone:String! = nil
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        containerScrollViewInitY = containerScrollView.contentOffset.y
        nameInitFont = nameLbl.font.pointSize
        schoolInitFont = schoolLbl.font.pointSize
        secondSchoolInitFont = secondSchoolLbl.font.pointSize
        detailTbl.tableFooterView = UIView()
        nameLbl.text = contact != nil ? contact.name : ""
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
        super.viewDidAppear(animated)
        loadDataFromServer()
        
        adjustViews()
        
    }
    
    func adjustViews() {
        
        profileImg.layer.masksToBounds = true
        profileImg.layer.cornerRadius = profileImg.frame.size.height / 2
        
    }
    
    func loadDataFromServer() {
        
        WebServices.getSharedWebServices().getContactDetail(contact.id, successCallback: { (message:String, contactDetail:ContactDetail) -> Void in
            
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.contactDetail = contactDetail
                self.setContactData()
            })
            
        }, failureCallback: { (message:String) -> Void in
                
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                Helper.showAlert("", message: message)
            })
                
        })
        
    }
    
    func setContactData() {
        
        nameLbl.text = contactDetail.name
        setTitleNCompany(12)
        schoolLbl.text = contactDetail.school
        schoolImg.hidden = contactDetail.school.characters.count == 0
        secondSchoolLbl.text = contactDetail.secondSchool
        secondSchoolImg.hidden = contactDetail.secondSchool.characters.count == 0
        personalStmtLbl.text = contactDetail.personalStmt
        
        profileImg.setImageWithURL(NSURL(string: contactDetail.profileImg)!, placeholderImage: UIImage(named:"profileImgPlaceholder"))
        coverImg.setImageWithURL(NSURL(string: contactDetail.coverImg)!, placeholderImage: UIImage(named:"backgroundImg"))
       
        detailTbl.reloadData()
        
    }
    
    func setTitleNCompany(fontSize:CGFloat) {
        if contactDetail.title.characters.count > 0 || contactDetail.company.characters.count > 0 {
            let titleStr = contactDetail.title + " @ " + contactDetail.company
            let attributedStr = NSMutableAttributedString(string: titleStr, attributes: [NSFontAttributeName: Helper.getNormalFont(fontSize)])
            let range = (titleStr as NSString).rangeOfString("@")
            attributedStr.addAttributes([NSFontAttributeName: Helper.getNormalFont(fontSize - 4)], range: range)
            titleLbl.attributedText = attributedStr
        }else {
            titleLbl.text = ""
        }
    }
    
}

extension ContactDetailViewController : UIScrollViewDelegate {
    
    func scrollViewDidScroll(scrollView: UIScrollView) {
        
        if scrollView != containerScrollView {
            return
        }
        
        if (scrollView.contentOffset.y > (scrollView.contentSize.height - scrollView.frame.size.height)) {
            scrollView.setContentOffset(CGPoint(x: scrollView.contentOffset.x, y: (scrollView.contentSize.height - scrollView.frame.size.height)), animated: false)
        }
        
        let delta = -1 * (scrollView.contentOffset.y - containerScrollViewInitY) / (200.0 - containerScrollViewInitY) * fontMaxDelta
        
        nameLbl.font = nameLbl.font.fontWithSize(nameInitFont + delta)
        setTitleNCompany(12 + delta)
        schoolLbl.font = schoolLbl.font.fontWithSize(schoolInitFont + delta)
        secondSchoolLbl.font = secondSchoolLbl.font.fontWithSize(secondSchoolInitFont + delta)
        
    }
}


extension ContactDetailViewController : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("ContactDetailCell")! as! ContactDetailCell
        
        
        let detail = contactDetail.detailUrls[indexPath.row]
        
        switch detail.urlName {
        case "email", "phone":
            cell.titleLbl.hidden = false
            cell.titleImg.hidden = true
            
            cell.detailLbl.hidden = false
            cell.detailImg.hidden = true
        default:
            cell.titleLbl.hidden = true
            cell.titleImg.hidden = false
            
            cell.detailLbl.hidden = true
            cell.detailImg.hidden = false

        }
        
        cell.detailLbl.textColor = Helper.getAppBlackColor()
        switch detail.urlName {
        case "email":
            cell.titleLbl.text = "EMAIL"
            cell.detailLbl.text = detail.urlValue
            cell.detailLbl.textColor = Helper.getAppGreenColor()
            
        case "phone":
            cell.titleLbl.text = "PHONE"
            cell.detailLbl.text = detail.urlValue
            cell.detailLbl.textColor = Helper.getAppGreenColor()
            
        case "facebook":
            cell.titleImg.image = UIImage(named: "socialFacebook")
            cell.titleImgHieght.constant = cell.frame.size.height * 0.31
            cell.titleImgWidth.constant = cell.titleImgHieght.constant * 0.5
        case "twitter":
            cell.titleImg.image = UIImage(named: "socialTwitter")
            cell.titleImgHieght.constant = cell.frame.size.height * 0.24
            cell.titleImgWidth.constant = cell.titleImgHieght.constant * 1.28
        case "google":
            cell.titleImg.image = UIImage(named: "socialGoogle")
            cell.titleImgHieght.constant = cell.frame.size.height * 0.34
            cell.titleImgWidth.constant = cell.titleImgHieght.constant * 0.647
        case "tumblr":
            cell.titleImg.image = UIImage(named: "socialTumblr")
            cell.titleImgHieght.constant = cell.frame.size.height * 0.31
            cell.titleImgWidth.constant = cell.titleImgHieght.constant * 0.566
        case "instagram":
            cell.titleImg.image = UIImage(named: "socialInstagram")
            cell.titleImgHieght.constant = cell.frame.size.height * 0.37
            cell.titleImgWidth.constant = cell.titleImgHieght.constant * 0.945
        case "linkedin":
            cell.titleImg.image = UIImage(named: "socialLinkedin")
            cell.titleImgHieght.constant = cell.frame.size.height * 0.27
            cell.titleImgWidth.constant = cell.titleImgHieght.constant * 1.074
        case "snapchat":
            cell.titleImg.image = UIImage(named: "socialSnapchat")
            cell.titleImgHieght.constant = cell.frame.size.height * 0.34
            cell.titleImgWidth.constant = cell.titleImgHieght.constant * 1.058
        default:
            break
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactDetail == nil ? 0 : contactDetail.detailUrls.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60 / 600 * UIScreen.mainScreen().bounds.size.height
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let detail = contactDetail.detailUrls[indexPath.row]
        
        switch detail.urlName {
        case "email":
            openEmailViewContoller(detail.urlValue)
        case "phone":
            openPhoneContoller(detail.urlValue)
            
        case "facebook":
            openUrl(detail.urlValue)
        case "twitter":
            openUrl("https://www.twitter.com/" + detail.urlValue)
        case "google":
            openUrl(detail.urlValue)
        case "tumblr":
            openUrl(detail.urlValue)
        case "instagram":
            openUrl("https://www.instagram.com/" + detail.urlValue)
        case "linkedin":
            openUrl(detail.urlValue)
        case "snapchat":
            openUrl("snapchat://add/" + detail.urlValue)
            
        default:
            break
            
        }
               
    }

    func openEmailViewContoller(email:String) {
        
        if MFMailComposeViewController.canSendMail() {
            let mailComposer = MFMailComposeViewController()
            mailComposer.mailComposeDelegate = self
            mailComposer.setToRecipients([email])
            presentViewController(mailComposer, animated: true, completion: nil)
            
        }else {
            Helper.showAlert("", message: "Email not supported. Kindly check your settings for email account.")
        }
    }
    
    func openPhoneContoller(phone:String) {
        
        currentPhone = phone
        let actionSheet = UIActionSheet(title: nil, delegate: self, cancelButtonTitle: "Cancel", destructiveButtonTitle: nil, otherButtonTitles: "Send message", "Call")
        actionSheet.showInView(view)
        
    }
    
    func openUrl(urlStr:String) {
        let url = NSURL(string: urlStr)!
        if !UIApplication.sharedApplication().canOpenURL(url) {
            Helper.showAlert("", message:Helper.genericErrorMsg)
            return
        }
        UIApplication.sharedApplication().openURL(url)
    }
    
}

extension ContactDetailViewController : UIActionSheetDelegate {
    
    func actionSheet(actionSheet: UIActionSheet, clickedButtonAtIndex buttonIndex: Int) {
        
        if buttonIndex == 0 {//cancel
            return
        }
        if buttonIndex == 1 {// sms
            
            if !MFMessageComposeViewController.canSendText() {
                Helper.showAlert("", message: "Message not supported on device")
            }else {
                let messageComposer = MFMessageComposeViewController()
                messageComposer.messageComposeDelegate = self
                messageComposer.recipients = [currentPhone!]
                presentViewController(messageComposer, animated: true, completion: nil)
            }
            
        }else {//call
            
            let phoneNo = "telprompt://" + currentPhone.stringByReplacingOccurrencesOfString(" ", withString: "")
            let url = NSURL(string: phoneNo)!
            if !UIApplication.sharedApplication().canOpenURL(url) {
                Helper.showAlert("", message:Helper.genericErrorMsg)
                return
            }
            UIApplication.sharedApplication().openURL(url)
            
        }
        
    }
    
}

extension ContactDetailViewController : MFMessageComposeViewControllerDelegate {
    
    func messageComposeViewController(controller: MFMessageComposeViewController, didFinishWithResult result: MessageComposeResult) {
        controller.dismissViewControllerAnimated(true, completion: nil)
    }
}

extension ContactDetailViewController : MFMailComposeViewControllerDelegate {
    func mailComposeController(controller: MFMailComposeViewController, didFinishWithResult result: MFMailComposeResult, error: NSError?) {
        dismissViewControllerAnimated(true, completion: nil)
    }
}

extension ContactDetailViewController {
    
    @IBAction func backAct(sender: UIButton) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
}