//
//  ContentDetailViewController.swift
//  AirFive
//
//  Created by Anil Gautam on 5/13/16.
//  Copyright © 2016 AirFive. All rights reserved.
//

import UIKit

class ContentDetailViewController : BaseViewController {

    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var progressView: M13ProgressViewRing!
    @IBOutlet weak var detailWebView: UIWebView!
 
    var contentMeta:ContentMeta! = nil
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        detailWebView.delegate = self
        progressView.hidden = true
        if contentMeta != nil {
            titleLbl.text = contentMeta.title
            detailWebView.loadRequest(NSURLRequest(URL: NSURL(string: contentMeta.url)!))
        }
        
    }
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        if progressView != nil {
            progressView.backgroundRingWidth = 2
            progressView.showPercentage = false
            progressView.indeterminate = true
        }
    }
    
}

extension ContentDetailViewController : UIWebViewDelegate {
    
    func webViewDidStartLoad(webView: UIWebView) {
        progressView.hidden = false
    }
    
    func webViewDidFinishLoad(webView: UIWebView) {
        progressView.hidden = true
    }
    
    func webView(webView: UIWebView, didFailLoadWithError error: NSError?) {
        progressView.hidden = true
    }
}

extension ContentDetailViewController {

    @IBAction func closeAct() {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
}